/// <reference types="next" />
/// <reference types="next/image-types/global" />

// Next.js regenerates this file during development/build.
// Do not reference a generated .next file in the source distribution.
