# Therapy Scheduler — repaired source package

This package preserves the existing scheduler, dashboard, therapy selection, room masters,
capabilities, practitioner planner, reports, and sample data.

## Run locally

Use **Node.js 22**. Extract this ZIP into a **new, empty folder** and open a terminal in
the folder containing `package.json`. Do not overlay it onto an old install: removed
configuration files and lockfiles would otherwise remain there.

```sh
npm install
npm run dev
```

Open `http://localhost:3000`.

**No Gemini API key or `.env.local` file is required.** The current application has no
AI API calls. Optional hosting variables are described in `.env.example`.

The first install creates `package-lock.json`. Retain that file for subsequent
reproducible installs with `npm ci`. The old `bun.lock` has intentionally been removed
because it pins the incompatible linting configuration. A replacement lockfile could
not be generated in the repair environment because the package registry was unreachable.

## Validate and run a production build

```sh
npm run verify
npm start
```

`verify` runs ESLint, a full project TypeScript check, regression tests, and the
production build. Alternatively, build directly:

```sh
npm run build
npm start
```

The build prepares `.next/standalone`, including static assets. `npm start` launches
that standalone server. Use your hosting environment to set `PORT` and `HOSTNAME` when
needed. Do not run the production start command before building.

## Clear generated caches

Stop the running development server first, then run:

```sh
npm run clean
npm run dev
```

The cleanup script works with Node on Windows, macOS, and Linux. It removes `.next`
and TypeScript build metadata only; it does not delete dependencies or browser data.

## Saved-data behavior

The scheduler uses the browser's localStorage key `therapy_scheduler_data_v4`.
Valid existing snapshots are retained. Missing collections, malformed JSON, duplicate
record IDs, and malformed records are rejected before the UI reads them.

When saved data is incompatible, the app displays a warning and temporary demo data.
**The original saved value is not overwritten.** Changes in that temporary session
are not persisted. Back up the original browser storage before using the explicitly
confirmed **Reset Demo** action. That action replaces the saved dataset.

Storage permission and quota errors are also shown in a visible warning. The
application remains usable in memory, but unsaved changes will not survive a reload.
Data is local to the current browser and origin; switching hostnames or ports does not
move the saved records to the new origin.

This remains a prototype/local-data application. This repair does not add a backend,
authentication, multi-user synchronization, or production clinical-data controls.

## What was checked

**28 automated checks passed** in the repair environment, covering:

- Parsing every TypeScript/TSX source file and strict type checking of the core models,
  sample data, validation, IDs, and data service.
- Stored-data compatibility, unavailable/full storage, reset behavior, notifications,
  rapid order creation, allocation state updates, and unique history IDs.
- Configuration consistency and isolated cleanup/standalone-script fixtures.

These are not end-to-end browser tests. **Dependency installation, a complete Next.js
production build, a full React/Next.js type check, ESLint execution, and browser testing
could not be completed here**, because the environment could not resolve
`registry.npmjs.org`. Run `npm run verify` after installation on your machine.

The checks ran with Node.js 22.16.0 and the locally available TypeScript 5.8.3 compiler.
The project retains its declared TypeScript 5.9.3 dependency for normal installation.
See `FIX_NOTES.md` and `TEST_RESULTS.txt` for details.
