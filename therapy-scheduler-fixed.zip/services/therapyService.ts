import {
  StationType,
  Station,
  Treatment,
  StationTreatmentCapability,
  Practitioner,
  StationPractitionerRoster,
  Patient,
  TreatmentOrder,
  TreatmentOccurrence,
  TreatmentAllocation,
  AllocationHistory,
  AllocationStatus,
  OccurrenceStatus,
  PriorityLevel,
} from '@/types/therapy';
import {
  INITIAL_STATION_TYPES,
  INITIAL_STATIONS,
  INITIAL_TREATMENTS,
  INITIAL_CAPABILITIES,
  INITIAL_PRACTITIONERS,
  INITIAL_PATIENTS,
  generateInitialRosters,
  generateInitialOrders,
  getTodayDateString,
} from '@/lib/sampleData';
import { ValidationContext } from '@/lib/validation';
import { createId } from '@/lib/id';

const STORAGE_KEY = 'therapy_scheduler_data_v4';

export interface StorageData {
  stationTypes: StationType[];
  stations: Station[];
  treatments: Treatment[];
  capabilities: StationTreatmentCapability[];
  practitioners: Practitioner[];
  patients: Patient[];
  rosters: StationPractitionerRoster[];
  orders: TreatmentOrder[];
  occurrences: TreatmentOccurrence[];
  allocations: TreatmentAllocation[];
  history: AllocationHistory[];
  lastInitializedDate: string;
}

// Storage is an untrusted boundary: a valid JSON document may still be an
// incomplete snapshot from an older app version. Check every collection before
// allowing page components to call .map(), .filter(), or string methods on it.
const snapshotFields: Record<string, { strings: string[]; numbers?: string[]; booleans?: string[] }> = {
  stationTypes: { strings: ['name', 'description'], numbers: ['defaultCapacity'], booleans: ['isActive'] },
  stations: { strings: ['name', 'stationTypeId', 'department', 'location'], numbers: ['capacity'], booleans: ['isActive'] },
  treatments: { strings: ['name', 'description'], numbers: ['defaultDurationMinutes'], booleans: ['isActive'] },
  capabilities: { strings: ['stationId', 'treatmentId', 'attentionMode'], numbers: ['durationMinutes', 'stationCapacity'], booleans: ['isAllowed', 'isActive'] },
  practitioners: { strings: ['externalPractitionerId', 'displayName', 'department'], booleans: ['isActive'] },
  patients: { strings: ['externalPatientId', 'displayName', 'gender', 'department'], numbers: ['age'] },
  rosters: { strings: ['date', 'startTime', 'endTime', 'stationId', 'primaryPractitionerId', 'status'] },
  orders: { strings: ['externalOrderId', 'patientId', 'treatmentId', 'earliestAllowedDate', 'latestAllowedDate', 'priority', 'instructions', 'status'], numbers: ['totalSessions', 'completedSessions'] },
  occurrences: { strings: ['treatmentOrderId', 'requestedDate', 'status'], numbers: ['sessionNumber', 'expectedDurationMinutes'] },
  allocations: { strings: ['treatmentOccurrenceId', 'stationId', 'date', 'plannedStart', 'plannedEnd', 'status', 'createdBy', 'createdAt'] },
  history: { strings: ['allocationId', 'eventType', 'performedBy', 'performedAt'] },
};

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

function isStorageData(value: unknown): value is StorageData {
  if (!isRecord(value) || typeof value.lastInitializedDate !== 'string') return false;
  for (const [key, fields] of Object.entries(snapshotFields)) {
    const records = value[key];
    if (!Array.isArray(records)) return false;
    const ids = new Set<string>();
    for (const record of records) {
      if (!isRecord(record) || typeof record.id !== 'string' || !record.id || ids.has(record.id)) return false;
      ids.add(record.id);
      if (fields.strings.some((field) => typeof record[field] !== 'string')) return false;
      if (fields.numbers?.some((field) => typeof record[field] !== 'number' || !Number.isFinite(record[field]))) return false;
      if (fields.booleans?.some((field) => typeof record[field] !== 'boolean')) return false;
      for (const field of ['variations', 'genderApplicability', 'practitionerIds']) {
        const items = record[field];
        if (items !== undefined && (!Array.isArray(items) || items.some((item) => typeof item !== 'string'))) return false;
      }
      if (record.therapyApplicability !== undefined) {
        const rules = record.therapyApplicability;
        if (!Array.isArray(rules) || rules.some((rule) => !isRecord(rule) || typeof rule.category !== 'string' || typeof rule.treatmentId !== 'string')) return false;
      }
    }
  }
  return true;
}

export class TherapyDataService {
  private static instance: TherapyDataService;
  private data: StorageData;
  private listeners: Array<() => void> = [];
  private storageWarning: string | null = null;
  private storageWriteBlocked = false;

  private constructor() {
    this.data = this.loadData();
  }

  public static getInstance(): TherapyDataService {
    if (!TherapyDataService.instance) {
      TherapyDataService.instance = new TherapyDataService();
    }
    return TherapyDataService.instance;
  }

  private loadData(): StorageData {
    const today = getTodayDateString();
    if (typeof window !== 'undefined') {
      try {
        const stored = window.localStorage.getItem(STORAGE_KEY);
        if (stored !== null) {
          let parsed: unknown;
          try {
            parsed = JSON.parse(stored);
          } catch {
            // Handle invalid JSON the same way as an incomplete snapshot below.
          }
          if (isStorageData(parsed)) return parsed;
          this.storageWriteBlocked = true;
          this.storageWarning = 'Saved scheduler data is invalid or incompatible and has NOT been overwritten. Temporary demo data is displayed; changes will not be saved. Back up the browser storage before choosing Reset Demo.';
        }
      } catch {
        this.storageWriteBlocked = true;
        this.storageWarning = 'Browser storage is unavailable. The scheduler is running with temporary demo data; changes will be lost when the page is reloaded. Enable site storage and reload to restore persistence.';
      }
    }
    return this.createDefaultDataset(today);
  }

  private createDefaultDataset(today: string): StorageData {
    const { orders, occurrences, allocations, history } = generateInitialOrders(today);
    const initial: StorageData = {
      stationTypes: INITIAL_STATION_TYPES,
      stations: INITIAL_STATIONS,
      treatments: INITIAL_TREATMENTS,
      capabilities: INITIAL_CAPABILITIES,
      practitioners: INITIAL_PRACTITIONERS,
      patients: INITIAL_PATIENTS,
      rosters: generateInitialRosters(today),
      orders,
      occurrences,
      allocations,
      history,
      lastInitializedDate: today,
    };
    this.saveData(initial);
    return initial;
  }

  private saveData(data: StorageData) {
    this.data = data;
    if (typeof window !== 'undefined' && !this.storageWriteBlocked) {
      try {
        window.localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
        this.storageWarning = null;
      } catch {
        this.storageWarning = 'Your latest changes could not be saved to browser storage. They are available only in this session. Check storage permissions or available space before reloading.';
      }
    }
    this.notify();
  }

  public getStorageWarning(): string | null {
    return this.storageWarning;
  }

  public subscribe(listener: () => void): () => void {
    this.listeners.push(listener);
    return () => {
      this.listeners = this.listeners.filter((l) => l !== listener);
    };
  }

  private notify() {
    this.listeners.forEach((l) => l());
  }

  public resetToDemo(): void {
    const today = getTodayDateString();
    // Invoked only after the UI's explicit Reset Demo confirmation.
    this.storageWriteBlocked = false;
    this.storageWarning = null;
    this.createDefaultDataset(today);
  }

  // Getters
  public getData(): StorageData {
    return this.data;
  }

  public getStationTypes(): StationType[] {
    return this.data.stationTypes;
  }

  public getStations(): Station[] {
    return this.data.stations;
  }

  public getCapabilities(): StationTreatmentCapability[] {
    return this.data.capabilities;
  }

  public getPractitioners(): Practitioner[] {
    return this.data.practitioners;
  }

  public getRosters(): StationPractitionerRoster[] {
    return this.data.rosters;
  }

  public getTreatments(): Treatment[] {
    return this.data.treatments;
  }

  public getPatients(): Patient[] {
    return this.data.patients;
  }

  public getOrders(): TreatmentOrder[] {
    return this.data.orders;
  }

  public getOccurrences(): TreatmentOccurrence[] {
    return this.data.occurrences;
  }

  public getAllocations(): TreatmentAllocation[] {
    return this.data.allocations;
  }

  public getHistory(): AllocationHistory[] {
    return this.data.history;
  }

  public resetToSampleData(): void {
    this.resetToDemo();
  }

  public toggleStationTypeActive(typeId: string, active: boolean): void {
    const updated = this.data.stationTypes.map((t) => (t.id === typeId ? { ...t, isActive: active } : t));
    this.saveData({ ...this.data, stationTypes: updated });
  }

  public toggleStationActive(stationId: string, active: boolean): void {
    const updated = this.data.stations.map((s) => (s.id === stationId ? { ...s, isActive: active } : s));
    this.saveData({ ...this.data, stations: updated });
  }

  public toggleCapabilityAllowed(stationId: string, treatmentId: string): void {
    const existing = this.data.capabilities.find((c) => c.stationId === stationId && c.treatmentId === treatmentId);
    let updated;
    if (existing) {
      updated = this.data.capabilities.map((c) =>
        c.stationId === stationId && c.treatmentId === treatmentId ? { ...c, isAllowed: !c.isAllowed } : c
      );
    } else {
      const treatment = this.data.treatments.find((t) => t.id === treatmentId);
      const newCap: StationTreatmentCapability = {
        id: `cap-${stationId}-${treatmentId}`,
        stationId,
        treatmentId,
        isAllowed: true,
        durationMinutes: treatment?.defaultDurationMinutes || 45,
        stationCapacity: 1,
        attentionMode: 'EXCLUSIVE',
        maximumParallelPatients: 1,
        isActive: true,
      };
      updated = [...this.data.capabilities, newCap];
    }
    this.saveData({ ...this.data, capabilities: updated });
  }

  public copyRosters(sourceDate: string, targetDate: string): void {
    const sourceRosters = this.data.rosters.filter((r) => r.date === sourceDate);
    const otherRosters = this.data.rosters.filter((r) => r.date !== targetDate);
    const newTargetRosters = sourceRosters.map((r) => ({
      ...r,
      id: createId('rst'),
      date: targetDate,
    }));
    this.saveData({ ...this.data, rosters: [...otherRosters, ...newTargetRosters] });
  }

  public createPatient(patient: Omit<Patient, 'id' | 'externalPatientId'> & { externalPatientId?: string }): Patient {
    const id = createId('pat');
    const extId = patient.externalPatientId || `MRN-${Math.floor(100000 + Math.random() * 900000)}`;
    const newPat: Patient = { ...patient, id, externalPatientId: extId };
    this.saveData({ ...this.data, patients: [...this.data.patients, newPat] });
    return newPat;
  }

  public createOrder(
    patientId: string,
    treatmentId: string,
    totalSessions: number,
    earliestAllowedDate: string,
    latestAllowedDate: string,
    priority: PriorityLevel,
    instructions: string
  ): { order: TreatmentOrder; occurrences: TreatmentOccurrence[] } {
    const orderId = createId('ord');
    const newOrder: TreatmentOrder = {
      id: orderId,
      externalOrderId: `EXT-ORD-${Math.floor(100000 + Math.random() * 900000)}`,
      patientId,
      treatmentId,
      totalSessions,
      completedSessions: 0,
      earliestAllowedDate,
      latestAllowedDate,
      priority,
      instructions,
      status: 'ACTIVE',
    };

    const treatment = this.data.treatments.find((t) => t.id === treatmentId);
    const duration = treatment?.defaultDurationMinutes || 45;

    const newOccs: TreatmentOccurrence[] = [];
    for (let i = 1; i <= totalSessions; i++) {
      newOccs.push({
        id: `occ-${orderId}-${i}`,
        treatmentOrderId: orderId,
        sessionNumber: i,
        expectedDurationMinutes: duration,
        requestedDate: earliestAllowedDate,
        status: 'UNSCHEDULED',
      });
    }

    this.saveData({
      ...this.data,
      orders: [...this.data.orders, newOrder],
      occurrences: [...this.data.occurrences, ...newOccs],
    });

    return { order: newOrder, occurrences: newOccs };
  }

  public createOrderWithVariations(
    patientId: string,
    treatmentId: string,
    totalSessions: number,
    earliestAllowedDate: string,
    latestAllowedDate: string,
    priority: PriorityLevel,
    instructions: string,
    customDuration: number
  ): { order: TreatmentOrder; occurrences: TreatmentOccurrence[] } {
    const orderId = createId('ord');
    const newOrder: TreatmentOrder = {
      id: orderId,
      externalOrderId: `EXT-ORD-${Math.floor(100000 + Math.random() * 900000)}`,
      patientId,
      treatmentId,
      totalSessions,
      completedSessions: 0,
      earliestAllowedDate,
      latestAllowedDate,
      priority,
      instructions,
      status: 'ACTIVE',
    };

    const newOccs: TreatmentOccurrence[] = [];
    for (let i = 1; i <= totalSessions; i++) {
      newOccs.push({
        id: `occ-${orderId}-${i}`,
        treatmentOrderId: orderId,
        sessionNumber: i,
        expectedDurationMinutes: customDuration,
        requestedDate: earliestAllowedDate,
        status: 'UNSCHEDULED',
      });
    }

    this.saveData({
      ...this.data,
      orders: [...this.data.orders, newOrder],
      occurrences: [...this.data.occurrences, ...newOccs],
    });

    return { order: newOrder, occurrences: newOccs };
  }

  public recordBackupTakeover(
    allocationId: string,
    backupPractitionerId: string,
    reason: string,
    performedBy: string = 'Clinical Supervisor'
  ): void {
    this.takeoverByBackup(allocationId, backupPractitionerId, reason, performedBy);
  }

  public getValidationContext(): ValidationContext {
    return {
      stations: this.data.stations,
      treatments: this.data.treatments,
      capabilities: this.data.capabilities,
      rosters: this.data.rosters,
      practitioners: this.data.practitioners,
      patients: this.data.patients,
      orders: this.data.orders,
      occurrences: this.data.occurrences,
      allocations: this.data.allocations,
    };
  }

  // Station Types CRUD
  public saveStationType(type: StationType): void {
    const exists = this.data.stationTypes.some((t) => t.id === type.id);
    const updated = exists
      ? this.data.stationTypes.map((t) => (t.id === type.id ? type : t))
      : [...this.data.stationTypes, type];
    this.saveData({ ...this.data, stationTypes: updated });
  }

  public deleteStationType(id: string): void {
    this.saveData({
      ...this.data,
      stationTypes: this.data.stationTypes.filter((t) => t.id !== id),
    });
  }

  // Stations CRUD
  public saveStation(station: Station): void {
    const exists = this.data.stations.some((s) => s.id === station.id);
    const updated = exists
      ? this.data.stations.map((s) => (s.id === station.id ? station : s))
      : [...this.data.stations, station];
    this.saveData({ ...this.data, stations: updated });
  }

  public deleteStation(id: string): void {
    this.saveData({
      ...this.data,
      stations: this.data.stations.filter((s) => s.id !== id),
    });
  }

  // Treatments CRUD
  public saveTreatment(treatment: Treatment): void {
    const exists = this.data.treatments.some((t) => t.id === treatment.id);
    const updated = exists
      ? this.data.treatments.map((t) => (t.id === treatment.id ? treatment : t))
      : [...this.data.treatments, treatment];
    this.saveData({ ...this.data, treatments: updated });
  }

  // Station Treatment Capabilities CRUD
  public saveCapability(capability: StationTreatmentCapability): void {
    const exists = this.data.capabilities.some((c) => c.id === capability.id);
    const updated = exists
      ? this.data.capabilities.map((c) => (c.id === capability.id ? capability : c))
      : [...this.data.capabilities, capability];
    this.saveData({ ...this.data, capabilities: updated });
  }

  public batchUpdateCapabilities(capabilities: StationTreatmentCapability[]): void {
    this.saveData({ ...this.data, capabilities });
  }

  // Practitioners CRUD
  public savePractitioner(practitioner: Practitioner): void {
    const exists = this.data.practitioners.some((p) => p.id === practitioner.id);
    const updated = exists
      ? this.data.practitioners.map((p) => (p.id === practitioner.id ? practitioner : p))
      : [...this.data.practitioners, practitioner];
    this.saveData({ ...this.data, practitioners: updated });
  }

  // Rosters CRUD & Batch operations
  public saveRoster(roster: StationPractitionerRoster): void {
    const exists = this.data.rosters.some(
      (r) => r.id === roster.id || (r.stationId === roster.stationId && r.date === roster.date)
    );
    const updated = exists
      ? this.data.rosters.map((r) =>
          r.id === roster.id || (r.stationId === roster.stationId && r.date === roster.date)
            ? { ...r, ...roster }
            : r
        )
      : [...this.data.rosters, roster];
    this.saveData({ ...this.data, rosters: updated });
  }

  public deleteRoster(id: string): void {
    this.saveData({
      ...this.data,
      rosters: this.data.rosters.filter((r) => r.id !== id),
    });
  }

  public copyRosterFromDate(sourceDate: string, targetDate: string): number {
    const sourceRosters = this.data.rosters.filter((r) => r.date === sourceDate);
    if (sourceRosters.length === 0) return 0;

    // Filter out any existing rosters on targetDate to overwrite or merge
    const otherRosters = this.data.rosters.filter((r) => r.date !== targetDate);
    const copied: StationPractitionerRoster[] = sourceRosters.map((r) => ({
      ...r,
      id: `roster-${targetDate}-${r.stationId}-${Math.random().toString(36).substring(2, 6)}`,
      date: targetDate,
    }));

    this.saveData({ ...this.data, rosters: [...otherRosters, ...copied] });
    return copied.length;
  }

  public applyRosterToDates(rosterTemplate: Omit<StationPractitionerRoster, 'id' | 'date'>, dates: string[]): void {
    const targetSet = new Set(dates);
    const retained = this.data.rosters.filter(
      (r) => !(targetSet.has(r.date) && r.stationId === rosterTemplate.stationId)
    );

    const generated: StationPractitionerRoster[] = dates.map((d) => ({
      ...rosterTemplate,
      id: `roster-${d}-${rosterTemplate.stationId}-${Math.random().toString(36).substring(2, 6)}`,
      date: d,
    }));

    this.saveData({ ...this.data, rosters: [...retained, ...generated] });
  }

  // Allocation Lifecycle & State Transitions
  public createAllocation(
    allocation: Omit<TreatmentAllocation, 'id' | 'createdAt'>,
    performedBy: string = 'Current User'
  ): TreatmentAllocation {
    const id = createId('alloc');
    const nowIso = new Date().toISOString();
    const newAllocation: TreatmentAllocation = {
      ...allocation,
      id,
      createdAt: nowIso,
    };

    // Update Occurrence status
    const occurrence = this.data.occurrences.find((o) => o.id === allocation.treatmentOccurrenceId);
    const updatedOccurrences = this.data.occurrences.map((o) =>
      o.id === allocation.treatmentOccurrenceId ? { ...o, status: 'SCHEDULED' as OccurrenceStatus } : o
    );

    // Create history entry
    const historyEntry: AllocationHistory = {
      id: createId('hist'),
      allocationId: id,
      eventType: allocation.overrideReason ? 'OVERRIDDEN' : 'CREATED',
      newValue: `${allocation.status} on ${allocation.date} (${allocation.plannedStart}-${allocation.plannedEnd})`,
      reason: allocation.overrideReason || 'Direct schedule allocation',
      performedBy,
      performedAt: nowIso,
    };

    this.saveData({
      ...this.data,
      allocations: [...this.data.allocations, newAllocation],
      occurrences: updatedOccurrences,
      history: [historyEntry, ...this.data.history],
    });

    return newAllocation;
  }

  public updateAllocation(
    allocationId: string,
    updates: Partial<TreatmentAllocation>,
    reason: string = 'Updated allocation details',
    performedBy: string = 'Current User'
  ): TreatmentAllocation | null {
    const current = this.data.allocations.find((a) => a.id === allocationId);
    if (!current) return null;

    const nowIso = new Date().toISOString();
    const updatedAllocation: TreatmentAllocation = {
      ...current,
      ...updates,
      updatedBy: performedBy,
      updatedAt: nowIso,
    };

    const updatedAllocations = this.data.allocations.map((a) =>
      a.id === allocationId ? updatedAllocation : a
    );

    let eventType: AllocationHistory['eventType'] = 'RESCHEDULED';
    if (updates.status && updates.status !== current.status) {
      eventType = updates.status === 'CANCELLED' ? 'CANCELLED' : 'STATUS_CHANGED';
    } else if (updates.overrideReason) {
      eventType = 'OVERRIDDEN';
    }

    const historyEntry: AllocationHistory = {
      id: createId('hist'),
      allocationId,
      eventType,
      previousValue: `${current.status} (${current.plannedStart}-${current.plannedEnd})`,
      newValue: `${updatedAllocation.status} (${updatedAllocation.plannedStart}-${updatedAllocation.plannedEnd})`,
      reason,
      performedBy,
      performedAt: nowIso,
    };

    // If status changed to COMPLETED / CANCELLED / NO_SHOW, update Occurrence status as well
    let updatedOccurrences = this.data.occurrences;
    if (updates.status) {
      updatedOccurrences = this.data.occurrences.map((o) => {
        if (o.id === current.treatmentOccurrenceId) {
          let occStatus: OccurrenceStatus = 'SCHEDULED';
          if (updates.status === 'CHECKED_IN') occStatus = 'CHECKED_IN';
          if (updates.status === 'IN_PROGRESS') occStatus = 'IN_PROGRESS';
          if (updates.status === 'COMPLETED') occStatus = 'COMPLETED';
          if (updates.status === 'CANCELLED') occStatus = 'CANCELLED';
          if (updates.status === 'NO_SHOW') occStatus = 'NO_SHOW';
          return { ...o, status: occStatus };
        }
        return o;
      });
    }

    this.saveData({
      ...this.data,
      allocations: updatedAllocations,
      occurrences: updatedOccurrences,
      history: [historyEntry, ...this.data.history],
    });

    return updatedAllocation;
  }

  public updateAllocationStatus(
    allocationId: string,
    status: AllocationStatus,
    notes?: string,
    performedBy: string = 'Clinical Supervisor'
  ): TreatmentAllocation | null {
    const current = this.data.allocations.find((a) => a.id === allocationId);
    if (!current) return null;

    const updates: Partial<TreatmentAllocation> = { status };
    if (notes) {
      updates.notes = current.notes ? `${current.notes} | ${notes}` : notes;
    }
    if (status === 'CHECKED_IN' && !current.checkInTime) {
      updates.checkInTime = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    } else if (status === 'IN_PROGRESS' && !current.actualStartTime) {
      updates.actualStartTime = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    } else if (status === 'COMPLETED' && !current.actualEndTime) {
      updates.actualEndTime = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    }

    return this.updateAllocation(
      allocationId,
      updates,
      `Status changed from ${current.status} to ${status}${notes ? `: ${notes}` : ''}`,
      performedBy
    );
  }

  public returnToUnscheduled(
    allocationId: string,
    reason: string = 'Returned to unscheduled pool',
    performedBy: string = 'Current User'
  ): void {
    const current = this.data.allocations.find((a) => a.id === allocationId);
    if (!current) return;

    const nowIso = new Date().toISOString();
    const historyEntry: AllocationHistory = {
      id: createId('hist'),
      allocationId,
      eventType: 'RETURNED_TO_UNSCHEDULED',
      previousValue: `Station: ${current.stationId}, ${current.plannedStart}-${current.plannedEnd}`,
      newValue: 'Unscheduled Pool',
      reason,
      performedBy,
      performedAt: nowIso,
    };

    const updatedOccurrences = this.data.occurrences.map((o) =>
      o.id === current.treatmentOccurrenceId ? { ...o, status: 'UNSCHEDULED' as OccurrenceStatus } : o
    );

    const updatedAllocations = this.data.allocations.filter((a) => a.id !== allocationId);

    this.saveData({
      ...this.data,
      allocations: updatedAllocations,
      occurrences: updatedOccurrences,
      history: [historyEntry, ...this.data.history],
    });
  }

  public takeoverByBackup(
    allocationId: string,
    backupPractitionerId: string,
    notes: string,
    performedBy: string = 'Supervisor'
  ): void {
    const current = this.data.allocations.find((a) => a.id === allocationId);
    if (!current) return;

    this.updateAllocation(
      allocationId,
      {
        actualPractitionerId: backupPractitionerId,
        notes: current.notes ? `${current.notes} | Backup takeover: ${notes}` : `Backup takeover: ${notes}`,
      },
      `Backup practitioner ${backupPractitionerId} took over care: ${notes}`,
      performedBy
    );
  }

  // Create new Patient / Treatment Order from UI (Simulate external source receiving)
  public createPatientOrder(
    patient: Omit<Patient, 'id'>,
    order: Omit<TreatmentOrder, 'id' | 'patientId' | 'completedSessions'>,
    occurrencesCount: number = 1
  ): { patient: Patient; order: TreatmentOrder; occurrences: TreatmentOccurrence[] } {
    const patientId = createId('pat');
    const newPatient: Patient = { ...patient, id: patientId };

    const orderId = createId('ord');
    const newOrder: TreatmentOrder = {
      ...order,
      id: orderId,
      patientId,
      completedSessions: 0,
    };

    const newOccurrences: TreatmentOccurrence[] = [];
    const treatment = this.data.treatments.find((t) => t.id === order.treatmentId);
    const duration = treatment?.defaultDurationMinutes || 45;

    for (let i = 1; i <= occurrencesCount; i++) {
      newOccurrences.push({
        id: createId('occ'),
        treatmentOrderId: orderId,
        sessionNumber: i,
        expectedDurationMinutes: duration,
        requestedDate: order.earliestAllowedDate || getTodayDateString(),
        status: 'UNSCHEDULED',
      });
    }

    this.saveData({
      ...this.data,
      patients: [...this.data.patients, newPatient],
      orders: [...this.data.orders, newOrder],
      occurrences: [...this.data.occurrences, ...newOccurrences],
    });

    return { patient: newPatient, order: newOrder, occurrences: newOccurrences };
  }
}

export const therapyService = TherapyDataService.getInstance();
