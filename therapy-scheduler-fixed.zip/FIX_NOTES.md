# Repair notes

Package: therapy-scheduler 0.1.1  
Source: the uploaded therapy-scheduler.zip  
Repair date: 22 September 2026

No error log was supplied with the request. The repairs below address issues found in
that source. They do not establish that a particular deployment-specific error has
been reproduced or that the production application is fully verified.

## Reproduced original-code failures

### Incomplete saved data crashes collection reads

The original service accepted any saved JSON object that contained arrays named
`stations` and `allocations`. Other collections could be missing. With the saved value
`{"stations":[],"allocations":[]}`, `getStationTypes()` returned `undefined`.
Filtering it reproduced:

```text
Cannot read properties of undefined (reading 'filter')
```

The updated loader checks every required collection and important record fields before
returning saved data. Invalid snapshots are preserved unchanged, writes are blocked,
and the UI shows a warning with temporary demo data. Explicitly confirmed Reset Demo
restores persistence. Read-permission and quota failures are handled without a startup
exception.

### Rapid order creation produces duplicate keys

The original `createOrderWithVariations()` based order IDs only on `Date.now()`.
Creating 100 orders with the clock held at the same millisecond produced **one unique
order ID**, with repeated occurrence IDs. History entries also used millisecond-only IDs.

The repair uses `crypto.randomUUID()` where available and a sequence-based fallback
otherwise. Repeating the same frozen-clock/randomness test produced **100 unique order
IDs**, with unique occurrence and history IDs. This prevents those ID collisions from
propagating to React list keys and record lookups.

## Next.js/tooling corrections

| Area | Correction |
| --- | --- |
| Framework versions | Pin Next.js to 15.5.25 and React/React DOM to 19.3.0, matching the versions already resolved in the uploaded lockfile. Match eslint-config-next to 15.5.25 rather than mixing it with version 16.0.8. |
| ESLint configuration | Use FlatCompat for Next.js 15's legacy configuration with ESLint 9. Remove the duplicate `.eslintrc.json`. |
| Build checks | Remove the setting that skipped ESLint during production builds. TypeScript checks remain enabled. |
| Browser-only entrypoint | Move the application into `components/TherapySchedulerApp.tsx` and load it from a client wrapper with `ssr: false`. This keeps browser-local dates and localStorage-backed state out of the server's initial rendering. |
| Hydration warnings | Remove the broad body-level suppression. Make the mobile hook's first render deterministic and synchronize its media query after mounting. |
| Generated types | Remove the source distribution's direct reference to a `.next/types/routes.d.ts` file that is absent in a fresh extraction. Next.js may regenerate this reference during normal development/build. |
| Cleanup | Replace the unsupported `next clean` command with a project-relative Node cleanup script. |
| Standalone deployment | Copy `.next/static` and any `public` assets into the standalone output after a successful build. Start that generated server, with a clear message when a production build is absent. |
| Lockfile | Remove the old Bun lockfile rather than retaining incompatible dependency metadata. No new lockfile is claimed to have been generated or verified. |
| Unused scaffolding | Remove unused Gemini, form-resolver, motion, class-variance, Firebase CLI, and typography-plugin dependencies. Preserve used application dependencies. |

## Additional runtime corrections

The scheduler's PDF generator is imported only when Download PDF is clicked. The UI
shows export progress and catches an import/export failure instead of letting it escape
from the event handler. The PDF's existing drawing logic is unchanged.

The allocation details panel now derives its selected allocation from the current
service-backed state, rather than retaining an outdated object after status changes.
Slot/details forms are remounted when their target/open state changes so old form state
does not carry into a newly opened session. The slot form's initial duration matches its
initially selected occurrence.

Pending override callbacks and drag payloads are typed. Drag state is held in a React
ref rather than an untyped window property, and is cleared after drag completion.
Toast callbacks are stable and their timers are cleared on unmount. A route error
boundary provides retry/reload controls without clearing saved data. Existing modal
animation utility classes now have their stylesheet imported.

## Validation and limitations

Completed: **28 checks passed, zero failed**, including source parsing, strict core
TypeScript checks, actual service-module regression tests, and deployment-script fixture
tests. Original-versus-fixed reproduction results are included in `TEST_RESULTS.txt`.

The environment's registry connectivity check returned:

```text
curl: (6) Could not resolve host: registry.npmjs.org
```

Dependency installation could not complete. Consequently, the attempted production
build could not start its Next.js executable:

```text
> next build && node scripts/prepare-standalone.mjs
sh: 1: next: not found
```

This is an environment/testing limitation, not evidence that a real Next.js build has
passed or failed on the repaired application source. Full installation, linting, React/
Next.js type checking, production build, PDF generation, browser hydration, visual
layout, and end-to-end workflows still require validation in an installed environment.
The standalone asset-copy check used fixture files, not a generated Next.js build.

## Suggested local verification

Extract into a fresh directory; install with Node.js 22 and `npm install`, then run
`npm run verify`. Start development with `npm run dev` or start the completed production
build with `npm start`.

In the browser, check Scheduler, Dashboard, Therapy Selection, room types/rooms,
Capabilities, Practitioner Planner, and Reports. Create several treatments in one action,
open an allocation and change its status, schedule/move a slot, download the PDF, and
reload to check valid-data persistence. Preserve existing browser data before testing
Reset Demo.
