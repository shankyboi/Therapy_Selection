'use client';

import React, { useState, useEffect, useCallback, useRef } from 'react';
import {
  ActivePage,
  Station,
  StationType,
  StationPractitionerRoster,
  Practitioner,
  Patient,
  Treatment,
  TreatmentOrder,
  TreatmentOccurrence,
  TreatmentAllocation,
  StationTreatmentCapability,
  AllocationHistory,
  ValidationResult,
  AllocationStatus,
  PriorityLevel,
} from '@/types/therapy';
import { therapyService } from '@/services/therapyService';
import { validateAllocation, calculateEndTime, timeToMinutes } from '@/lib/validation';
import { getTodayDateString, getRelativeDateString } from '@/lib/sampleData';

import { Navbar } from '@/components/Navbar';
import { SchedulerGrid } from '@/components/scheduler/SchedulerGrid';
import { UnscheduledDrawer } from '@/components/scheduler/UnscheduledDrawer';
import { ConflictDialog } from '@/components/scheduler/ConflictDialog';
import { AllocationDetailsModal } from '@/components/scheduler/AllocationDetailsModal';
import { NewOrderModal } from '@/components/scheduler/NewOrderModal';
import { ScheduleSlotModal } from '@/components/scheduler/ScheduleSlotModal';

import { DashboardView } from '@/components/pages/DashboardView';
import { TherapySelectionView } from '@/components/pages/TherapySelectionView';
import { StationTypeMasterView } from '@/components/pages/StationTypeMasterView';
import { StationMasterView } from '@/components/pages/StationMasterView';
import { StationCapabilitiesView } from '@/components/pages/StationCapabilitiesView';
import { PractitionerPlannerView } from '@/components/pages/PractitionerPlannerView';
import { ReportsView } from '@/components/pages/ReportsView';

import {
  Calendar,
  ChevronLeft,
  ChevronRight,
  Plus,
  RotateCcw,
  SlidersHorizontal,
  Info,
  CheckCircle2,
  AlertCircle,
} from 'lucide-react';

type DragData =
  | { type: 'UNSCHEDULED'; occurrenceId: string }
  | { type: 'ALLOCATION'; allocationId: string };

export default function App() {
  const activeDragData = useRef<DragData | null>(null);

  // Navigation
  const [currentPage, setCurrentPage] = useState<ActivePage>('scheduler');
  const [selectedDate, setSelectedDate] = useState<string>(getTodayDateString());

  // App Data State (synced with therapyService)
  const [stationTypes, setStationTypes] = useState<StationType[]>([]);
  const [stations, setStations] = useState<Station[]>([]);
  const [capabilities, setCapabilities] = useState<StationTreatmentCapability[]>([]);
  const [practitioners, setPractitioners] = useState<Practitioner[]>([]);
  const [rosters, setRosters] = useState<StationPractitionerRoster[]>([]);
  const [treatments, setTreatments] = useState<Treatment[]>([]);
  const [patients, setPatients] = useState<Patient[]>([]);
  const [orders, setOrders] = useState<TreatmentOrder[]>([]);
  const [occurrences, setOccurrences] = useState<TreatmentOccurrence[]>([]);
  const [allocations, setAllocations] = useState<TreatmentAllocation[]>([]);
  const [history, setHistory] = useState<AllocationHistory[]>([]);
  const [storageWarning, setStorageWarning] = useState<string | null>(null);

  // Modals & Drawers
  const [isNewOrderOpen, setIsNewOrderOpen] = useState(false);
  const [isSlotScheduleOpen, setIsSlotScheduleOpen] = useState(false);
  const [slotTargetStation, setSlotTargetStation] = useState<Station | null>(null);
  const [slotTargetTime, setSlotTargetTime] = useState('09:00');

  const [selectedAllocationId, setSelectedAllocationId] = useState<string | null>(null);
  const selectedAllocation = allocations.find((item) => item.id === selectedAllocationId) ?? null;
  const [isDetailsOpen, setIsDetailsOpen] = useState(false);

  // Unscheduled Drawer Sidebar toggle in scheduler
  const [isUnscheduledOpen, setIsUnscheduledOpen] = useState(true);

  // Height scaling sync state
  const [pixelsPerMinute, setPixelsPerMinute] = useState<number>(1.8);

  // Validation Conflict Dialog
  const [conflictDialogOpen, setConflictDialogOpen] = useState(false);
  const [conflictResult, setConflictResult] = useState<ValidationResult | null>(null);
  const [pendingAction, setPendingAction] = useState<((overrideReason?: string) => void) | null>(null);

  // Notification toast
  const [toastMessage, setToastMessage] = useState<{ text: string; type: 'success' | 'info' | 'error' } | null>(null);

  const toastTimeout = useRef<ReturnType<typeof setTimeout> | null>(null);
  const showToast = useCallback((text: string, type: 'success' | 'info' | 'error' = 'success') => {
    if (toastTimeout.current !== null) clearTimeout(toastTimeout.current);
    setToastMessage({ text, type });
    toastTimeout.current = setTimeout(() => setToastMessage(null), 4000);
  }, []);

  useEffect(() => () => {
    if (toastTimeout.current !== null) clearTimeout(toastTimeout.current);
  }, []);

  // Sync data on mount and subscribe to state changes
  useEffect(() => {
    const handleDataChange = () => {
      setStationTypes(therapyService.getStationTypes());
      setStations(therapyService.getStations());
      setCapabilities(therapyService.getCapabilities());
      setPractitioners(therapyService.getPractitioners());
      setRosters(therapyService.getRosters());
      setTreatments(therapyService.getTreatments());
      setPatients(therapyService.getPatients());
      setOrders(therapyService.getOrders());
      setOccurrences(therapyService.getOccurrences());
      setAllocations(therapyService.getAllocations());
      setHistory(therapyService.getHistory());
      setStorageWarning(therapyService.getStorageWarning());
    };

    handleDataChange();
    const unsubscribe = therapyService.subscribe(handleDataChange);
    return () => unsubscribe();
  }, []);

  // Quick Date Navigation Helpers
  const handlePrevDay = () => {
    const d = new Date(selectedDate);
    d.setDate(d.getDate() - 1);
    setSelectedDate(d.toISOString().split('T')[0]);
  };

  const handleNextDay = () => {
    const d = new Date(selectedDate);
    d.setDate(d.getDate() + 1);
    setSelectedDate(d.toISOString().split('T')[0]);
  };

  const handleToday = () => {
    setSelectedDate(getTodayDateString());
  };

  // Drag start for existing allocation
  const handleDragStartAllocation = (e: React.DragEvent, allocation: TreatmentAllocation) => {
    e.dataTransfer.setData('text/plain', JSON.stringify({ type: 'ALLOCATION', allocationId: allocation.id }));
    e.dataTransfer.effectAllowed = 'move';
  };

  // Perform allocation with validation & conflict interception
  const executeAllocationAssignment = useCallback(
    (
      occurrenceId: string,
      stationId: string,
      date: string,
      startTime: string,
      durationMinutes: number,
      existingAllocationId?: string,
      overrideReason?: string
    ) => {
      const doAssign = (withOverride?: string) => {
        const endTime = calculateEndTime(startTime, durationMinutes);

        // Perform deep rule validation
        const validation = validateAllocation(
          {
            id: existingAllocationId,
            treatmentOccurrenceId: occurrenceId,
            stationId,
            date,
            plannedStart: startTime,
            plannedEnd: endTime,
          },
          {
            stations,
            stationTypes,
            capabilities,
            practitioners,
            rosters,
            orders,
            occurrences,
            allocations,
            patients,
            treatments,
          }
        );

        // If errors exist or warnings exist without override: prompt dialog
        if (!withOverride && (!validation.isValid || validation.warnings.length > 0)) {
          setConflictResult(validation);
          setPendingAction(() => (overrideMsg?: string) => {
            doAssign(overrideMsg || 'Supervisor Clinical Override');
          });
          setConflictDialogOpen(true);
          return;
        }

        if (!validation.isValid && !withOverride) {
          setConflictResult(validation);
          setConflictDialogOpen(true);
          return;
        }

        // Find station primary practitioner
        const currentRoster = rosters.find((r) => r.stationId === stationId && r.date === date);
        const plannedPracId = currentRoster?.primaryPractitionerId;

        if (existingAllocationId) {
          // Update existing allocation (move/reschedule)
          const updated = therapyService.updateAllocation(
            existingAllocationId,
            {
              stationId,
              date,
              plannedStart: startTime,
              plannedEnd: endTime,
              plannedPractitionerId: plannedPracId,
              overrideReason: withOverride || undefined,
              overriddenBy: withOverride ? 'Clinical Supervisor' : undefined,
              overriddenAt: withOverride ? new Date().toISOString() : undefined,
            },
            `Rescheduled to ${date} ${startTime}-${endTime} on station`,
            'Scheduler Dispatcher'
          );
          if (updated) {
            showToast(`Allocation rescheduled successfully to ${startTime} on station.`, 'success');
          }
        } else {
          // Create new allocation from unscheduled occurrence
          const newAlloc = therapyService.createAllocation(
            {
              treatmentOccurrenceId: occurrenceId,
              stationId,
              date,
              plannedStart: startTime,
              plannedEnd: endTime,
              plannedPractitionerId: plannedPracId,
              status: 'CONFIRMED',
              createdBy: withOverride ? 'Clinical Supervisor' : 'Scheduler Dispatcher',
              overrideReason: withOverride || undefined,
              overriddenBy: withOverride ? 'Clinical Supervisor' : undefined,
              overriddenAt: withOverride ? new Date().toISOString() : undefined,
              rosterId: currentRoster?.id,
            },
            withOverride ? 'Clinical Supervisor' : 'Scheduler Dispatcher'
          );
          if (newAlloc) {
            showToast(`Treatment allocated to ${startTime} - ${endTime}.`, 'success');
          }
        }
      };

      doAssign(overrideReason);
    },
    [stations, stationTypes, capabilities, practitioners, rosters, orders, occurrences, allocations, patients, treatments, showToast]
  );

  // Drop target handler on grid slot
  const handleDropTarget = (stationId: string, timeStr: string) => {
    // Read drag data from window or active drag object
    const dragData = activeDragData.current;
    if (!dragData) return;

    if (dragData.type === 'UNSCHEDULED') {
      const occurrence = occurrences.find((o) => o.id === dragData.occurrenceId);
      const order = occurrence ? orders.find((o) => o.id === occurrence.treatmentOrderId) : null;
      const duration = occurrence?.expectedDurationMinutes || 45;

      executeAllocationAssignment(
        dragData.occurrenceId,
        stationId,
        selectedDate,
        timeStr,
        duration
      );
    } else if (dragData.type === 'ALLOCATION') {
      const alloc = allocations.find((a) => a.id === dragData.allocationId);
      if (!alloc) return;
      const dur = timeToMinutes(alloc.plannedEnd) - timeToMinutes(alloc.plannedStart);

      executeAllocationAssignment(
        alloc.treatmentOccurrenceId,
        stationId,
        selectedDate,
        timeStr,
        dur,
        alloc.id
      );
    }

    activeDragData.current = null;
  };

  // Slot click to open quick schedule modal
  const handleSlotClick = (stationId: string, timeStr: string) => {
    const st = stations.find((s) => s.id === stationId);
    setSlotTargetStation(st || null);
    setSlotTargetTime(timeStr);
    setIsSlotScheduleOpen(true);
  };

  // Open details for allocation
  const handleOpenAllocationDetails = (alloc: TreatmentAllocation) => {
    setSelectedAllocationId(alloc.id);
    setIsDetailsOpen(true);
  };

  // Quick resize allocation duration (+15m or -15m)
  const handleResizeDuration = (allocation: TreatmentAllocation, deltaMinutes: number) => {
    const curStartMins = timeToMinutes(allocation.plannedStart);
    const curEndMins = timeToMinutes(allocation.plannedEnd);
    const newEndMins = curEndMins + deltaMinutes;

    if (newEndMins <= curStartMins + 15) {
      showToast('Minimum treatment duration is 15 minutes', 'error');
      return;
    }

    const newDuration = newEndMins - curStartMins;
    executeAllocationAssignment(
      allocation.treatmentOccurrenceId,
      allocation.stationId,
      allocation.date,
      allocation.plannedStart,
      newDuration,
      allocation.id
    );
  };

  // Handle new external order submission
  const handleCreateNewOrder = (
    patData: {
      isNew: boolean;
      existingPatientId?: string;
      displayName: string;
      gender: 'MALE' | 'FEMALE' | 'OTHER';
      age: number;
      department: string;
      precautions?: string;
    },
    orderData: {
      treatmentId: string;
      totalSessions: number;
      earliestAllowedDate: string;
      latestAllowedDate: string;
      priority: PriorityLevel;
      instructions: string;
    }
  ) => {
    let patientId = patData.existingPatientId;
    if (patData.isNew || !patientId) {
      const newPat = therapyService.createPatient({
        displayName: patData.displayName,
        gender: patData.gender,
        age: patData.age,
        department: patData.department,
        precautions: patData.precautions,
      });
      patientId = newPat.id;
    }

    const createdOrder = therapyService.createOrder(
      patientId,
      orderData.treatmentId,
      orderData.totalSessions,
      orderData.earliestAllowedDate,
      orderData.latestAllowedDate,
      orderData.priority,
      orderData.instructions
    );

    showToast(`Order created with ${orderData.totalSessions} sessions placed into unscheduled pool.`, 'success');
  };

  // Reset demo sample data
  const handleResetData = () => {
    if (confirm('Are you sure you want to reset all scheduler state to the default clinical sample data?')) {
      therapyService.resetToSampleData();
      showToast('Sample dataset restored successfully.', 'info');
    }
  };

  // Get data for selected allocation modal
  const selectedOcc = selectedAllocation
    ? occurrences.find((o) => o.id === selectedAllocation.treatmentOccurrenceId)
    : undefined;
  const selectedOrder = selectedOcc
    ? orders.find((o) => o.id === selectedOcc.treatmentOrderId)
    : undefined;
  const selectedPatient = selectedOrder
    ? patients.find((p) => p.id === selectedOrder.patientId)
    : undefined;
  const selectedTreatment = selectedOrder
    ? treatments.find((t) => t.id === selectedOrder.treatmentId)
    : undefined;
  const selectedStation = selectedAllocation
    ? stations.find((s) => s.id === selectedAllocation.stationId)
    : undefined;
  const selectedStationType = selectedStation
    ? stationTypes.find((st) => st.id === selectedStation.stationTypeId)
    : undefined;
  const selectedRoster = selectedAllocation
    ? rosters.find((r) => r.stationId === selectedAllocation.stationId && r.date === selectedAllocation.date)
    : undefined;
  const plannedPractitioner = selectedAllocation?.plannedPractitionerId
    ? practitioners.find((p) => p.id === selectedAllocation.plannedPractitionerId)
    : selectedRoster?.primaryPractitionerId
    ? practitioners.find((p) => p.id === selectedRoster.primaryPractitionerId)
    : undefined;
  const actualPractitioner = selectedAllocation?.actualPractitionerId
    ? practitioners.find((p) => p.id === selectedAllocation.actualPractitionerId)
    : undefined;
  const backupPractitioner = selectedRoster?.backupPractitionerId
    ? practitioners.find((p) => p.id === selectedRoster.backupPractitionerId)
    : undefined;

  const unscheduledOccurrences = occurrences.filter((o) => o.status === 'UNSCHEDULED');

  return (
    <div onDragEnd={() => { activeDragData.current = null; }} className="min-h-screen bg-slate-100 flex flex-col text-slate-900 font-sans antialiased selection:bg-teal-500 selection:text-white">
      {/* Primary Top Header Navigation */}
      <Navbar
        activePage={currentPage}
        onNavigate={setCurrentPage}
        selectedDate={selectedDate}
        onDateChange={setSelectedDate}
        onOpenNewOrder={() => setIsNewOrderOpen(true)}
        onResetDemo={handleResetData}
        unscheduledCount={unscheduledOccurrences.length}
      />

      {storageWarning && (
        <p role="alert" className="border-b border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-900">
          {storageWarning}
        </p>
      )}

      {/* Main Content View Switcher */}
      <main className="flex-1 flex flex-col overflow-hidden relative">
        {currentPage === 'dashboard' && (
          <div className="flex-1 overflow-y-auto">
            <DashboardView
              selectedDate={selectedDate}
              stations={stations}
              stationTypes={stationTypes}
              practitioners={practitioners}
              rosters={rosters}
              orders={orders}
              occurrences={occurrences}
              allocations={allocations}
              patients={patients}
              treatments={treatments}
              capabilities={capabilities}
              onNavigate={setCurrentPage}
              onSelectAllocation={handleOpenAllocationDetails}
              onQuickScheduleOccurrence={(occ) => {
                const ord = orders.find((o) => o.id === occ.treatmentOrderId);
                const defaultStation = stations.find((s) => s.isActive);
                if (defaultStation) {
                  setSlotTargetStation(defaultStation);
                  setSlotTargetTime('09:00');
                  setIsSlotScheduleOpen(true);
                }
              }}
            />
          </div>
        )}

        {currentPage === 'therapy-selection' && (
          <div className="flex-1 overflow-y-auto">
            <TherapySelectionView
              patients={patients}
              treatments={treatments}
              orders={orders}
              onCreateOrder={(
                patientId,
                treatmentId,
                totalSessions,
                earliestAllowedDate,
                latestAllowedDate,
                priority,
                instructions,
                customDuration
              ) => {
                therapyService.createOrderWithVariations(
                  patientId,
                  treatmentId,
                  totalSessions,
                  earliestAllowedDate,
                  latestAllowedDate,
                  priority,
                  instructions,
                  customDuration
                );
              }}
              showToast={showToast}
            />
          </div>
        )}

        {currentPage === 'scheduler' && (
          <div className="flex-1 flex overflow-hidden relative">
            {/* Main Day Planner Horizontal Grid */}
            <div className="flex-1 flex flex-col overflow-hidden">
              <SchedulerGrid
                selectedDate={selectedDate}
                stations={stations}
                stationTypes={stationTypes}
                rosters={rosters}
                practitioners={practitioners}
                allocations={allocations}
                patients={patients}
                treatments={treatments}
                orders={orders}
                occurrences={occurrences}
                capabilities={capabilities}
                onSlotClick={handleSlotClick}
                onAllocationClick={handleOpenAllocationDetails}
                onDragStartAllocation={(e, allocation) => {
                  activeDragData.current = {
                    type: 'ALLOCATION',
                    allocationId: allocation.id,
                  };
                  handleDragStartAllocation(e, allocation);
                }}
                onResizeDuration={handleResizeDuration}
                onDropTarget={handleDropTarget}
                onPixelsPerMinuteChange={setPixelsPerMinute}
              />
            </div>

             {/* Right Unscheduled Treatment Review Queue Panel */}
            <UnscheduledDrawer
              isOpen={isUnscheduledOpen}
              onToggleOpen={() => setIsUnscheduledOpen(!isUnscheduledOpen)}
              occurrences={occurrences}
              orders={orders}
              patients={patients}
              treatments={treatments}
              capabilities={capabilities}
              onOpenNewOrderModal={() => setIsNewOrderOpen(true)}
              onQuickSchedule={(occurrence) => {
                const defaultStation = stations.find((s) => s.isActive);
                if (defaultStation) {
                  setSlotTargetStation(defaultStation);
                  setSlotTargetTime('09:00');
                  setIsSlotScheduleOpen(true);
                }
              }}
              onDragStartTile={(e, occurrence) => {
                activeDragData.current = {
                  type: 'UNSCHEDULED',
                  occurrenceId: occurrence.id,
                };
              }}
              pixelsPerMinute={pixelsPerMinute}
            />
          </div>
        )}

        {currentPage === 'station-types' && (
          <div className="flex-1 overflow-y-auto">
            <StationTypeMasterView
              stationTypes={stationTypes}
              onSaveStationType={(type) => {
                therapyService.saveStationType(type);
                showToast(`Station type '${type.name}' saved.`, 'success');
              }}
              onToggleActive={(typeId, active) => {
                therapyService.toggleStationTypeActive(typeId, active);
              }}
            />
          </div>
        )}

        {currentPage === 'stations' && (
          <div className="flex-1 overflow-y-auto">
            <StationMasterView
              stations={stations}
              stationTypes={stationTypes}
              treatments={treatments}
              onSaveStation={(station) => {
                therapyService.saveStation(station);
                showToast(`Station '${station.name}' saved.`, 'success');
              }}
              onToggleActive={(stationId, active) => {
                therapyService.toggleStationActive(stationId, active);
              }}
              onNavigate={setCurrentPage}
            />
          </div>
        )}

        {currentPage === 'capabilities' && (
          <div className="flex-1 overflow-y-auto">
            <StationCapabilitiesView
              stations={stations}
              treatments={treatments}
              capabilities={capabilities}
              onSaveCapability={(cap) => {
                therapyService.saveCapability(cap);
                showToast('Capability rule updated.', 'success');
              }}
              onToggleAllowed={(stationId, treatmentId) => {
                therapyService.toggleCapabilityAllowed(stationId, treatmentId);
              }}
            />
          </div>
        )}

        {currentPage === 'practitioner-planner' && (
          <div className="flex-1 overflow-y-auto">
            <PractitionerPlannerView
              selectedDate={selectedDate}
              onDateChange={setSelectedDate}
              stations={stations}
              stationTypes={stationTypes}
              practitioners={practitioners}
              rosters={rosters}
              onSaveRoster={(roster) => {
                therapyService.saveRoster(roster);
                showToast('Practitioner shift roster updated.', 'success');
              }}
              onCopyFromDate={(sourceDate, targetDate) => {
                therapyService.copyRosters(sourceDate, targetDate);
                showToast(`Roster copied from ${sourceDate} to ${targetDate}.`, 'success');
              }}
            />
          </div>
        )}

        {currentPage === 'reports' && (
          <div className="flex-1 overflow-y-auto">
            <ReportsView
              allocations={allocations}
              patients={patients}
              treatments={treatments}
              stations={stations}
              practitioners={practitioners}
              orders={orders}
              occurrences={occurrences}
              onSelectAllocation={handleOpenAllocationDetails}
            />
          </div>
        )}
      </main>

      {/* Global Notification Toast */}
      {toastMessage && (
        <div className="fixed bottom-5 right-5 z-50 animate-in slide-in-from-bottom-5 duration-200">
          <div
            className={`px-4 py-3 rounded-xl shadow-lg border text-xs font-semibold flex items-center gap-2.5 ${
              toastMessage.type === 'success'
                ? 'bg-slate-900 text-white border-slate-800'
                : toastMessage.type === 'error'
                ? 'bg-rose-900 text-white border-rose-800'
                : 'bg-teal-900 text-white border-teal-800'
            }`}
          >
            {toastMessage.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            ) : (
              <AlertCircle className="w-4 h-4 text-amber-400" />
            )}
            <span>{toastMessage.text}</span>
          </div>
        </div>
      )}

      {/* Modals & Overlays */}
      {/* 1. External Order Intake Modal */}
      <NewOrderModal
        isOpen={isNewOrderOpen}
        onClose={() => setIsNewOrderOpen(false)}
        treatments={treatments}
        patients={patients}
        onCreateOrder={handleCreateNewOrder}
      />

      {/* 2. Direct Slot Placement Modal */}
      <ScheduleSlotModal
        key={`${slotTargetStation?.id ?? 'none'}-${selectedDate}-${slotTargetTime}-${isSlotScheduleOpen}`}
        isOpen={isSlotScheduleOpen}
        onClose={() => setIsSlotScheduleOpen(false)}
        selectedStation={slotTargetStation}
        selectedDate={selectedDate}
        selectedTime={slotTargetTime}
        unscheduledOccurrences={unscheduledOccurrences}
        orders={orders}
        patients={patients}
        treatments={treatments}
        capabilities={capabilities}
        onConfirmSchedule={(occurrenceId, stationId, date, startTime, durationMinutes) => {
          executeAllocationAssignment(occurrenceId, stationId, date, startTime, durationMinutes);
        }}
      />

      {/* 3. Allocation Details & Lifecycle Drawer */}
      <AllocationDetailsModal
        key={`${selectedAllocationId ?? 'none'}-${isDetailsOpen}`}
        isOpen={isDetailsOpen}
        onClose={() => setIsDetailsOpen(false)}
        allocation={selectedAllocation}
        patient={selectedPatient}
        treatment={selectedTreatment}
        station={selectedStation}
        stationType={selectedStationType}
        order={selectedOrder}
        occurrence={selectedOcc}
        roster={selectedRoster}
        plannedPractitioner={plannedPractitioner}
        actualPractitioner={actualPractitioner}
        backupPractitioner={backupPractitioner}
        allPractitioners={practitioners}
        allStations={stations}
        capabilities={capabilities}
        history={history}
        onUpdateStatus={(allocationId, newStatus, notes) => {
          therapyService.updateAllocationStatus(allocationId, newStatus, notes, 'Clinical Supervisor');
          showToast(`Status updated to ${newStatus}.`, 'success');
        }}
        onReschedule={(allocationId, newStationId, newDate, newStartTime, newDuration, overrideReason) => {
          if (selectedAllocation) {
            executeAllocationAssignment(
              selectedAllocation.treatmentOccurrenceId,
              newStationId,
              newDate,
              newStartTime,
              newDuration,
              allocationId,
              overrideReason
            );
          }
        }}
        onReturnToUnscheduled={(allocationId, reason) => {
          therapyService.returnToUnscheduled(allocationId, reason, 'Clinical Supervisor');
          showToast('Allocation returned to unscheduled queue.', 'info');
        }}
        onTakeoverByBackup={(allocationId, backupPractitionerId, reason) => {
          therapyService.recordBackupTakeover(allocationId, backupPractitionerId, reason, 'Clinical Supervisor');
          showToast('Backup practitioner handover recorded as active care provider.', 'success');
        }}
      />

      {/* 4. Conflict & Supervisor Override Dialog */}
      <ConflictDialog
        isOpen={conflictDialogOpen}
        onClose={() => setConflictDialogOpen(false)}
        validationResult={conflictResult}
        onConfirmOverride={(reason) => {
          setConflictDialogOpen(false);
          if (pendingAction) {
            pendingAction(reason);
            setPendingAction(null);
          }
        }}
      />
    </div>
  );
}
