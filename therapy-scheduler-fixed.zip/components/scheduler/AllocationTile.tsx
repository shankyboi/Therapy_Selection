import React, { useState } from 'react';
import {
  TreatmentAllocation,
  Patient,
  Treatment,
  Station,
  Practitioner,
  TreatmentOrder,
  TreatmentOccurrence,
  StationTreatmentCapability,
} from '@/types/therapy';
import { AllocationStatusBadge } from '@/components/StatusBadge';
import { timeToMinutes } from '@/lib/validation';
import { User, Clock, GripVertical, AlertTriangle } from 'lucide-react';
import { therapyService } from '@/services/therapyService';

interface AllocationTileProps {
  allocation: TreatmentAllocation;
  patient?: Patient;
  treatment?: Treatment;
  station?: Station;
  order?: TreatmentOrder;
  occurrence?: TreatmentOccurrence;
  capability?: StationTreatmentCapability;
  plannedPractitioner?: Practitioner;
  actualPractitioner?: Practitioner;
  primaryPractitioner?: Practitioner;
  backupPractitioner?: Practitioner;
  topOffsetPx: number;
  heightPx: number;
  subColIndex: number;
  totalSubCols: number;
  pixelsPerMinute: number;
  onClick: () => void;
  onDragStart: (e: React.DragEvent, allocation: TreatmentAllocation) => void;
  onResizeDuration: (allocation: TreatmentAllocation, deltaMinutes: number) => void;
}

export function AllocationTile({
  allocation,
  patient,
  treatment,
  station,
  order,
  occurrence,
  capability,
  plannedPractitioner,
  actualPractitioner,
  primaryPractitioner,
  backupPractitioner,
  topOffsetPx,
  heightPx,
  subColIndex,
  totalSubCols,
  pixelsPerMinute,
  onClick,
  onDragStart,
  onResizeDuration,
}: AllocationTileProps) {
  const [isHovered, setIsHovered] = useState(false);

  // Sub-column layout math for parallel allocations on multi-capacity stations
  const widthPercent = 100 / totalSubCols;
  const leftPercent = subColIndex * widthPercent;

  const durationMinutes =
    timeToMinutes(allocation.plannedEnd) - timeToMinutes(allocation.plannedStart);

  // Priority color accents
  const priority = order?.priority || 'NORMAL';
  const getPriorityAccent = () => {
    switch (priority) {
      case 'URGENT':
        return 'border-l-4 border-l-rose-500 bg-rose-50/70 hover:bg-rose-50';
      case 'HIGH':
        return 'border-l-4 border-l-amber-500 bg-amber-50/70 hover:bg-amber-50';
      case 'NORMAL':
        return 'border-l-4 border-l-teal-500 bg-teal-50/70 hover:bg-teal-50';
      case 'LOW':
        return 'border-l-4 border-l-slate-400 bg-slate-50/70 hover:bg-slate-50';
      default:
        return 'border-l-4 border-l-slate-300 bg-slate-50';
    }
  };

  const isCancelled = allocation.status === 'CANCELLED';
  const isCompleted = allocation.status === 'COMPLETED';

  // Get all variations/notes as list
  const getVariationsList = (): string[] => {
    const list: string[] = [];
    if (treatment?.variations && Array.isArray(treatment.variations)) {
      treatment.variations.forEach((v) => {
        if (v && v !== 'Default Protocol') {
          list.push(v);
        }
      });
    }
    if (order?.instructions) {
      const match = order.instructions.match(/Variations:\s*([^.]+)/i);
      if (match && match[1]) {
        const parts = match[1]
          .split(',')
          .map((p) => p.trim())
          .filter((p) => p.length > 0 && p !== 'Default Protocol');
        parts.forEach((p) => {
          if (!list.includes(p)) {
            list.push(p);
          }
        });
      }
    }
    return list;
  };
  const variationsList = getVariationsList();

  return (
    <div
      id={`alloc-tile-${allocation.id}`}
      draggable={!isCancelled && !isCompleted}
      onDragStart={(e) => onDragStart(e, allocation)}
      onClick={onClick}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      style={{
        top: `${topOffsetPx}px`,
        height: `${Math.max(38, heightPx - 2)}px`,
        left: `calc(${leftPercent}% + 2px)`,
        width: `calc(${widthPercent}% - 4px)`,
      }}
      className={`absolute z-20 rounded-lg shadow-xs border border-slate-200 transition-all cursor-pointer select-none ${getPriorityAccent()} ${
        isCancelled ? 'opacity-50 grayscale line-through' : ''
      } ${isHovered ? 'shadow-md ring-2 ring-teal-500/50 z-30' : ''}`}
      title={`${patient?.displayName || 'Patient'} - ${treatment?.name} (${allocation.plannedStart}-${allocation.plannedEnd})`}
    >
      {/* Inner bounded content */}
      <div className="absolute inset-0 rounded-lg overflow-hidden flex flex-col justify-between p-1.5 bg-white/40">
        
        {/* Top row: Patient Name (Left) + Timings (Right) */}
        <div className="flex items-start justify-between gap-1.5 leading-none">
          <div className="font-bold text-slate-950 text-[11px] truncate flex items-center gap-0.5">
            <span className="truncate">{patient?.displayName || 'Unknown Patient'}</span>
            {patient?.age && (
              <span className="text-[9px] text-slate-500 font-normal shrink-0">({patient.age})</span>
            )}
          </div>

          <div className="flex items-center gap-0.5 text-slate-700 font-semibold text-[9px] font-mono shrink-0 bg-slate-100/90 border border-slate-200/50 px-1 py-0.5 rounded leading-none">
            <span>{allocation.plannedStart} - {allocation.plannedEnd}</span>
          </div>
        </div>

        {/* Middle row: Therapy Name + Variations */}
        <div className="my-1.5 min-w-0 flex flex-wrap items-center gap-1 w-full overflow-y-auto max-h-[36px] no-scrollbar">
          <span className="text-[11px] font-bold text-teal-900 mr-1 shrink-0 leading-tight">
            {treatment?.name || 'Treatment'}
          </span>
          {variationsList.map((variation, vIdx) => (
            <span
              key={vIdx}
              className="text-[8px] font-bold bg-teal-50/80 text-teal-700 border border-teal-200/50 rounded px-1.5 py-0.5 whitespace-nowrap leading-none select-none"
            >
              {variation}
            </span>
          ))}
        </div>

        {/* Footer Info: Practitioner & Status */}
        <div className="flex items-center justify-between gap-1 pt-1 border-t border-slate-200 mt-auto text-[9px] w-full">
          <div className="flex items-center gap-0.5 min-w-0 flex-1 relative z-30">
            <User className="w-2.5 h-2.5 text-slate-400 shrink-0" />
            {primaryPractitioner || backupPractitioner ? (
              <select
                id={`practitioner-select-${allocation.id}`}
                value={
                  allocation.actualPractitionerId ||
                  allocation.plannedPractitionerId ||
                  primaryPractitioner?.id ||
                  ''
                }
                onChange={(e) => {
                  e.stopPropagation();
                  const val = e.target.value;
                  therapyService.updateAllocation(allocation.id, {
                    actualPractitionerId: val || undefined,
                    plannedPractitionerId: val || undefined,
                  });
                }}
                onClick={(e) => {
                  // Prevent opening the details popup
                  e.stopPropagation();
                }}
                className="bg-transparent border-none text-slate-800 hover:text-slate-950 font-bold text-[9px] p-0 pr-3 leading-none focus:outline-hidden focus:ring-0 cursor-pointer min-w-0 w-full truncate font-sans select-none"
              >
                {primaryPractitioner && (
                  <option value={primaryPractitioner.id} className="text-slate-800 font-semibold bg-white text-[10px]">
                    {primaryPractitioner.displayName}
                  </option>
                )}
                {backupPractitioner && (
                  <option value={backupPractitioner.id} className="text-slate-800 font-semibold bg-white text-[10px]">
                    {backupPractitioner.displayName} (Backup)
                  </option>
                )}
              </select>
            ) : (
              <span className="truncate text-slate-700 font-semibold leading-none">
                {actualPractitioner
                  ? actualPractitioner.displayName
                  : plannedPractitioner
                  ? plannedPractitioner.displayName
                  : 'Unassigned'}
              </span>
            )}
          </div>

          {allocation.status !== 'CONFIRMED' && (
            <div className="shrink-0">
              <AllocationStatusBadge status={allocation.status} />
            </div>
          )}
        </div>

        {/* Resize handles when hovered */}
        {isHovered && !isCancelled && !isCompleted && (
          <div
            className="absolute bottom-0 inset-x-0 h-2 bg-teal-600/30 hover:bg-teal-600 cursor-ns-resize flex items-center justify-center transition-colors"
            title="Drag to resize duration (+/- 15 mins)"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex gap-1">
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onResizeDuration(allocation, -15);
                }}
                className="text-[8px] bg-white text-slate-700 px-1 rounded shadow-xs hover:bg-slate-100 font-bold"
                title="Shrink by 15 mins"
              >
                -15m
              </button>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onResizeDuration(allocation, 15);
                }}
                className="text-[8px] bg-white text-slate-700 px-1 rounded shadow-xs hover:bg-slate-100 font-bold"
                title="Extend by 15 mins"
              >
                +15m
              </button>
            </div>
          </div>
        )}
      </div>

      {/* 10-minute Preparation Buffer Extension */}
      {!isCancelled && (
        <div
          style={{
            position: 'absolute',
            bottom: `-${10 * pixelsPerMinute}px`,
            height: `${10 * pixelsPerMinute}px`,
            left: 0,
            right: 0,
          }}
          className="absolute z-10 border-r border-l border-b border-dotted border-slate-400 bg-slate-100/90 flex items-center justify-center pointer-events-none select-none rounded-b-md shadow-2xs"
        >
          <span className="text-[9px] text-slate-500 font-bold uppercase tracking-wider px-1 truncate leading-none">
            Preparation
          </span>
        </div>
      )}
    </div>
  );
}
