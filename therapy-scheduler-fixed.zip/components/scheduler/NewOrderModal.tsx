import React, { useState } from 'react';
import { Modal } from '@/components/Modal';
import { Treatment, Patient, PriorityLevel } from '@/types/therapy';
import { getTodayDateString, getRelativeDateString } from '@/lib/sampleData';
import { Plus, UserPlus, FilePlus2, Check } from 'lucide-react';

interface NewOrderModalProps {
  isOpen: boolean;
  onClose: () => void;
  treatments: Treatment[];
  patients: Patient[];
  onCreateOrder: (
    patientData: {
      isNew: boolean;
      existingPatientId?: string;
      displayName: string;
      gender: 'MALE' | 'FEMALE' | 'OTHER';
      age: number;
      department: string;
      precautions?: string;
    },
    orderData: {
      treatmentId: string;
      totalSessions: number;
      earliestAllowedDate: string;
      latestAllowedDate: string;
      priority: PriorityLevel;
      instructions: string;
    }
  ) => void;
}

export function NewOrderModal({
  isOpen,
  onClose,
  treatments,
  patients,
  onCreateOrder,
}: NewOrderModalProps) {
  const today = getTodayDateString();
  const defaultLatest = getRelativeDateString(14);

  const [useExistingPatient, setUseExistingPatient] = useState(true);
  const [selectedPatientId, setSelectedPatientId] = useState(patients[0]?.id || '');

  // New patient fields
  const [patientName, setPatientName] = useState('');
  const [gender, setGender] = useState<'MALE' | 'FEMALE' | 'OTHER'>('MALE');
  const [age, setAge] = useState(45);
  const [department, setDepartment] = useState('Physiotherapy');
  const [precautions, setPrecautions] = useState('');

  // Order fields
  const [treatmentId, setTreatmentId] = useState(treatments[0]?.id || '');
  const [totalSessions, setTotalSessions] = useState(6);
  const [priority, setPriority] = useState<PriorityLevel>('NORMAL');
  const [earliestDate, setEarliestDate] = useState(today);
  const [latestDate, setLatestDate] = useState(defaultLatest);
  const [instructions, setInstructions] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    let patData;
    if (useExistingPatient) {
      const existing = patients.find((p) => p.id === selectedPatientId);
      if (!existing) return;
      patData = {
        isNew: false,
        existingPatientId: existing.id,
        displayName: existing.displayName,
        gender: existing.gender,
        age: existing.age,
        department: existing.department,
        precautions: existing.precautions,
      };
    } else {
      patData = {
        isNew: true,
        displayName: patientName,
        gender,
        age: Number(age),
        department,
        precautions,
      };
    }

    onCreateOrder(patData, {
      treatmentId,
      totalSessions: Number(totalSessions),
      earliestAllowedDate: earliestDate,
      latestAllowedDate: latestDate,
      priority,
      instructions,
    });

    onClose();
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="Receive External Patient Treatment Order"
      subtitle="Ingest electronic health record (EHR) treatment prescription into the unscheduled pool"
      maxWidthClass="max-w-xl"
    >
      <form onSubmit={handleSubmit} className="space-y-4">
        {/* Patient Selection Tabs */}
        <div className="space-y-2">
          <label className="text-xs font-semibold text-slate-700 block">Patient Association</label>
          <div className="flex rounded-lg border border-slate-200 p-0.5 bg-slate-100">
            <button
              type="button"
              onClick={() => setUseExistingPatient(true)}
              className={`flex-1 py-1.5 text-xs font-semibold rounded-md transition-colors ${
                useExistingPatient
                  ? 'bg-white text-teal-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Existing Registered Patient
            </button>
            <button
              type="button"
              onClick={() => setUseExistingPatient(false)}
              className={`flex-1 py-1.5 text-xs font-semibold rounded-md transition-colors ${
                !useExistingPatient
                  ? 'bg-white text-teal-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              New Patient Intake
            </button>
          </div>
        </div>

        {useExistingPatient ? (
          <div>
            <label className="block text-xs font-medium text-slate-600 mb-1">
              Select Patient:
            </label>
            <select
              value={selectedPatientId}
              onChange={(e) => setSelectedPatientId(e.target.value)}
              className="w-full text-xs p-2 bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-teal-500"
            >
              {patients.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.displayName} ({p.externalPatientId} • {p.gender}, {p.age}y • {p.department})
                </option>
              ))}
            </select>
          </div>
        ) : (
          <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg space-y-3">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div>
                <label className="block text-slate-600 font-medium mb-1">Patient Full Name:</label>
                <input
                  type="text"
                  required
                  value={patientName}
                  onChange={(e) => setPatientName(e.target.value)}
                  placeholder="e.g. Ramesh Kulkarni"
                  className="w-full p-2 bg-white border border-slate-300 rounded-md focus:ring-2 focus:ring-teal-500"
                />
              </div>

              <div>
                <label className="block text-slate-600 font-medium mb-1">Department:</label>
                <input
                  type="text"
                  value={department}
                  onChange={(e) => setDepartment(e.target.value)}
                  placeholder="Physiotherapy"
                  className="w-full p-2 bg-white border border-slate-300 rounded-md focus:ring-2 focus:ring-teal-500"
                />
              </div>

              <div>
                <label className="block text-slate-600 font-medium mb-1">Gender:</label>
                <select
                  value={gender}
                  onChange={(e) => setGender(e.target.value as any)}
                  className="w-full p-2 bg-white border border-slate-300 rounded-md"
                >
                  <option value="MALE">Male</option>
                  <option value="FEMALE">Female</option>
                  <option value="OTHER">Other</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-600 font-medium mb-1">Age:</label>
                <input
                  type="number"
                  min="1"
                  max="120"
                  value={age}
                  onChange={(e) => setAge(Number(e.target.value))}
                  className="w-full p-2 bg-white border border-slate-300 rounded-md"
                />
              </div>
            </div>

            <div>
              <label className="block text-slate-600 font-medium mb-1 text-xs">
                Clinical Precautions / Allergies:
              </label>
              <input
                type="text"
                value={precautions}
                onChange={(e) => setPrecautions(e.target.value)}
                placeholder="e.g. Pacemaker implanted, avoid high frequency electrotherapy"
                className="w-full text-xs p-2 bg-white border border-slate-300 rounded-md"
              />
            </div>
          </div>
        )}

        {/* Treatment Prescription Details */}
        <div className="space-y-3 pt-2 border-t border-slate-100">
          <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider">
            Prescription Details
          </h4>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
            <div>
              <label className="block font-medium text-slate-700 mb-1">Prescribed Modality:</label>
              <select
                value={treatmentId}
                onChange={(e) => setTreatmentId(e.target.value)}
                className="w-full p-2 bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-teal-500"
              >
                {treatments.map((t) => (
                  <option key={t.id} value={t.id}>
                    {t.name} (Default {t.defaultDurationMinutes} mins)
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block font-medium text-slate-700 mb-1">Priority Triage:</label>
              <select
                value={priority}
                onChange={(e) => setPriority(e.target.value as PriorityLevel)}
                className="w-full p-2 bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-teal-500"
              >
                <option value="URGENT">Urgent (Red Alert)</option>
                <option value="HIGH">High Priority (Orange)</option>
                <option value="NORMAL">Normal Priority (Blue)</option>
                <option value="LOW">Low Priority (Grey)</option>
              </select>
            </div>

            <div>
              <label className="block font-medium text-slate-700 mb-1">Total Prescribed Sessions:</label>
              <input
                type="number"
                min="1"
                max="50"
                value={totalSessions}
                onChange={(e) => setTotalSessions(Number(e.target.value))}
                className="w-full p-2 bg-white border border-slate-300 rounded-lg"
              />
            </div>

            <div>
              <label className="block font-medium text-slate-700 mb-1">Earliest Start Date:</label>
              <input
                type="date"
                value={earliestDate}
                onChange={(e) => setEarliestDate(e.target.value)}
                className="w-full p-2 bg-white border border-slate-300 rounded-lg"
              />
            </div>

            <div className="sm:col-span-2">
              <label className="block font-medium text-slate-700 mb-1">Latest Allowed Completion:</label>
              <input
                type="date"
                value={latestDate}
                onChange={(e) => setLatestDate(e.target.value)}
                className="w-full p-2 bg-white border border-slate-300 rounded-lg"
              />
            </div>

            <div className="sm:col-span-2">
              <label className="block font-medium text-slate-700 mb-1">
                Doctor Instructions & Protocols:
              </label>
              <textarea
                rows={2}
                value={instructions}
                onChange={(e) => setInstructions(e.target.value)}
                placeholder="Specific anatomical targets, joint glides, or intensity parameters..."
                className="w-full p-2 bg-white border border-slate-300 rounded-lg text-xs"
              />
            </div>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="flex justify-end gap-2 pt-3 border-t border-slate-200">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-lg transition-colors"
          >
            Cancel
          </button>
          <button
            id="btn-submit-new-order"
            type="submit"
            className="px-4 py-2 text-xs font-semibold bg-teal-600 hover:bg-teal-700 text-white rounded-lg shadow-xs flex items-center gap-1.5 transition-colors"
          >
            <Plus className="w-4 h-4" />
            <span>Create Order & Add to Unscheduled Pool</span>
          </button>
        </div>
      </form>
    </Modal>
  );
}
