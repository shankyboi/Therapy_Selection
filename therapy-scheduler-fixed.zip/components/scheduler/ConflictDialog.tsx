import React, { useState } from 'react';
import { Modal } from '@/components/Modal';
import { ValidationResult } from '@/types/therapy';
import { AlertOctagon, AlertTriangle, Info, CheckCircle2, ShieldAlert, UserCheck } from 'lucide-react';

interface ConflictDialogProps {
  isOpen: boolean;
  onClose: () => void;
  validationResult: ValidationResult | null;
  onConfirmOverride?: (overrideReason: string, overriddenBy: string) => void;
  candidateSummary?: {
    patientName: string;
    treatmentName: string;
    stationName: string;
    date: string;
    plannedStart: string;
    plannedEnd: string;
  };
}

export function ConflictDialog({
  isOpen,
  onClose,
  validationResult,
  onConfirmOverride,
  candidateSummary,
}: ConflictDialogProps) {
  const [overrideReason, setOverrideReason] = useState('');
  const [overriddenBy, setOverriddenBy] = useState('Dr. Supervisor');

  if (!validationResult) return null;

  const hasBlockingErrors = validationResult.errors.length > 0;
  const canOverride = !hasBlockingErrors && validationResult.hasWarnings && onConfirmOverride;

  const handleOverrideSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!overrideReason.trim()) {
      alert('Please provide an override reason to proceed.');
      return;
    }
    onConfirmOverride?.(overrideReason, overriddenBy);
    setOverrideReason('');
    onClose();
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={hasBlockingErrors ? 'Scheduling Validation Error' : 'Clinical Override Required'}
      subtitle={
        hasBlockingErrors
          ? 'This allocation violates strict medical or capacity constraints and cannot be saved.'
          : 'Potential operational warnings detected. You may override with clinical justification.'
      }
      maxWidthClass="max-w-xl"
    >
      <div className="space-y-4">
        {/* Candidate Target Summary */}
        {candidateSummary && (
          <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 text-xs flex flex-wrap gap-x-4 gap-y-1">
            <div>
              <span className="text-slate-500 font-medium">Patient: </span>
              <strong className="text-slate-800">{candidateSummary.patientName}</strong>
            </div>
            <div>
              <span className="text-slate-500 font-medium">Treatment: </span>
              <strong className="text-slate-800">{candidateSummary.treatmentName}</strong>
            </div>
            <div>
              <span className="text-slate-500 font-medium">Target Station: </span>
              <strong className="text-slate-800">{candidateSummary.stationName}</strong>
            </div>
            <div>
              <span className="text-slate-500 font-medium">Time: </span>
              <strong className="text-slate-800">
                {candidateSummary.date} ({candidateSummary.plannedStart} - {candidateSummary.plannedEnd})
              </strong>
            </div>
          </div>
        )}

        {/* Blocking Errors */}
        {validationResult.errors.length > 0 && (
          <div className="space-y-2">
            <div className="flex items-center gap-1.5 text-rose-700 text-xs font-bold uppercase tracking-wider">
              <AlertOctagon className="w-4 h-4 text-rose-600" />
              <span>Blocking Violations ({validationResult.errors.length})</span>
            </div>
            <div className="space-y-2">
              {validationResult.errors.map((err, idx) => (
                <div
                  key={idx}
                  className="p-3 bg-rose-50 border border-rose-200 rounded-lg text-rose-900 space-y-1"
                >
                  <div className="flex items-start gap-2 font-semibold text-xs text-rose-800">
                    <span className="w-1.5 h-1.5 rounded-full bg-rose-500 mt-1.5 shrink-0" />
                    <span>{err.message}</span>
                  </div>
                  {err.details && (
                    <p className="text-[11px] text-rose-700 pl-3.5 leading-relaxed">{err.details}</p>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Warnings */}
        {validationResult.warnings.length > 0 && (
          <div className="space-y-2">
            <div className="flex items-center gap-1.5 text-amber-700 text-xs font-bold uppercase tracking-wider">
              <AlertTriangle className="w-4 h-4 text-amber-600" />
              <span>Warnings ({validationResult.warnings.length})</span>
            </div>
            <div className="space-y-2">
              {validationResult.warnings.map((warn, idx) => (
                <div
                  key={idx}
                  className="p-3 bg-amber-50 border border-amber-200 rounded-lg text-amber-900 space-y-1"
                >
                  <div className="flex items-start gap-2 font-semibold text-xs text-amber-800">
                    <span className="w-1.5 h-1.5 rounded-full bg-amber-500 mt-1.5 shrink-0" />
                    <span>{warn.message}</span>
                  </div>
                  {warn.details && (
                    <p className="text-[11px] text-amber-700 pl-3.5 leading-relaxed">{warn.details}</p>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Guidance Info */}
        {validationResult.infos.length > 0 && (
          <div className="space-y-1.5">
            <div className="flex items-center gap-1.5 text-sky-700 text-xs font-bold uppercase tracking-wider">
              <Info className="w-4 h-4 text-sky-600" />
              <span>Guidance</span>
            </div>
            {validationResult.infos.map((info, idx) => (
              <div
                key={idx}
                className="p-2.5 bg-sky-50 border border-sky-200 rounded-lg text-sky-800 text-xs flex items-center gap-2"
              >
                <Info className="w-3.5 h-3.5 text-sky-600 shrink-0" />
                <span>{info.message}</span>
              </div>
            ))}
          </div>
        )}

        {/* Override Form */}
        {canOverride && (
          <form onSubmit={handleOverrideSubmit} className="mt-4 pt-4 border-t border-slate-200 space-y-3">
            <div className="flex items-center gap-2 text-slate-800 text-xs font-semibold">
              <ShieldAlert className="w-4 h-4 text-teal-600" />
              <span>Supervisor Override Authorisation</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1">
                  Authorised By <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={overriddenBy}
                  onChange={(e) => setOverriddenBy(e.target.value)}
                  className="w-full text-xs px-3 py-2 border border-slate-300 rounded-md focus:ring-2 focus:ring-teal-500 focus:border-teal-500"
                  placeholder="e.g. Dr. Asha Rao (Head of PT)"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1">
                  Override Justification / Reason <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={overrideReason}
                  onChange={(e) => setOverrideReason(e.target.value)}
                  className="w-full text-xs px-3 py-2 border border-slate-300 rounded-md focus:ring-2 focus:ring-teal-500 focus:border-teal-500"
                  placeholder="e.g. Urgent post-op exception with extra aide assigned"
                />
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 rounded-lg text-xs font-semibold text-slate-600 hover:bg-slate-100 transition-colors"
              >
                Dismiss
              </button>
              <button
                id="btn-confirm-override"
                type="submit"
                className="px-4 py-2 rounded-lg text-xs font-semibold bg-amber-600 text-white hover:bg-amber-700 active:bg-amber-800 shadow-xs flex items-center gap-1.5 transition-colors"
              >
                <UserCheck className="w-4 h-4" />
                <span>Authorise & Save Override</span>
              </button>
            </div>
          </form>
        )}

        {/* Blocking Error Footer */}
        {hasBlockingErrors && (
          <div className="flex justify-end pt-3 border-t border-slate-200">
            <button
              id="btn-close-conflict"
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-lg text-xs font-semibold bg-slate-800 text-white hover:bg-slate-900 transition-colors"
            >
              Acknowledge & Close
            </button>
          </div>
        )}
      </div>
    </Modal>
  );
}
