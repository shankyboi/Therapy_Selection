'use client';

import React from 'react';
import {
  Station,
  StationType,
  StationPractitionerRoster,
  Practitioner,
  TreatmentAllocation,
  Patient,
  Treatment,
  TreatmentOrder,
  TreatmentOccurrence,
  StationTreatmentCapability,
} from '@/types/therapy';
import { AllocationTile } from './AllocationTile';
import { timeToMinutes } from '@/lib/validation';
import { User, ShieldAlert, BedDouble, AlertCircle, CheckCircle2 } from 'lucide-react';

interface StationColumnProps {
  station: Station;
  stationType?: StationType;
  roster?: StationPractitionerRoster;
  primaryPractitioner?: Practitioner;
  backupPractitioner?: Practitioner;
  allocations: TreatmentAllocation[];
  patients: Patient[];
  treatments: Treatment[];
  orders: TreatmentOrder[];
  occurrences: TreatmentOccurrence[];
  capabilities: StationTreatmentCapability[];
  practitioners: Practitioner[];
  startMinutes: number;
  endMinutes: number;
  intervalMinutes: number;
  pixelsPerMinute: number;
  onSlotClick: (stationId: string, time: string) => void;
  onAllocationClick: (allocation: TreatmentAllocation) => void;
  onDragStartAllocation: (e: React.DragEvent, allocation: TreatmentAllocation) => void;
  onResizeDuration: (allocation: TreatmentAllocation, deltaMinutes: number) => void;
  onDropTarget: (stationId: string, time: string) => void;
}

export function StationColumn({
  station,
  stationType,
  roster,
  primaryPractitioner,
  backupPractitioner,
  allocations,
  patients,
  treatments,
  orders,
  occurrences,
  capabilities,
  practitioners,
  startMinutes,
  endMinutes,
  intervalMinutes,
  pixelsPerMinute,
  onSlotClick,
  onAllocationClick,
  onDragStartAllocation,
  onResizeDuration,
  onDropTarget,
}: StationColumnProps) {
  // Calculate overlapping groups to render side-by-side on multi-capacity stations
  const activeAllocations = allocations.filter((a) => a.status !== 'CANCELLED');
  const cancelledAllocations = allocations.filter((a) => a.status === 'CANCELLED');

  // Compute parallel columns for overlapping active allocations
  interface PositionedAlloc {
    allocation: TreatmentAllocation;
    top: number;
    height: number;
    subCol: number;
    totalSubCols: number;
  }

  const positionedList: PositionedAlloc[] = [];

  // Sort by start time, then longer duration first (including preparation)
  const sorted = [...activeAllocations].sort((a, b) => {
    const diff = timeToMinutes(a.plannedStart) - timeToMinutes(b.plannedStart);
    if (diff !== 0) return diff;
    return (
      (timeToMinutes(b.plannedEnd) + 10) -
      timeToMinutes(b.plannedStart) -
      ((timeToMinutes(a.plannedEnd) + 10) - timeToMinutes(a.plannedStart))
    );
  });

  // Group overlapping items including preparation
  const clusters: TreatmentAllocation[][] = [];
  let currentCluster: TreatmentAllocation[] = [];
  let clusterEnd = -1;

  for (const alloc of sorted) {
    const aStart = timeToMinutes(alloc.plannedStart);
    const aEndWithPrep = timeToMinutes(alloc.plannedEnd) + 10;

    if (currentCluster.length === 0 || aStart < clusterEnd) {
      currentCluster.push(alloc);
      clusterEnd = Math.max(clusterEnd, aEndWithPrep);
    } else {
      clusters.push(currentCluster);
      currentCluster = [alloc];
      clusterEnd = aEndWithPrep;
    }
  }
  if (currentCluster.length > 0) {
    clusters.push(currentCluster);
  }

  // Assign sub-columns within each cluster
  for (const cluster of clusters) {
    const subColTracks: number[] = []; // tracks end time of each subCol (including preparation)
    const clusterAllocAssignments: { alloc: TreatmentAllocation; subCol: number }[] = [];

    for (const alloc of cluster) {
      const aStart = timeToMinutes(alloc.plannedStart);
      const aEndWithPrep = timeToMinutes(alloc.plannedEnd) + 10;

      let placed = false;
      for (let i = 0; i < subColTracks.length; i++) {
        if (subColTracks[i] <= aStart) {
          subColTracks[i] = aEndWithPrep;
          clusterAllocAssignments.push({ alloc, subCol: i });
          placed = true;
          break;
        }
      }
      if (!placed) {
        subColTracks.push(aEndWithPrep);
        clusterAllocAssignments.push({ alloc, subCol: subColTracks.length - 1 });
      }
    }

    const totalSubCols = Math.max(1, subColTracks.length);

    for (const { alloc, subCol } of clusterAllocAssignments) {
      const aStart = timeToMinutes(alloc.plannedStart);
      const aEnd = timeToMinutes(alloc.plannedEnd);
      const top = (aStart - startMinutes) * pixelsPerMinute;
      const height = (aEnd - aStart) * pixelsPerMinute;

      positionedList.push({
        allocation: alloc,
        top,
        height,
        subCol,
        totalSubCols,
      });
    }
  }

  // Also include cancelled allocations (stacked with 1 sub-col at reduced height)
  for (const alloc of cancelledAllocations) {
    const aStart = timeToMinutes(alloc.plannedStart);
    const aEnd = timeToMinutes(alloc.plannedEnd);
    positionedList.push({
      allocation: alloc,
      top: (aStart - startMinutes) * pixelsPerMinute,
      height: (aEnd - aStart) * pixelsPerMinute,
      subCol: 0,
      totalSubCols: 1,
    });
  }

  const hasNoPractitioner = !primaryPractitioner;
  const isMultiCapacity = station.capacity > 1;

  // Generate grid slot markers
  const totalMinutes = endMinutes - startMinutes;
  const totalSlots = totalMinutes / intervalMinutes;
  const slotElements = [];

  for (let i = 0; i < totalSlots; i++) {
    const slotStartMins = startMinutes + i * intervalMinutes;
    const h = Math.floor(slotStartMins / 60);
    const m = slotStartMins % 60;
    const timeStr = `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`;

    slotElements.push(
      <div
        key={`slot-${timeStr}`}
        id={`slot-${station.id}-${timeStr}`}
        style={{ height: `${intervalMinutes * pixelsPerMinute}px` }}
        onClick={() => onSlotClick(station.id, timeStr)}
        onDragOver={(e) => {
          e.preventDefault();
          e.dataTransfer.dropEffect = 'move';
        }}
        onDrop={(e) => {
          e.preventDefault();
          onDropTarget(station.id, timeStr);
        }}
        className="border-b border-slate-100 hover:bg-teal-50/40 transition-colors cursor-pointer relative group flex items-start p-1"
      >
        <span className="text-[9px] text-slate-300 group-hover:text-teal-600 font-mono opacity-0 group-hover:opacity-100 transition-opacity">
          +{timeStr}
        </span>
      </div>
    );
  }

  return (
    <div
      id={`station-col-${station.id}`}
      className="flex-1 min-w-[220px] max-w-[320px] border-r border-slate-200 bg-white flex flex-col relative"
    >
      {/* Sticky Station Header */}
      <div className="sticky top-0 z-30 bg-slate-50 border-b border-slate-200 p-2 shadow-xs h-[89px] flex flex-col justify-between select-none">
        {/* Compact Room Name */}
        <div className="flex items-center gap-1 min-w-0">
          <BedDouble className="w-3.5 h-3.5 text-teal-700 shrink-0" />
          <span className="font-bold text-[11px] text-slate-900 truncate" title={station.name}>
            {station.name}
          </span>
        </div>

        {/* Primary & Backup Doctors (Super compact) */}
        <div className="text-[10px] leading-tight">
          {hasNoPractitioner ? (
            <div
              className="flex items-center gap-1 text-amber-700 bg-amber-50 px-1 py-0.5 rounded border border-amber-200 font-semibold"
              title="Warning: No primary practitioner rostered today for this room!"
            >
              <AlertCircle className="w-2.5 h-2.5 text-amber-600 shrink-0" />
              <span className="truncate">No Doctor</span>
            </div>
          ) : (
            <div className="space-y-0.5">
              <div className="flex items-center gap-1 text-slate-800 font-bold truncate">
                <span className="w-1.5 h-1.5 rounded-full bg-teal-500 shrink-0" />
                <span className="truncate">{primaryPractitioner?.displayName}</span>
              </div>
              {backupPractitioner ? (
                <div className="flex items-center gap-1 text-slate-500 text-[9px] font-medium truncate">
                  <span className="w-1.5 h-1.5 rounded-full bg-slate-300 shrink-0" />
                  <span className="truncate">Backup: {backupPractitioner.displayName}</span>
                </div>
              ) : (
                <div className="text-[9px] text-slate-400 italic font-medium truncate pl-2.5">
                  No backup doctor
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Grid Canvas with Slot Markers & Absolute Allocation Tiles */}
      <div
        className="relative flex-1 bg-repeat"
        style={{ height: `${totalMinutes * pixelsPerMinute}px` }}
      >
        {/* Background Clickable Slots */}
        {slotElements}

        {/* Positioned Allocation Tiles */}
        {positionedList.map(
          ({ allocation, top, height, subCol, totalSubCols }) => {
            const occ = occurrences.find((o) => o.id === allocation.treatmentOccurrenceId);
            const ord = occ ? orders.find((o) => o.id === occ.treatmentOrderId) : undefined;
            const pat = ord ? patients.find((p) => p.id === ord.patientId) : undefined;
            const treat = ord ? treatments.find((t) => t.id === ord.treatmentId) : undefined;
            const cap =
              ord && treat
                ? capabilities.find(
                    (c) => c.stationId === station.id && c.treatmentId === ord.treatmentId
                  )
                : undefined;
            const plannedPrac = allocation.plannedPractitionerId
              ? practitioners.find((p) => p.id === allocation.plannedPractitionerId)
              : primaryPractitioner;
            const actualPrac = allocation.actualPractitionerId
              ? practitioners.find((p) => p.id === allocation.actualPractitionerId)
              : undefined;

            return (
              <AllocationTile
                key={allocation.id}
                allocation={allocation}
                patient={pat}
                treatment={treat}
                station={station}
                order={ord}
                occurrence={occ}
                capability={cap}
                plannedPractitioner={plannedPrac}
                actualPractitioner={actualPrac}
                primaryPractitioner={primaryPractitioner}
                backupPractitioner={backupPractitioner}
                topOffsetPx={top}
                heightPx={height}
                subColIndex={subCol}
                totalSubCols={totalSubCols}
                pixelsPerMinute={pixelsPerMinute}
                onClick={() => onAllocationClick(allocation)}
                onDragStart={onDragStartAllocation}
                onResizeDuration={onResizeDuration}
              />
            );
          }
        )}
      </div>
    </div>
  );
}
