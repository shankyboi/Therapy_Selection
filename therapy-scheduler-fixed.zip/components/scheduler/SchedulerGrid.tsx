'use client';

import React, { useState, useEffect } from 'react';
import {
  Station,
  StationType,
  StationPractitionerRoster,
  Practitioner,
  TreatmentAllocation,
  Patient,
  Treatment,
  TreatmentOrder,
  TreatmentOccurrence,
  StationTreatmentCapability,
} from '@/types/therapy';
import { StationColumn } from './StationColumn';
import { timeToMinutes, minutesToTime } from '@/lib/validation';
import { getTodayDateString } from '@/lib/sampleData';
import {
  ZoomIn,
  ZoomOut,
  Clock,
  Filter,
  RefreshCw,
  Search,
  SlidersHorizontal,
  ChevronDown,
  FileText,
} from 'lucide-react';

interface SchedulerGridProps {
  selectedDate: string;
  stations: Station[];
  stationTypes: StationType[];
  rosters: StationPractitionerRoster[];
  practitioners: Practitioner[];
  allocations: TreatmentAllocation[];
  patients: Patient[];
  treatments: Treatment[];
  orders: TreatmentOrder[];
  occurrences: TreatmentOccurrence[];
  capabilities: StationTreatmentCapability[];
  onSlotClick: (stationId: string, time: string) => void;
  onAllocationClick: (allocation: TreatmentAllocation) => void;
  onDragStartAllocation: (e: React.DragEvent, allocation: TreatmentAllocation) => void;
  onResizeDuration: (allocation: TreatmentAllocation, deltaMinutes: number) => void;
  onDropTarget: (stationId: string, time: string) => void;
  onPixelsPerMinuteChange?: (ppm: number) => void;
}

export function SchedulerGrid({
  selectedDate,
  stations,
  stationTypes,
  rosters,
  practitioners,
  allocations,
  patients,
  treatments,
  orders,
  occurrences,
  capabilities,
  onSlotClick,
  onAllocationClick,
  onDragStartAllocation,
  onResizeDuration,
  onDropTarget,
  onPixelsPerMinuteChange,
}: SchedulerGridProps) {
  // Zoom & Interval setting (15, 30, 60 minutes interval display)
  const [zoomLevel, setZoomLevel] = useState<'15' | '30' | '60'>('15');
  const [intervalMinutes, setIntervalMinutes] = useState<number>(15);
  const [pixelsPerMinute, setPixelsPerMinute] = useState<number>(1.8); // 15m = 27px, 30m = 54px, 60m = 108px

  useEffect(() => {
    if (onPixelsPerMinuteChange) {
      onPixelsPerMinuteChange(pixelsPerMinute);
    }
  }, [pixelsPerMinute, onPixelsPerMinuteChange]);

  const [isExportingPDF, setIsExportingPDF] = useState(false);
  const [pdfError, setPdfError] = useState<string | null>(null);

  const handleDownloadPDF = async () => {
    if (isExportingPDF) return;
    setIsExportingPDF(true);
    setPdfError(null);
    try {
      const { generateSchedulerPDF } = await import('@/lib/pdfGenerator');
      generateSchedulerPDF({
        selectedDate, stations, stationTypes, rosters, practitioners,
        allocations, patients, treatments, orders, occurrences,
      });
    } catch {
      setPdfError('The PDF could not be generated. Please retry or reload the page.');
    } finally {
      setIsExportingPDF(false);
    }
  };

  // Working hours
  const [startHour, setStartHour] = useState<number>(8); // 08:00
  const [endHour, setEndHour] = useState<number>(18); // 18:00

  // Filters
  const [filterStationTypeId, setFilterStationTypeId] = useState<string>('');
  const [filterStationId, setFilterStationId] = useState<string>('ALL');
  const [filterTreatmentId, setFilterTreatmentId] = useState<string>('ALL');
  const [filterStatus, setFilterStatus] = useState<string>('ALL');

  const activeStationTypeId = filterStationTypeId || stationTypes[0]?.id || '';

  // Current time line calculation
  const [currentTimeMinutes, setCurrentTimeMinutes] = useState<number | null>(null);

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      const mins = now.getHours() * 60 + now.getMinutes();
      setCurrentTimeMinutes(mins);
    };
    updateTime();
    const timer = setInterval(updateTime, 60000);
    return () => clearInterval(timer);
  }, []);

  const handleZoomChange = (level: '15' | '30' | '60') => {
    setZoomLevel(level);
    if (level === '15') {
      setIntervalMinutes(15);
      setPixelsPerMinute(1.8); // 15m = 27px
    } else if (level === '30') {
      setIntervalMinutes(30);
      setPixelsPerMinute(1.2); // 30m = 36px
    } else {
      setIntervalMinutes(60);
      setPixelsPerMinute(0.8); // 60m = 48px
    }
  };

  const startMinutes = startHour * 60;
  const endMinutes = endHour * 60;
  const totalMinutes = endMinutes - startMinutes;

  // Filter stations
  const activeStations = stations.filter((s) => s.isActive);

  const filteredStations = activeStations.filter((st) => {
    if (activeStationTypeId && st.stationTypeId !== activeStationTypeId) return false;
    if (filterStationId !== 'ALL' && st.id !== filterStationId) return false;

    return true;
  });

  // Filter allocations on current date
  const dateAllocations = allocations.filter((a) => a.date === selectedDate);

  // Apply treatment and status filters to allocations
  const filteredAllocations = dateAllocations.filter((a) => {
    if (filterStatus !== 'ALL' && a.status !== filterStatus) return false;

    if (filterTreatmentId !== 'ALL') {
      const occ = occurrences.find((o) => o.id === a.treatmentOccurrenceId);
      const ord = occ ? orders.find((o) => o.id === occ.treatmentOrderId) : null;
      if (ord?.treatmentId !== filterTreatmentId) return false;
    }

    return true;
  });

  // Generate Time Rail labels
  const timeLabels = [];
  for (let m = startMinutes; m <= endMinutes; m += intervalMinutes) {
    const timeStr = minutesToTime(m);
    const isHour = m % 60 === 0;
    timeLabels.push({
      minutes: m,
      timeStr,
      isHour,
      topPx: (m - startMinutes) * pixelsPerMinute,
    });
  }

  const isToday = selectedDate === getTodayDateString();
  const showCurrentTimeLine =
    isToday &&
    currentTimeMinutes !== null &&
    currentTimeMinutes >= startMinutes &&
    currentTimeMinutes <= endMinutes;
  const currentTimeTopPx =
    showCurrentTimeLine && currentTimeMinutes !== null
      ? (currentTimeMinutes - startMinutes) * pixelsPerMinute
      : null;

  return (
    <div id="therapy-scheduler-grid-container" className="flex flex-col flex-1 h-full bg-slate-100 overflow-hidden">
      {/* Top Filter and Controls Bar */}
      <div className="bg-white border-b border-slate-200 px-4 py-2.5 flex flex-wrap items-center justify-between gap-3 shadow-2xs">
        {/* Left: Inline Filters */}
        <div className="flex flex-wrap items-center gap-4 text-xs">
          {/* Room Type Filter */}
          <div className="flex items-center gap-1.5">
            <span className="text-slate-500 font-bold">Room Type:</span>
            <select
              id="filter-station-type"
              value={activeStationTypeId}
              onChange={(e) => setFilterStationTypeId(e.target.value)}
              className="bg-white border border-slate-200 rounded px-2.5 py-1 text-xs text-slate-800 font-semibold focus:outline-hidden focus:border-zinc-400"
            >
              {stationTypes.map((st) => (
                <option key={st.id} value={st.id}>
                  {st.name}
                </option>
              ))}
            </select>
          </div>

          {/* Treatment Filter */}
          <div className="flex items-center gap-1.5">
            <span className="text-slate-500 font-bold">Treatment:</span>
            <select
              id="filter-treatment"
              value={filterTreatmentId}
              onChange={(e) => setFilterTreatmentId(e.target.value)}
              className="bg-white border border-slate-200 rounded px-2.5 py-1 text-xs text-slate-800 font-semibold focus:outline-hidden focus:border-zinc-400"
            >
              <option value="ALL">All Treatments</option>
              {treatments.map((t) => (
                <option key={t.id} value={t.id}>
                  {t.name}
                </option>
              ))}
            </select>
          </div>

          {/* Allocation Status Filter */}
          <div className="flex items-center gap-1.5">
            <span className="text-slate-500 font-bold">Status:</span>
            <select
              id="filter-status"
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
              className="bg-white border border-slate-200 rounded px-2.5 py-1 text-xs text-slate-800 font-semibold focus:outline-hidden focus:border-zinc-400"
            >
              <option value="ALL">All Statuses</option>
              <option value="CONFIRMED">Confirmed</option>
              <option value="CHECKED_IN">Checked In</option>
              <option value="IN_PROGRESS">In Progress</option>
              <option value="COMPLETED">Completed</option>
              <option value="CANCELLED">Cancelled</option>
              <option value="NO_SHOW">No-Show</option>
            </select>
          </div>

          {/* Clear Filters Reset */}
          {(filterStationTypeId !== '' ||
            filterStationId !== 'ALL' ||
            filterTreatmentId !== 'ALL' ||
            filterStatus !== 'ALL') && (
            <button
              onClick={() => {
                setFilterStationTypeId('');
                setFilterStationId('ALL');
                setFilterTreatmentId('ALL');
                setFilterStatus('ALL');
              }}
              className="text-xs text-zinc-600 hover:text-zinc-900 font-bold underline cursor-pointer"
            >
              Reset Filters
            </button>
          )}
        </div>

        {/* Right: Working hours & Zoom interval controls */}
        <div className="flex items-center gap-2">
          {/* Zoom buttons */}
          <div className="flex items-center bg-slate-100 p-0.5 rounded-lg border border-slate-200 text-xs">
            <button
              id="btn-zoom-15"
              onClick={() => handleZoomChange('15')}
              className={`px-2.5 py-1 rounded font-medium transition-colors ${
                zoomLevel === '15'
                  ? 'bg-white text-teal-700 shadow-2xs font-bold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              15 min
            </button>
            <button
              id="btn-zoom-30"
              onClick={() => handleZoomChange('30')}
              className={`px-2.5 py-1 rounded font-medium transition-colors ${
                zoomLevel === '30'
                  ? 'bg-white text-teal-700 shadow-2xs font-bold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              30 min
            </button>
            <button
              id="btn-zoom-60"
              onClick={() => handleZoomChange('60')}
              className={`px-2.5 py-1 rounded font-medium transition-colors ${
                zoomLevel === '60'
                  ? 'bg-white text-teal-700 shadow-2xs font-bold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              60 min
            </button>
          </div>

          {/* Operating hours select */}
          <div className="hidden lg:flex items-center gap-1 text-xs text-slate-600 bg-white border border-slate-200 px-2 py-1 rounded-lg">
            <Clock className="w-3.5 h-3.5 text-slate-400" />
            <span>08:00 - 18:00</span>
          </div>

          {/* Download PDF option */}
          <button
            id="btn-download-pdf"
            onClick={handleDownloadPDF}
            disabled={isExportingPDF}
            aria-busy={isExportingPDF}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs text-slate-700 hover:text-slate-900 bg-white hover:bg-slate-50 border border-slate-200 rounded-lg font-bold shadow-2xs transition-colors cursor-pointer"
            title="Download PDF schedule"
          >
            <FileText className="w-3.5 h-3.5 text-teal-600 shrink-0" />
            <span>{isExportingPDF ? 'Generating PDF...' : 'Download PDF'}</span>
          </button>
        </div>
      </div>

      {pdfError && (
        <p role="alert" className="border-b border-rose-200 bg-rose-50 px-4 py-2 text-sm text-rose-700">
          {pdfError}
        </p>
      )}

      {/* Main Grid Scroll Area: Left Time Rail + Horizontal Stations Container */}
      <div className="flex-1 overflow-x-auto overflow-y-auto flex bg-white relative">
        {/* Sticky Time Axis Column on Left */}
        <div className="sticky left-0 z-40 bg-slate-50 border-r border-slate-300 w-16 sm:w-20 shrink-0 select-none shadow-xs">
          {/* Top corner box matching sticky station headers height */}
          <div className="sticky top-0 z-50 bg-slate-100 border-b border-slate-300 h-[89px] flex flex-col items-center justify-center p-2 text-center shadow-xs">
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Time</span>
            <span className="text-[9px] text-slate-400 font-mono">15m slot</span>
          </div>

          {/* Time Labels Down Y-Axis */}
          <div
            className="relative bg-slate-50"
            style={{ height: `${totalMinutes * pixelsPerMinute}px` }}
          >
            {timeLabels.map((tl, i) => (
              <div
                key={tl.timeStr}
                style={{
                  top: `${tl.topPx}px`,
                  height: `${intervalMinutes * pixelsPerMinute}px`,
                }}
                className={`absolute inset-x-0 border-b border-slate-200 px-1.5 flex items-start justify-end ${
                  tl.isHour ? 'bg-slate-100/60 font-bold text-slate-900' : 'text-slate-500 font-mono text-[10px]'
                }`}
              >
                <span className="text-[11px] leading-tight">{tl.timeStr}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Stations Horizontal Columns */}
        <div className="flex relative flex-1">
          {/* Current Time Red Horizontal Line (Spans across all stations) */}
          {currentTimeTopPx !== null && (
            <div
              style={{ top: `${currentTimeTopPx + 89}px` }}
              className="absolute left-0 right-0 z-35 pointer-events-none flex items-center"
            >
              <div className="w-2.5 h-2.5 rounded-full bg-rose-600 -ml-1.5 shadow-xs" />
              <div className="flex-1 border-t-2 border-rose-500 shadow-xs" />
              <span className="bg-rose-600 text-white text-[9px] font-bold px-1 rounded mr-2 shadow-xs">
                NOW
              </span>
            </div>
          )}

          {/* Render each filtered Station Column */}
          {filteredStations.map((station) => {
            const stationType = stationTypes.find((st) => st.id === station.stationTypeId);
            const roster = rosters.find(
              (r) => r.stationId === station.id && r.date === selectedDate
            );
            const primaryPrac = roster?.primaryPractitionerId
              ? practitioners.find((p) => p.id === roster.primaryPractitionerId)
              : undefined;
            const backupPrac = roster?.backupPractitionerId
              ? practitioners.find((p) => p.id === roster.backupPractitionerId)
              : undefined;

            const stationAllocations = filteredAllocations.filter((a) => a.stationId === station.id);

            return (
              <StationColumn
                key={station.id}
                station={station}
                stationType={stationType}
                roster={roster}
                primaryPractitioner={primaryPrac}
                backupPractitioner={backupPrac}
                allocations={stationAllocations}
                patients={patients}
                treatments={treatments}
                orders={orders}
                occurrences={occurrences}
                capabilities={capabilities}
                practitioners={practitioners}
                startMinutes={startMinutes}
                endMinutes={endMinutes}
                intervalMinutes={intervalMinutes}
                pixelsPerMinute={pixelsPerMinute}
                onSlotClick={onSlotClick}
                onAllocationClick={onAllocationClick}
                onDragStartAllocation={onDragStartAllocation}
                onResizeDuration={onResizeDuration}
                onDropTarget={onDropTarget}
              />
            );
          })}
        </div>
      </div>
    </div>
  );
}
