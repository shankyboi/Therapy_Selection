import React, { useState } from 'react';
import {
  TreatmentOccurrence,
  TreatmentOrder,
  Patient,
  Treatment,
  StationTreatmentCapability,
} from '@/types/therapy';
import { GripVertical, ChevronLeft, ChevronRight, AlertCircle, Plus } from 'lucide-react';

interface UnscheduledDrawerProps {
  occurrences: TreatmentOccurrence[];
  orders: TreatmentOrder[];
  patients: Patient[];
  treatments: Treatment[];
  capabilities: StationTreatmentCapability[];
  isOpen: boolean;
  onToggleOpen: () => void;
  onDragStartTile: (e: React.DragEvent, occurrence: TreatmentOccurrence) => void;
  onQuickSchedule: (occurrence: TreatmentOccurrence) => void;
  onOpenNewOrderModal: () => void;
  pixelsPerMinute?: number;
}

export function UnscheduledDrawer({
  occurrences,
  orders,
  patients,
  treatments,
  isOpen,
  onToggleOpen,
  onDragStartTile,
  onOpenNewOrderModal,
  pixelsPerMinute,
}: UnscheduledDrawerProps) {
  const [selectedPatientId, setSelectedPatientId] = useState<string>('ALL');
  const [selectedTreatmentId, setSelectedTreatmentId] = useState<string>('ALL');
  const [selectedGender, setSelectedGender] = useState<string>('ALL');

  // Filter only unscheduled occurrences
  const unscheduledOccurrences = occurrences.filter((occ) => occ.status === 'UNSCHEDULED');

  const filteredItems = unscheduledOccurrences.filter((occ) => {
    const order = orders.find((o) => o.id === occ.treatmentOrderId);
    if (!order) return false;
    const patient = patients.find((p) => p.id === order.patientId);

    // Gender filter
    if (selectedGender !== 'ALL' && patient?.gender !== selectedGender) {
      return false;
    }

    // Therapy/Treatment filter
    if (selectedTreatmentId !== 'ALL' && order.treatmentId !== selectedTreatmentId) {
      return false;
    }

    // Patient select filter
    if (selectedPatientId !== 'ALL' && patient?.id !== selectedPatientId) {
      return false;
    }

    return true;
  });

  const renderGenderIcon = (gender?: string) => {
    if (gender === 'MALE') return <span className="text-blue-600 font-bold ml-1 text-xs shrink-0" title="Male">♂</span>;
    if (gender === 'FEMALE') return <span className="text-rose-500 font-bold ml-1 text-xs shrink-0" title="Female">♀</span>;
    return <span className="text-slate-500 font-bold ml-1 text-xs shrink-0" title="Other">⚧</span>;
  };

  return (
    <aside
      id="panel-unscheduled-treatments"
      className={`bg-white border-l border-slate-200 flex flex-col transition-all duration-300 z-30 shrink-0 shadow-sm ${
        isOpen ? 'w-64 sm:w-72' : 'w-12'
      }`}
    >
      {/* Drawer Toggle Header */}
      <div className="p-3 border-b border-slate-150 flex items-center justify-between bg-slate-50/70 min-h-[56px]">
        {isOpen ? (
          <>
            <div className="flex items-center gap-2">
              <span className="font-bold text-slate-800 text-sm">Review Queue</span>
              <span className="px-2 py-0.5 rounded-full text-[11px] font-bold bg-zinc-900 text-white">
                {unscheduledOccurrences.length}
              </span>
            </div>
            <div className="flex items-center gap-1">
              <button
                id="btn-add-order-drawer"
                onClick={onOpenNewOrderModal}
                className="p-1 text-zinc-600 hover:text-zinc-900 hover:bg-slate-100 rounded"
                title="Receive New Patient Order"
              >
                <Plus className="w-4 h-4" />
              </button>
              <button
                id="btn-collapse-unscheduled"
                onClick={onToggleOpen}
                className="p-1 text-slate-400 hover:text-slate-700 hover:bg-slate-200/60 rounded"
                title="Collapse Panel"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </>
        ) : (
          <button
            id="btn-expand-unscheduled"
            onClick={onToggleOpen}
            className="w-full flex flex-col items-center gap-2 text-slate-600 hover:text-zinc-900 py-2"
            title="Expand Review Queue"
          >
            <ChevronLeft className="w-4 h-4" />
            <span className="text-[10px] font-bold uppercase tracking-widest writing-vertical rotate-180">
              Review Queue ({unscheduledOccurrences.length})
            </span>
          </button>
        )}
      </div>

      {/* Expanded Content */}
      {isOpen && (
        <div className="flex flex-col flex-1 overflow-hidden">
          {/* Filters (Patient, Therapy & Gender) */}
          <div className="p-2.5 border-b border-slate-150 space-y-1.5 bg-slate-50/40">
            <div className="relative">
              <select
                id="select-filter-patient"
                value={selectedPatientId}
                onChange={(e) => setSelectedPatientId(e.target.value)}
                className="w-full text-xs py-1 px-2 bg-white border border-slate-250 rounded-md text-slate-800 font-semibold focus:outline-hidden focus:border-zinc-400"
              >
                <option value="ALL">Filter Patient (All Patients)</option>
                {patients.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.displayName}
                  </option>
                ))}
              </select>
            </div>

            <div className="grid grid-cols-2 gap-1.5">
              <div className="relative">
                <select
                  id="select-filter-treatment"
                  value={selectedTreatmentId}
                  onChange={(e) => setSelectedTreatmentId(e.target.value)}
                  className="w-full text-xs py-1 px-2 bg-white border border-slate-250 rounded-md text-slate-800 font-semibold focus:outline-hidden focus:border-zinc-400"
                >
                  <option value="ALL">Filter Therapy</option>
                  {treatments.map((t) => (
                    <option key={t.id} value={t.id}>
                      {t.name}
                    </option>
                  ))}
                </select>
              </div>

              <div className="relative">
                <select
                  id="select-filter-gender"
                  value={selectedGender}
                  onChange={(e) => setSelectedGender(e.target.value)}
                  className="w-full text-xs py-1 px-2 bg-white border border-slate-250 rounded-md text-slate-800 font-semibold focus:outline-hidden focus:border-zinc-400"
                >
                  <option value="ALL">Filter Gender</option>
                  <option value="MALE">Male (♂)</option>
                  <option value="FEMALE">Female (♀)</option>
                  <option value="OTHER">Other (⚧)</option>
                </select>
              </div>
            </div>
          </div>

          {/* Draggable Tiles List */}
          <div
            style={{ maxHeight: `${600 * (pixelsPerMinute || 1.8)}px` }}
            className="flex-1 overflow-y-auto p-2.5 space-y-2"
          >
            {filteredItems.length === 0 ? (
              <div className="text-center py-8 text-slate-400">
                <AlertCircle className="w-8 h-8 mx-auto text-slate-300 mb-2" />
                <p className="text-xs font-semibold text-slate-600">No matching treatments</p>
                <p className="text-[11px] text-slate-400 mt-1">
                  Adjust your filters or register a new patient order.
                </p>
              </div>
            ) : (
              filteredItems.map((occ) => {
                const order = orders.find((o) => o.id === occ.treatmentOrderId);
                if (!order) return null;
                const patient = patients.find((p) => p.id === order.patientId);
                const treatment = treatments.find((t) => t.id === order.treatmentId);

                // Shorten variations instructions if it says "Variations: "
                const compactInstructions = order.instructions
                  ? order.instructions.replace(/^Variations:\s*/i, 'Var: ')
                  : '';

                return (
                  <div
                    key={occ.id}
                    id={`unscheduled-tile-${occ.id}`}
                    draggable
                    onDragStart={(e) => onDragStartTile(e, occ)}
                    className="p-2 bg-white rounded-lg border border-slate-200 hover:border-zinc-400 shadow-2xs hover:shadow-xs transition-all cursor-grab active:cursor-grabbing group relative flex flex-col gap-1.5"
                  >
                    {/* Header: Patient & ID & Drag Icon */}
                    <div className="flex items-center justify-between gap-1 leading-none">
                      <div className="flex items-center gap-1 min-w-0">
                        <span className="text-xs font-bold text-slate-950 truncate">
                          {patient?.displayName || 'Unknown Patient'}
                        </span>
                        {renderGenderIcon(patient?.gender)}
                        {patient?.externalPatientId && (
                          <span className="text-[9px] font-mono font-bold text-slate-400 shrink-0">
                            #{patient.externalPatientId}
                          </span>
                        )}
                      </div>
                      <div className="flex items-center text-slate-400 shrink-0">
                        <GripVertical className="w-3 h-3 cursor-grab" />
                      </div>
                    </div>

                    {/* Bottom Row: Therapy Name + Duration */}
                    <div className="flex items-center justify-between gap-2 text-[11px] leading-none text-teal-950 bg-slate-50 border border-slate-100 p-1.5 rounded-md">
                      <span className="font-bold truncate">{treatment?.name || 'Treatment'}</span>
                      <span className="text-[9px] font-bold text-slate-500 font-mono shrink-0">
                        {occ.expectedDurationMinutes}m
                      </span>
                    </div>

                    {/* Doctor Notes / Variations (If any) */}
                    {compactInstructions && (
                      <p className="text-[10px] text-slate-600 font-medium leading-none italic truncate px-0.5">
                        {compactInstructions}
                      </p>
                    )}
                  </div>
                );
              })
            )}
          </div>
        </div>
      )}
    </aside>
  );
}
