import React, { useState } from 'react';
import {
  TreatmentAllocation,
  Patient,
  Treatment,
  Station,
  StationType,
  Practitioner,
  TreatmentOrder,
  TreatmentOccurrence,
  StationPractitionerRoster,
  StationTreatmentCapability,
  AllocationHistory,
  AllocationStatus,
} from '@/types/therapy';
import { Drawer } from '@/components/Modal';
import { AllocationStatusBadge, AttentionModeBadge, PriorityBadge } from '@/components/StatusBadge';
import { calculateEndTime, timeToMinutes } from '@/lib/validation';
import {
  User,
  Clock,
  MapPin,
  BedDouble,
  FileText,
  AlertTriangle,
  History,
  CheckCircle2,
  PlayCircle,
  UserCheck,
  XCircle,
  UserX,
  RotateCcw,
  Calendar,
  ShieldCheck,
  ArrowRight,
  Stethoscope,
} from 'lucide-react';

interface AllocationDetailsModalProps {
  isOpen: boolean;
  onClose: () => void;
  allocation: TreatmentAllocation | null;
  patient?: Patient;
  treatment?: Treatment;
  station?: Station;
  stationType?: StationType;
  order?: TreatmentOrder;
  occurrence?: TreatmentOccurrence;
  roster?: StationPractitionerRoster;
  plannedPractitioner?: Practitioner;
  actualPractitioner?: Practitioner;
  backupPractitioner?: Practitioner;
  allPractitioners: Practitioner[];
  allStations: Station[];
  capabilities: StationTreatmentCapability[];
  history: AllocationHistory[];
  onUpdateStatus: (allocationId: string, newStatus: AllocationStatus, notes?: string) => void;
  onReschedule: (
    allocationId: string,
    newStationId: string,
    newDate: string,
    newStartTime: string,
    newDuration: number,
    overrideReason?: string
  ) => void;
  onReturnToUnscheduled: (allocationId: string, reason: string) => void;
  onTakeoverByBackup: (allocationId: string, backupPractitionerId: string, reason: string) => void;
}

export function AllocationDetailsModal({
  isOpen,
  onClose,
  allocation,
  patient,
  treatment,
  station,
  stationType,
  order,
  occurrence,
  roster,
  plannedPractitioner,
  actualPractitioner,
  backupPractitioner,
  allPractitioners,
  allStations,
  capabilities,
  history,
  onUpdateStatus,
  onReschedule,
  onReturnToUnscheduled,
  onTakeoverByBackup,
}: AllocationDetailsModalProps) {
  const [isRescheduling, setIsRescheduling] = useState(false);
  const [rescheduleDate, setRescheduleDate] = useState('');
  const [rescheduleStartTime, setRescheduleStartTime] = useState('');
  const [rescheduleStationId, setRescheduleStationId] = useState('');
  const [rescheduleDuration, setRescheduleDuration] = useState(45);

  const [isTakeoverOpen, setIsTakeoverOpen] = useState(false);
  const [takeoverPractitionerId, setTakeoverPractitionerId] = useState('');
  const [takeoverNotes, setTakeoverNotes] = useState('');

  const [statusNotes, setStatusNotes] = useState('');

  if (!allocation) return null;

  // Filter history for this allocation
  const allocationHistory = history.filter((h) => h.allocationId === allocation.id);

  // Capability details
  const matchingCap =
    order && station
      ? capabilities.find((c) => c.stationId === station.id && c.treatmentId === order.treatmentId)
      : undefined;

  const durationMinutes =
    timeToMinutes(allocation.plannedEnd) - timeToMinutes(allocation.plannedStart);

  const handleStartReschedule = () => {
    setIsRescheduling(true);
    setRescheduleDate(allocation.date);
    setRescheduleStartTime(allocation.plannedStart);
    setRescheduleStationId(allocation.stationId);
    setRescheduleDuration(durationMinutes);
  };

  const handleApplyReschedule = (e: React.FormEvent) => {
    e.preventDefault();
    onReschedule(
      allocation.id,
      rescheduleStationId,
      rescheduleDate,
      rescheduleStartTime,
      rescheduleDuration
    );
    setIsRescheduling(false);
  };

  const handleConfirmTakeover = (e: React.FormEvent) => {
    e.preventDefault();
    if (!takeoverPractitionerId) return;
    onTakeoverByBackup(
      allocation.id,
      takeoverPractitionerId,
      takeoverNotes || 'Clinical handover / backup coverage'
    );
    setIsTakeoverOpen(false);
  };

  return (
    <Drawer
      isOpen={isOpen}
      onClose={onClose}
      title="Treatment Allocation Details"
      subtitle={`Session ID: ${allocation.id} • Occurrence: ${occurrence?.sessionNumber || 1} of ${order?.totalSessions || 1}`}
      widthClass="max-w-2xl"
    >
      <div className="space-y-6 pb-8">
        {/* Status Bar & Action Buttons */}
        <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <AllocationStatusBadge status={allocation.status} />
            {order?.priority && <PriorityBadge priority={order.priority} />}
          </div>

          {/* Status Progression Workflow Buttons */}
          <div className="flex flex-wrap items-center gap-1.5">
            {allocation.status === 'CONFIRMED' && (
              <button
                id="btn-status-checkin"
                onClick={() => onUpdateStatus(allocation.id, 'CHECKED_IN')}
                className="px-3 py-1.5 bg-amber-600 hover:bg-amber-700 text-white font-semibold text-xs rounded-lg shadow-xs flex items-center gap-1 transition-colors"
              >
                <UserCheck className="w-3.5 h-3.5" />
                <span>Check In</span>
              </button>
            )}

            {(allocation.status === 'CONFIRMED' || allocation.status === 'CHECKED_IN') && (
              <button
                id="btn-status-start"
                onClick={() => onUpdateStatus(allocation.id, 'IN_PROGRESS')}
                className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-xs rounded-lg shadow-xs flex items-center gap-1 transition-colors"
              >
                <PlayCircle className="w-3.5 h-3.5" />
                <span>Start Treatment</span>
              </button>
            )}

            {allocation.status === 'IN_PROGRESS' && (
              <button
                id="btn-status-complete"
                onClick={() => onUpdateStatus(allocation.id, 'COMPLETED')}
                className="px-3 py-1.5 bg-slate-800 hover:bg-slate-900 text-white font-semibold text-xs rounded-lg shadow-xs flex items-center gap-1 transition-colors"
              >
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                <span>Complete Session</span>
              </button>
            )}

            {allocation.status !== 'CANCELLED' && allocation.status !== 'COMPLETED' && (
              <>
                <button
                  id="btn-status-noshow"
                  onClick={() => onUpdateStatus(allocation.id, 'NO_SHOW')}
                  className="px-2.5 py-1.5 bg-zinc-200 hover:bg-zinc-300 text-zinc-800 font-medium text-xs rounded-lg transition-colors"
                  title="Mark as No-Show"
                >
                  <UserX className="w-3.5 h-3.5" />
                </button>
                <button
                  id="btn-status-cancel"
                  onClick={() => {
                    const reason = prompt('Please enter cancellation reason:', 'Patient requested reschedule');
                    if (reason !== null) {
                      onUpdateStatus(allocation.id, 'CANCELLED', reason);
                    }
                  }}
                  className="px-2.5 py-1.5 bg-rose-100 hover:bg-rose-200 text-rose-700 font-medium text-xs rounded-lg transition-colors"
                  title="Cancel Allocation"
                >
                  <XCircle className="w-3.5 h-3.5" />
                </button>
              </>
            )}
          </div>
        </div>

        {/* Override banner if present */}
        {allocation.overrideReason && (
          <div className="p-3 bg-amber-50 border border-amber-200 rounded-lg text-amber-900 text-xs space-y-1">
            <div className="flex items-center gap-1.5 font-bold">
              <AlertTriangle className="w-4 h-4 text-amber-600" />
              <span>Supervisor Override Active</span>
            </div>
            <p>
              <strong>Reason:</strong> {allocation.overrideReason}
            </p>
            <p className="text-[11px] text-amber-700">
              By {allocation.overriddenBy || 'Supervisor'} at {allocation.overriddenAt || 'Booking'}
            </p>
          </div>
        )}

        {/* Section 1: Patient Details */}
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs space-y-3">
          <div className="flex items-center justify-between border-b border-slate-100 pb-2">
            <div className="flex items-center gap-2">
              <User className="w-4 h-4 text-teal-600" />
              <h4 className="font-bold text-slate-800 text-sm">Patient Profile</h4>
            </div>
            <span className="text-xs font-mono text-slate-500 bg-slate-100 px-2 py-0.5 rounded">
              {patient?.externalPatientId}
            </span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 text-xs">
            <div>
              <span className="text-slate-500 block">Full Name</span>
              <strong className="text-slate-900 text-sm">{patient?.displayName}</strong>
            </div>
            <div>
              <span className="text-slate-500 block">Gender / Age</span>
              <span className="text-slate-800">
                {patient?.gender} • {patient?.age} yrs
              </span>
            </div>
            <div>
              <span className="text-slate-500 block">Department</span>
              <span className="text-slate-800">{patient?.department}</span>
            </div>
            <div>
              <span className="text-slate-500 block">Medical Record (MRN)</span>
              <span className="text-slate-800 font-mono">{patient?.medicalRecordNumber || 'N/A'}</span>
            </div>
            <div className="col-span-2">
              <span className="text-slate-500 block">Contact Phone</span>
              <span className="text-slate-800">{patient?.phone || 'Not recorded'}</span>
            </div>
          </div>

          {patient?.precautions && (
            <div className="p-2.5 bg-rose-50 border border-rose-200 rounded-lg text-rose-800 text-xs">
              <strong>Clinical Precautions: </strong>
              <span>{patient.precautions}</span>
            </div>
          )}
        </div>

        {/* Section 2: Treatment & Station Info */}
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs space-y-3">
          <div className="flex items-center justify-between border-b border-slate-100 pb-2">
            <div className="flex items-center gap-2">
              <Stethoscope className="w-4 h-4 text-teal-600" />
              <h4 className="font-bold text-slate-800 text-sm">Treatment & Room</h4>
            </div>
            {matchingCap && (
              <AttentionModeBadge
                mode={matchingCap.attentionMode}
                maxParallel={matchingCap.maximumParallelPatients}
              />
            )}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            <div className="space-y-1.5">
              <div>
                <span className="text-slate-500 block">Prescribed Modality</span>
                <strong className="text-slate-900 text-sm">{treatment?.name}</strong>
              </div>
              <p className="text-slate-600 text-[11px] leading-relaxed">{treatment?.description}</p>
              {order?.instructions && (
                <div className="p-2 bg-slate-50 rounded border border-slate-200 text-slate-700">
                  <span className="text-[10px] uppercase font-bold text-slate-500 block">
                    Special Physician Orders
                  </span>
                  &quot;{order.instructions}&quot;
                </div>
              )}
            </div>

            <div className="space-y-1.5 bg-slate-50/70 p-3 rounded-lg border border-slate-100">
              <div className="flex items-center justify-between">
                <span className="text-slate-500 font-medium">Assigned Room</span>
                <span className="font-bold text-slate-900">{station?.name}</span>
              </div>
              <div className="flex items-center justify-between text-slate-600">
                <span>Room Type:</span>
                <span>{stationType?.name}</span>
              </div>
              <div className="flex items-center justify-between text-slate-600">
                <span>Location:</span>
                <span>{station?.location}</span>
              </div>
              <div className="flex items-center justify-between text-slate-600">
                <span>Room Concurrent Cap:</span>
                <span className="font-semibold">{station?.capacity} Patient(s)</span>
              </div>
            </div>
          </div>
        </div>

        {/* Section 3: Time Schedule & Practitioner Assignments */}
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs space-y-3">
          <div className="flex items-center justify-between border-b border-slate-100 pb-2">
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4 text-teal-600" />
              <h4 className="font-bold text-slate-800 text-sm">Schedule & Clinical Personnel</h4>
            </div>
            <button
              id="btn-trigger-reschedule"
              onClick={handleStartReschedule}
              className="text-xs font-semibold text-teal-700 hover:text-teal-900 bg-teal-50 px-2.5 py-1 rounded-md transition-colors"
            >
              Reschedule / Move
            </button>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 text-xs">
            <div>
              <span className="text-slate-500 block">Scheduled Date</span>
              <strong className="text-slate-900">{allocation.date}</strong>
            </div>
            <div>
              <span className="text-slate-500 block">Planned Time Slot</span>
              <strong className="text-slate-900">
                {allocation.plannedStart} - {allocation.plannedEnd} ({durationMinutes}m)
              </strong>
            </div>
            <div>
              <span className="text-slate-500 block">Timestamps</span>
              <span className="text-slate-700">
                In: {allocation.checkInTime || '--'} | Start: {allocation.actualStartTime || '--'} | End:{' '}
                {allocation.actualEndTime || '--'}
              </span>
            </div>
            <div>
              <span className="text-slate-500 block">Planned Responsible</span>
              <span className="text-slate-800 font-medium">
                {plannedPractitioner?.displayName || 'Unassigned'}
              </span>
            </div>
            <div>
              <span className="text-slate-500 block">Actual Care Practitioner</span>
              <span className="text-teal-800 font-bold">
                {actualPractitioner?.displayName || plannedPractitioner?.displayName || 'Pending'}
              </span>
            </div>
            <div>
              <span className="text-slate-500 block">Room Roster Backup</span>
              <span className="text-slate-600">
                {backupPractitioner ? backupPractitioner.displayName : 'None assigned'}
              </span>
            </div>
          </div>

          {/* Backup Practitioner Takeover Action */}
          <div className="pt-2 border-t border-slate-100 flex items-center justify-between">
            <div className="text-[11px] text-slate-500">
              Is backup providing active therapy care?
            </div>
            <button
              id="btn-backup-takeover"
              onClick={() => setIsTakeoverOpen(true)}
              className="text-xs text-purple-700 hover:text-purple-900 font-semibold flex items-center gap-1 bg-purple-50 px-2.5 py-1 rounded"
            >
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>Record Backup Takeover</span>
            </button>
          </div>

          {/* Takeover Form inline */}
          {isTakeoverOpen && (
            <form
              onSubmit={handleConfirmTakeover}
              className="p-3 bg-purple-50/70 border border-purple-200 rounded-lg space-y-2 mt-2"
            >
              <div className="text-xs font-bold text-purple-900">
                Handover / Assign Actual Practitioner
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                <div>
                  <label className="block text-slate-600 font-medium mb-0.5">
                    Select Treating Practitioner:
                  </label>
                  <select
                    required
                    value={takeoverPractitionerId}
                    onChange={(e) => setTakeoverPractitionerId(e.target.value)}
                    className="w-full text-xs p-1.5 bg-white border border-purple-300 rounded"
                  >
                    <option value="">-- Choose Practitioner --</option>
                    {allPractitioners.map((p) => (
                      <option key={p.id} value={p.id}>
                        {p.displayName} ({p.department})
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-slate-600 font-medium mb-0.5">Takeover Reason / Notes:</label>
                  <input
                    type="text"
                    value={takeoverNotes}
                    onChange={(e) => setTakeoverNotes(e.target.value)}
                    placeholder="e.g. Primary in emergency procedure"
                    className="w-full text-xs p-1.5 bg-white border border-purple-300 rounded"
                  />
                </div>
              </div>
              <div className="flex justify-end gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => setIsTakeoverOpen(false)}
                  className="px-2.5 py-1 text-xs text-slate-600 hover:bg-slate-200 rounded"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-3 py-1 text-xs bg-purple-700 hover:bg-purple-800 text-white font-semibold rounded shadow-xs"
                >
                  Save Takeover
                </button>
              </div>
            </form>
          )}
        </div>

        {/* Reschedule Form Section */}
        {isRescheduling && (
          <form
            onSubmit={handleApplyReschedule}
            className="p-4 bg-teal-50 border border-teal-200 rounded-xl space-y-3"
          >
            <div className="flex items-center justify-between">
              <h5 className="font-bold text-teal-900 text-xs">Reschedule Treatment Slot</h5>
              <button
                type="button"
                onClick={() => setIsRescheduling(false)}
                className="text-xs text-teal-700 hover:underline"
              >
                Cancel
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 text-xs">
              <div>
                <label className="block text-slate-700 font-medium mb-1">Target Room:</label>
                <select
                  value={rescheduleStationId}
                  onChange={(e) => setRescheduleStationId(e.target.value)}
                  className="w-full text-xs p-1.5 bg-white border border-teal-300 rounded"
                >
                  {allStations
                    .filter((s) => s.isActive)
                    .map((st) => (
                      <option key={st.id} value={st.id}>
                        {st.name} ({st.department})
                      </option>
                    ))}
                </select>
              </div>

              <div>
                <label className="block text-slate-700 font-medium mb-1">Date:</label>
                <input
                  type="date"
                  required
                  value={rescheduleDate}
                  onChange={(e) => setRescheduleDate(e.target.value)}
                  className="w-full text-xs p-1.5 bg-white border border-teal-300 rounded"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-medium mb-1">Start Time:</label>
                <input
                  type="time"
                  required
                  step="900"
                  value={rescheduleStartTime}
                  onChange={(e) => setRescheduleStartTime(e.target.value)}
                  className="w-full text-xs p-1.5 bg-white border border-teal-300 rounded"
                />
              </div>
            </div>

            <div className="flex items-center justify-between pt-2">
              <span className="text-[11px] text-teal-800">
                Calculated End:{' '}
                <strong>{calculateEndTime(rescheduleStartTime, rescheduleDuration)}</strong>
              </span>
              <button
                id="btn-submit-reschedule"
                type="submit"
                className="px-4 py-1.5 bg-teal-700 hover:bg-teal-800 text-white font-semibold text-xs rounded-lg shadow-xs"
              >
                Validate & Move
              </button>
            </div>
          </form>
        )}

        {/* Section 4: Return to Unscheduled Action */}
        <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg flex items-center justify-between text-xs">
          <div>
            <span className="font-semibold text-slate-800">Return to Unscheduled Queue</span>
            <p className="text-[11px] text-slate-500">
              Removes from room grid and places back into left unscheduled pool.
            </p>
          </div>
          <button
            id="btn-return-unscheduled"
            onClick={() => {
              const reason = prompt(
                'Reason for returning to unscheduled pool:',
                'Rescheduling required due to station maintenance'
              );
              if (reason !== null) {
                onReturnToUnscheduled(allocation.id, reason);
                onClose();
              }
            }}
            className="px-3 py-1.5 text-xs text-amber-800 bg-amber-100 hover:bg-amber-200 font-semibold rounded-lg transition-colors flex items-center gap-1"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Unschedule</span>
          </button>
        </div>

        {/* Section 5: Audit History Timeline */}
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs space-y-3">
          <div className="flex items-center gap-2 border-b border-slate-100 pb-2">
            <History className="w-4 h-4 text-slate-500" />
            <h4 className="font-bold text-slate-800 text-sm">Allocation History & Audit Trail</h4>
          </div>

          <div className="space-y-2.5 max-h-48 overflow-y-auto pr-1">
            {allocationHistory.length === 0 ? (
              <p className="text-xs text-slate-400 italic">Initial creation event logged.</p>
            ) : (
              allocationHistory.map((h) => (
                <div
                  key={h.id}
                  className="p-2.5 bg-slate-50 rounded-lg border border-slate-100 text-xs space-y-0.5"
                >
                  <div className="flex items-center justify-between font-semibold text-slate-800">
                    <span className="text-teal-700">{h.eventType}</span>
                    <span className="text-[10px] text-slate-400 font-normal">
                      {new Date(h.performedAt).toLocaleTimeString([], {
                        hour: '2-digit',
                        minute: '2-digit',
                      })}
                    </span>
                  </div>
                  <div className="text-[11px] text-slate-600">
                    {h.previousValue && <span>From: {h.previousValue} → </span>}
                    <strong>{h.newValue}</strong>
                  </div>
                  {h.reason && <div className="text-[10px] text-slate-500 italic">&quot;{h.reason}&quot;</div>}
                  <div className="text-[9px] text-slate-400">By: {h.performedBy}</div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </Drawer>
  );
}
