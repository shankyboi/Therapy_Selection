import React, { useState } from 'react';
import { Modal } from '@/components/Modal';
import {
  Station,
  TreatmentOccurrence,
  TreatmentOrder,
  Patient,
  Treatment,
  StationTreatmentCapability,
} from '@/types/therapy';
import { calculateEndTime } from '@/lib/validation';
import { PriorityBadge, AttentionModeBadge } from '@/components/StatusBadge';
import { Calendar, Clock, BedDouble, ArrowRight, Check } from 'lucide-react';

interface ScheduleSlotModalProps {
  isOpen: boolean;
  onClose: () => void;
  selectedStation: Station | null;
  selectedDate: string;
  selectedTime: string;
  unscheduledOccurrences: TreatmentOccurrence[];
  orders: TreatmentOrder[];
  patients: Patient[];
  treatments: Treatment[];
  capabilities: StationTreatmentCapability[];
  onConfirmSchedule: (
    occurrenceId: string,
    stationId: string,
    date: string,
    startTime: string,
    durationMinutes: number
  ) => void;
}

export function ScheduleSlotModal({
  isOpen,
  onClose,
  selectedStation,
  selectedDate,
  selectedTime,
  unscheduledOccurrences,
  orders,
  patients,
  treatments,
  capabilities,
  onConfirmSchedule,
}: ScheduleSlotModalProps) {
  const [selectedOccId, setSelectedOccId] = useState<string>(
    unscheduledOccurrences[0]?.id || ''
  );
  const [customDuration, setCustomDuration] = useState<number>(unscheduledOccurrences[0]?.expectedDurationMinutes || 45);

  if (!selectedStation) return null;

  // Find currently selected occurrence info
  const currentOcc = unscheduledOccurrences.find((o) => o.id === selectedOccId);
  const currentOrder = currentOcc ? orders.find((o) => o.id === currentOcc.treatmentOrderId) : null;
  const currentPatient = currentOrder ? patients.find((p) => p.id === currentOrder.patientId) : null;
  const currentTreatment = currentOrder ? treatments.find((t) => t.id === currentOrder.treatmentId) : null;

  // Filter capabilities for this station to check if treatment is allowed
  const stationAllowedCaps = capabilities.filter(
    (c) => c.stationId === selectedStation.id && c.isAllowed
  );
  const allowedTreatmentIds = new Set(stationAllowedCaps.map((c) => c.treatmentId));

  const handleSelectOccurrence = (occId: string) => {
    setSelectedOccId(occId);
    const occ = unscheduledOccurrences.find((o) => o.id === occId);
    if (occ) {
      setCustomDuration(occ.expectedDurationMinutes || 45);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedOccId) return;
    onConfirmSchedule(
      selectedOccId,
      selectedStation.id,
      selectedDate,
      selectedTime,
      customDuration
    );
    onClose();
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="Schedule Treatment Slot"
      subtitle={`Room: ${selectedStation.name} • ${selectedDate} at ${selectedTime}`}
      maxWidthClass="max-w-xl"
    >
      <form onSubmit={handleSubmit} className="space-y-4">
        {/* Target Slot Details */}
        <div className="p-3 bg-teal-50 border border-teal-200 rounded-lg flex items-center justify-between text-xs text-teal-900">
          <div className="flex items-center gap-2">
            <BedDouble className="w-4 h-4 text-teal-700" />
            <div>
              <strong>{selectedStation.name}</strong>
              <span className="text-teal-700 block">{selectedStation.department} • {selectedStation.location}</span>
            </div>
          </div>
          <div className="text-right">
            <span className="text-slate-500 font-medium">Slot Time:</span>
            <div className="font-bold text-sm">
              {selectedTime} - {calculateEndTime(selectedTime, customDuration)}
            </div>
          </div>
        </div>

        {/* Unscheduled Items Selector */}
        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-2">
            Select Patient Treatment to Schedule ({unscheduledOccurrences.length} available):
          </label>

          {unscheduledOccurrences.length === 0 ? (
            <div className="p-4 bg-slate-50 border border-slate-200 rounded-lg text-center text-xs text-slate-500">
              No unscheduled treatments available. Please receive a new patient order.
            </div>
          ) : (
            <div className="space-y-2 max-h-56 overflow-y-auto pr-1">
              {unscheduledOccurrences.map((occ) => {
                const ord = orders.find((o) => o.id === occ.treatmentOrderId);
                if (!ord) return null;
                const pat = patients.find((p) => p.id === ord.patientId);
                const trt = treatments.find((t) => t.id === ord.treatmentId);
                const isSelected = occ.id === selectedOccId;
                const isSupported = allowedTreatmentIds.has(ord.treatmentId);

                return (
                  <div
                    key={occ.id}
                    onClick={() => handleSelectOccurrence(occ.id)}
                    className={`p-3 rounded-lg border text-xs cursor-pointer transition-all ${
                      isSelected
                        ? 'border-teal-600 bg-teal-50/60 ring-2 ring-teal-500/20'
                        : 'border-slate-200 hover:border-slate-300 bg-white'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2 font-bold text-slate-900">
                        <span>{pat?.displayName}</span>
                        <span className="text-[10px] text-slate-400 font-normal font-mono">
                          {pat?.externalPatientId}
                        </span>
                      </div>
                      <PriorityBadge priority={ord.priority} />
                    </div>

                    <div className="flex items-center justify-between mt-1 text-slate-600">
                      <span className="font-semibold text-teal-800">{trt?.name}</span>
                      <span className="text-[11px]">
                        Session {occ.sessionNumber}/{ord.totalSessions} • {occ.expectedDurationMinutes}m
                      </span>
                    </div>

                    {!isSupported && (
                      <div className="mt-1 text-[10px] text-rose-600 font-medium">
                        ⚠️ Note: This treatment may not be supported by {selectedStation.name}.
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Duration Adjuster */}
        {currentOcc && (
          <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-xs">
            <label className="font-semibold text-slate-700">Planned Duration (Minutes):</label>
            <div className="flex items-center gap-2">
              {[15, 30, 45, 60, 90, 120].map((mins) => (
                <button
                  type="button"
                  key={mins}
                  onClick={() => setCustomDuration(mins)}
                  className={`px-2 py-1 rounded text-xs font-medium border transition-colors ${
                    customDuration === mins
                      ? 'bg-teal-600 text-white border-teal-600'
                      : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                  }`}
                >
                  {mins}m
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Footer Actions */}
        <div className="flex justify-end gap-2 pt-3 border-t border-slate-200">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-lg transition-colors"
          >
            Cancel
          </button>
          <button
            id="btn-confirm-slot-schedule"
            type="submit"
            disabled={!selectedOccId || unscheduledOccurrences.length === 0}
            className="px-4 py-2 text-xs font-semibold bg-teal-600 hover:bg-teal-700 disabled:opacity-50 text-white rounded-lg shadow-xs flex items-center gap-1.5 transition-colors"
          >
            <Check className="w-4 h-4" />
            <span>Validate & Allocate Slot</span>
          </button>
        </div>
      </form>
    </Modal>
  );
}
