import React from 'react';
import { PriorityLevel, AttentionMode, AllocationStatus, RosterStatus } from '@/types/therapy';
import { 
  AlertTriangle, 
  Flame, 
  Clock, 
  CheckCircle2, 
  PlayCircle, 
  UserCheck, 
  XCircle, 
  UserX, 
  ShieldAlert, 
  Users, 
  EyeOff,
  UserCheck2
} from 'lucide-react';

export function PriorityBadge({ priority, className = '' }: { priority: PriorityLevel; className?: string }) {
  switch (priority) {
    case 'URGENT':
      return (
        <span
          id={`badge-priority-urgent-${priority}`}
          className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-xs font-semibold bg-rose-50 text-rose-700 border border-rose-200 ${className}`}
        >
          <Flame className="w-3.5 h-3.5 text-rose-600" />
          <span>Urgent</span>
        </span>
      );
    case 'HIGH':
      return (
        <span
          id={`badge-priority-high-${priority}`}
          className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-xs font-semibold bg-amber-50 text-amber-700 border border-amber-200 ${className}`}
        >
          <AlertTriangle className="w-3.5 h-3.5 text-amber-600" />
          <span>High</span>
        </span>
      );
    case 'NORMAL':
      return (
        <span
          id={`badge-priority-normal-${priority}`}
          className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-xs font-medium bg-sky-50 text-sky-700 border border-sky-200 ${className}`}
        >
          <Clock className="w-3 h-3 text-sky-600" />
          <span>Normal</span>
        </span>
      );
    case 'LOW':
      return (
        <span
          id={`badge-priority-low-${priority}`}
          className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-xs font-medium bg-slate-100 text-slate-700 border border-slate-200 ${className}`}
        >
          <span>Low</span>
        </span>
      );
    default:
      return null;
  }
}

export function AttentionModeBadge({ mode, maxParallel }: { mode: AttentionMode; maxParallel?: number | null }) {
  switch (mode) {
    case 'EXCLUSIVE':
      return (
        <span
          id={`badge-mode-exclusive`}
          className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-xs font-medium bg-purple-50 text-purple-700 border border-purple-200"
          title="Exclusive 1-on-1: Full practitioner dedication required"
        >
          <ShieldAlert className="w-3 h-3 text-purple-600" />
          <span>Exclusive 1:1</span>
        </span>
      );
    case 'SHARED':
      return (
        <span
          id={`badge-mode-shared`}
          className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-xs font-medium bg-teal-50 text-teal-700 border border-teal-200"
          title={`Shared supervision: Max ${maxParallel || 3} parallel patients`}
        >
          <Users className="w-3 h-3 text-teal-600" />
          <span>Shared (Max {maxParallel || 3})</span>
        </span>
      );
    case 'UNATTENDED':
      return (
        <span
          id={`badge-mode-unattended`}
          className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-xs font-medium bg-emerald-50 text-emerald-700 border border-emerald-200"
          title="Unattended: Practitioner needed for setup/monitoring only"
        >
          <EyeOff className="w-3 h-3 text-emerald-600" />
          <span>Unattended</span>
        </span>
      );
    default:
      return null;
  }
}

export function AllocationStatusBadge({ status }: { status: AllocationStatus }) {
  switch (status) {
    case 'CONFIRMED':
      return (
        <span
          id="badge-status-confirmed"
          className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-50 text-blue-700 border border-blue-200"
        >
          <Clock className="w-3 h-3 text-blue-600" />
          <span>Confirmed</span>
        </span>
      );
    case 'CHECKED_IN':
      return (
        <span
          id="badge-status-checked-in"
          className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-medium bg-amber-50 text-amber-700 border border-amber-200"
        >
          <UserCheck className="w-3 h-3 text-amber-600" />
          <span>Checked In</span>
        </span>
      );
    case 'IN_PROGRESS':
      return (
        <span
          id="badge-status-in-progress"
          className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-700 border border-emerald-300 animate-pulse"
        >
          <PlayCircle className="w-3 h-3 text-emerald-600" />
          <span>In Progress</span>
        </span>
      );
    case 'COMPLETED':
      return (
        <span
          id="badge-status-completed"
          className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-medium bg-slate-100 text-slate-700 border border-slate-300"
        >
          <CheckCircle2 className="w-3 h-3 text-slate-600" />
          <span>Completed</span>
        </span>
      );
    case 'CANCELLED':
      return (
        <span
          id="badge-status-cancelled"
          className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-medium bg-rose-50 text-rose-700 border border-rose-200"
        >
          <XCircle className="w-3 h-3 text-rose-600" />
          <span>Cancelled</span>
        </span>
      );
    case 'NO_SHOW':
      return (
        <span
          id="badge-status-no-show"
          className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-medium bg-zinc-100 text-zinc-700 border border-zinc-300"
        >
          <UserX className="w-3 h-3 text-zinc-600" />
          <span>No-Show</span>
        </span>
      );
    default:
      return null;
  }
}

export function RosterStatusBadge({ status }: { status: RosterStatus }) {
  switch (status) {
    case 'CONFIRMED':
      return (
        <span
          id="badge-roster-confirmed"
          className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-xs font-medium bg-emerald-50 text-emerald-700 border border-emerald-200"
        >
          <UserCheck2 className="w-3 h-3 text-emerald-600" />
          <span>Active Roster</span>
        </span>
      );
    case 'SCHEDULED':
      return (
        <span
          id="badge-roster-scheduled"
          className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-xs font-medium bg-blue-50 text-blue-700 border border-blue-200"
        >
          <Clock className="w-3 h-3 text-blue-600" />
          <span>Scheduled Shift</span>
        </span>
      );
    case 'ABSENT':
      return (
        <span
          id="badge-roster-absent"
          className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-xs font-medium bg-rose-50 text-rose-700 border border-rose-200"
        >
          <UserX className="w-3 h-3 text-rose-600" />
          <span>Absent</span>
        </span>
      );
    default:
      return null;
  }
}
