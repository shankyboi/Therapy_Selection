import React from 'react';
import { ActivePage } from '@/types/therapy';
import {
  LayoutDashboard,
  CalendarDays,
  Layers,
  BedDouble,
  SlidersHorizontal,
  UserCog,
  FileSpreadsheet,
  RotateCcw,
  PlusCircle,
  Stethoscope,
  ChevronLeft,
  ChevronRight,
  Calendar,
} from 'lucide-react';
import { getRelativeDateString } from '@/lib/sampleData';

interface NavbarProps {
  activePage: ActivePage;
  onNavigate: (page: ActivePage) => void;
  selectedDate: string;
  onDateChange: (date: string) => void;
  onOpenNewOrder: () => void;
  onResetDemo: () => void;
  unscheduledCount: number;
}

export function Navbar({
  activePage,
  onNavigate,
  selectedDate,
  onDateChange,
  onOpenNewOrder,
  onResetDemo,
  unscheduledCount,
}: NavbarProps) {
  const handlePrevDay = () => {
    const d = new Date(selectedDate);
    d.setDate(d.getDate() - 1);
    onDateChange(d.toISOString().split('T')[0]);
  };

  const handleNextDay = () => {
    const d = new Date(selectedDate);
    d.setDate(d.getDate() + 1);
    onDateChange(d.toISOString().split('T')[0]);
  };

  const handleToday = () => {
    onDateChange(getRelativeDateString(0));
  };

  return (
    <header className="bg-white border-b border-slate-200 sticky top-0 z-40 shadow-xs">
      {/* Top Branding & Main Controls */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 flex items-center justify-between h-16">
        {/* Brand */}
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-teal-600 text-white flex items-center justify-center shadow-md shadow-teal-600/20">
            <Stethoscope className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-lg font-bold text-slate-900 tracking-tight">Therapy Scheduler</span>
              <span className="text-[10px] uppercase font-bold tracking-wider px-1.5 py-0.5 rounded bg-teal-100 text-teal-800 border border-teal-200">
                Hospital Roster & Grid
              </span>
            </div>
            <p className="text-xs text-slate-500 hidden sm:block">
              Clinical Therapy Station & Treatment Workload Planner
            </p>
          </div>
        </div>

        {/* Date Selector & Global Actions */}
        <div className="flex items-center gap-3">
          {/* Quick Date Navigator */}
          <div className="flex items-center bg-slate-50 border border-slate-200 rounded-lg p-0.5 shadow-2xs">
            <button
              id="btn-nav-prev-date"
              onClick={handlePrevDay}
              className="p-1.5 hover:bg-slate-200/70 rounded text-slate-600 transition-colors"
              title="Previous Day"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button
              id="btn-nav-today"
              onClick={handleToday}
              className="px-2.5 py-1 text-xs font-semibold text-slate-700 hover:bg-slate-200/70 rounded transition-colors"
            >
              Today
            </button>
            <div className="flex items-center gap-1 px-2 border-l border-r border-slate-200">
              <Calendar className="w-3.5 h-3.5 text-slate-400" />
              <input
                id="input-nav-selected-date"
                type="date"
                value={selectedDate}
                onChange={(e) => e.target.value && onDateChange(e.target.value)}
                className="text-xs font-medium text-slate-800 bg-transparent border-none focus:outline-hidden py-0.5 cursor-pointer"
              />
            </div>
            <button
              id="btn-nav-next-date"
              onClick={handleNextDay}
              className="p-1.5 hover:bg-slate-200/70 rounded text-slate-600 transition-colors"
              title="Next Day"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>

          {/* New External Order Simulation */}
          <button
            id="btn-nav-new-order"
            onClick={onOpenNewOrder}
            className="hidden md:inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-teal-600 text-white hover:bg-teal-700 active:bg-teal-800 shadow-xs transition-colors"
          >
            <PlusCircle className="w-4 h-4" />
            <span>Receive Patient Order</span>
          </button>

          {/* Reset Demo Data */}
          <button
            id="btn-nav-reset-demo"
            onClick={() => {
              if (window.confirm('Reset all stations, rosters, and allocations back to the initial sample state?')) {
                onResetDemo();
              }
            }}
            className="p-2 rounded-lg text-slate-500 hover:text-slate-800 hover:bg-slate-100 border border-slate-200 transition-colors"
            title="Reset to Demo State"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 overflow-x-auto scrollbar-none border-t border-slate-100 flex items-center gap-1">
        <NavTab
          id="nav-tab-dashboard"
          label="Dashboard"
          icon={<LayoutDashboard className="w-4 h-4" />}
          isActive={activePage === 'dashboard'}
          onClick={() => onNavigate('dashboard')}
        />
        <NavTab
          id="nav-tab-therapy-selection"
          label="Therapy Selection"
          icon={<PlusCircle className="w-4 h-4" />}
          isActive={activePage === 'therapy-selection'}
          onClick={() => onNavigate('therapy-selection')}
        />
        <NavTab
          id="nav-tab-scheduler"
          label="Therapy Scheduler"
          icon={<CalendarDays className="w-4 h-4" />}
          isActive={activePage === 'scheduler'}
          onClick={() => onNavigate('scheduler')}
          badge={unscheduledCount > 0 ? `${unscheduledCount} Unscheduled` : undefined}
          badgeColor="bg-amber-100 text-amber-800 border-amber-200"
        />
        <NavTab
          id="nav-tab-practitioner-planner"
          label="Practitioner Planner"
          icon={<UserCog className="w-4 h-4" />}
          isActive={activePage === 'practitioner-planner'}
          onClick={() => onNavigate('practitioner-planner')}
        />
        <NavTab
          id="nav-tab-capabilities"
          label="Room Treatment Capabilities"
          icon={<SlidersHorizontal className="w-4 h-4" />}
          isActive={activePage === 'capabilities'}
          onClick={() => onNavigate('capabilities')}
        />
        <NavTab
          id="nav-tab-stations"
          label="Room"
          icon={<BedDouble className="w-4 h-4" />}
          isActive={activePage === 'stations'}
          onClick={() => onNavigate('stations')}
        />
        <NavTab
          id="nav-tab-station-types"
          label="Room Type"
          icon={<Layers className="w-4 h-4" />}
          isActive={activePage === 'station-types'}
          onClick={() => onNavigate('station-types')}
        />
        <NavTab
          id="nav-tab-reports"
          label="Reports & Allocation List"
          icon={<FileSpreadsheet className="w-4 h-4" />}
          isActive={activePage === 'reports'}
          onClick={() => onNavigate('reports')}
        />
      </div>
    </header>
  );
}

function NavTab({
  id,
  label,
  icon,
  isActive,
  onClick,
  badge,
  badgeColor = 'bg-slate-100 text-slate-700',
}: {
  id: string;
  label: string;
  icon: React.ReactNode;
  isActive: boolean;
  onClick: () => void;
  badge?: string;
  badgeColor?: string;
}) {
  return (
    <button
      id={id}
      onClick={onClick}
      className={`flex items-center gap-2 px-5 py-3.5 text-sm font-bold whitespace-nowrap transition-colors border-b-2 ${
        isActive
          ? 'border-teal-600 text-teal-700 bg-teal-50/40'
          : 'border-transparent text-slate-600 hover:text-slate-900 hover:bg-slate-50'
      }`}
    >
      {icon}
      <span>{label}</span>
      {badge && (
        <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded-full border ${badgeColor}`}>
          {badge}
        </span>
      )}
    </button>
  );
}
