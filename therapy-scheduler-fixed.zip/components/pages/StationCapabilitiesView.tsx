import React, { useState } from 'react';
import {
  Station,
  Treatment,
  StationTreatmentCapability,
  AttentionMode,
} from '@/types/therapy';
import { Modal } from '@/components/Modal';
import { AttentionModeBadge } from '@/components/StatusBadge';
import { SlidersHorizontal, Check, X, Edit2, Search, CheckCircle2, XCircle } from 'lucide-react';

interface StationCapabilitiesViewProps {
  stations: Station[];
  treatments: Treatment[];
  capabilities: StationTreatmentCapability[];
  onSaveCapability: (capability: StationTreatmentCapability) => void;
  onToggleAllowed: (stationId: string, treatmentId: string) => void;
}

export function StationCapabilitiesView({
  stations,
  treatments,
  capabilities,
  onSaveCapability,
  onToggleAllowed,
}: StationCapabilitiesViewProps) {
  const [selectedStationId, setSelectedStationId] = useState<string>('ALL');
  const [selectedTreatmentId, setSelectedTreatmentId] = useState<string>('ALL');
  const [viewMode, setViewMode] = useState<'matrix' | 'list'>('matrix');

  // Edit Modal State
  const [editingCap, setEditingCap] = useState<StationTreatmentCapability | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  // Form states
  const [isAllowed, setIsAllowed] = useState(true);
  const [duration, setDuration] = useState(45);
  const [attentionMode, setAttentionMode] = useState<AttentionMode>('EXCLUSIVE');
  const [maxParallel, setMaxParallel] = useState(1);
  const [isActive, setIsActive] = useState(true);

  const handleOpenEdit = (cap: StationTreatmentCapability) => {
    setEditingCap(cap);
    setIsAllowed(cap.isAllowed);
    setDuration(cap.durationMinutes);
    setAttentionMode(cap.attentionMode);
    setMaxParallel(cap.maximumParallelPatients || 1);
    setIsActive(cap.isActive);
    setIsModalOpen(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingCap) return;

    onSaveCapability({
      ...editingCap,
      isAllowed,
      durationMinutes: Number(duration),
      stationCapacity: editingCap.stationCapacity || 1,
      attentionMode,
      maximumParallelPatients: attentionMode === 'SHARED' ? Number(maxParallel) : null,
      isActive,
    });

    setIsModalOpen(false);
  };

  const filteredStations = stations.filter((s) => s.isActive && (selectedStationId === 'ALL' || s.id === selectedStationId));
  const filteredTreatments = treatments.filter((t) => t.isActive && (selectedTreatmentId === 'ALL' || t.id === selectedTreatmentId));

  // Flattened capability list for list view
  const flattenedCaps = capabilities.filter((c) => {
    if (selectedStationId !== 'ALL' && c.stationId !== selectedStationId) return false;
    if (selectedTreatmentId !== 'ALL' && c.treatmentId !== selectedTreatmentId) return false;
    return true;
  });

  return (
    <div id="station-capabilities-view" className="max-w-7xl mx-auto px-4 sm:px-6 py-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 pb-4">
        <div>
          <div className="flex items-center gap-2 text-teal-700 text-xs font-bold uppercase tracking-wider mb-1">
            <SlidersHorizontal className="w-4 h-4" />
            <span>Compatibility & Protocol Matrix</span>
          </div>
          <h2 className="text-xl font-bold text-slate-900">Room Treatment Capabilities</h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Configure which treatments each room can support, default durations, and practitioner attention modes (1:1 Exclusive, Shared Multi-Patient, or Unattended).
          </p>
        </div>

        {/* View Toggle */}
        <div className="flex items-center bg-slate-100 p-0.5 rounded-lg border border-slate-200 text-xs">
          <button
            onClick={() => setViewMode('matrix')}
            className={`px-3 py-1.5 rounded-md font-semibold transition-colors ${
              viewMode === 'matrix' ? 'bg-white text-teal-700 shadow-2xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Matrix Grid View
          </button>
          <button
            onClick={() => setViewMode('list')}
            className={`px-3 py-1.5 rounded-md font-semibold transition-colors ${
              viewMode === 'list' ? 'bg-white text-teal-700 shadow-2xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Detailed List View
          </button>
        </div>
      </div>

      {/* Filter Toolbar */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-2 text-xs">
            <span className="text-slate-500 font-medium">Filter Room:</span>
            <select
              value={selectedStationId}
              onChange={(e) => setSelectedStationId(e.target.value)}
              className="py-1.5 px-3 bg-white border border-slate-200 rounded-lg text-slate-700 focus:outline-hidden"
            >
              <option value="ALL">All Rooms ({stations.length})</option>
              {stations.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name} ({s.department})
                </option>
              ))}
            </select>
          </div>

          <div className="flex items-center gap-2 text-xs">
            <span className="text-slate-500 font-medium">Filter Treatment:</span>
            <select
              value={selectedTreatmentId}
              onChange={(e) => setSelectedTreatmentId(e.target.value)}
              className="py-1.5 px-3 bg-white border border-slate-200 rounded-lg text-slate-700 focus:outline-hidden"
            >
              <option value="ALL">All Treatments ({treatments.length})</option>
              {treatments.map((t) => (
                <option key={t.id} value={t.id}>
                  {t.name}
                </option>
              ))}
            </select>
          </div>
        </div>

        <div className="text-xs text-slate-500 flex items-center gap-3">
          <span className="flex items-center gap-1.5">
            <span className="w-3 h-3 rounded-full bg-emerald-100 border border-emerald-300 inline-block" /> Supported
          </span>
          <span className="flex items-center gap-1.5">
            <span className="w-3 h-3 rounded-full bg-slate-100 border border-slate-300 inline-block" /> Not Supported
          </span>
        </div>
      </div>

      {/* View Mode 1: Interactive 2D Matrix Table */}
      {viewMode === 'matrix' ? (
        <div className="bg-white rounded-xl border border-slate-200 overflow-x-auto shadow-2xs">
          <table className="w-full text-left text-xs border-collapse min-w-[700px]">
            <thead>
              <tr className="border-b border-slate-200 bg-slate-50/80 text-slate-700 font-semibold">
                <th className="py-3 px-4 sticky left-0 bg-slate-50 z-10 w-48 border-r border-slate-200">
                  Room / Unit
                </th>
                {filteredTreatments.map((trt) => (
                  <th key={trt.id} className="py-3 px-3 text-center min-w-[130px]">
                    <div className="font-bold text-slate-900 truncate">{trt.name}</div>
                    <span className="text-[10px] text-slate-400 font-normal font-mono">{trt.category || 'General'}</span>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              {filteredStations.map((st) => (
                <tr key={st.id} className="hover:bg-slate-50/40 transition-colors">
                  <td className="py-3 px-4 sticky left-0 bg-white z-10 border-r border-slate-200 font-semibold text-slate-900 shadow-2xs">
                    <div>{st.name}</div>
                    <div className="text-[10px] text-slate-500 font-normal">
                      {st.department} • Cap: {st.capacity}
                    </div>
                  </td>

                  {filteredTreatments.map((trt) => {
                    const cap = capabilities.find(
                      (c) => c.stationId === st.id && c.treatmentId === trt.id
                    );
                    const isCapAllowed = cap?.isAllowed ?? false;

                    return (
                      <td key={trt.id} className="py-2.5 px-3 text-center border-l border-slate-100">
                        {cap ? (
                          <div className="flex flex-col items-center gap-1">
                            <button
                              onClick={() => onToggleAllowed(st.id, trt.id)}
                              className={`w-7 h-7 rounded-full flex items-center justify-center transition-all shadow-2xs ${
                                isCapAllowed
                                  ? 'bg-emerald-600 text-white hover:bg-emerald-700'
                                  : 'bg-slate-100 text-slate-400 hover:bg-slate-200 border border-slate-200'
                              }`}
                              title={isCapAllowed ? 'Click to disable' : 'Click to enable'}
                            >
                              {isCapAllowed ? <Check className="w-4 h-4 stroke-[2.5]" /> : <X className="w-3.5 h-3.5" />}
                            </button>

                            {isCapAllowed && (
                              <div
                                onClick={() => handleOpenEdit(cap)}
                                className="cursor-pointer group flex flex-col items-center text-[10px]"
                              >
                                <span className="font-mono text-slate-600 group-hover:text-teal-700">
                                  {cap.durationMinutes}m
                                </span>
                                <span className="text-[9px] text-slate-400 group-hover:text-teal-600 underline">
                                  {cap.attentionMode === 'EXCLUSIVE'
                                    ? '1:1'
                                    : cap.attentionMode === 'SHARED'
                                    ? `Shared (${cap.maximumParallelPatients})`
                                    : 'Unattended'}
                                </span>
                              </div>
                            )}
                          </div>
                        ) : (
                          <span className="text-slate-300">-</span>
                        )}
                      </td>
                    );
                  })}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        /* View Mode 2: Detailed List Table */
        <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-2xs">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-slate-200 bg-slate-50/70 text-slate-600 font-semibold">
                <th className="py-3 px-4">Room</th>
                <th className="py-3 px-4">Treatment Modality</th>
                <th className="py-3 px-4 text-center">Compatibility</th>
                <th className="py-3 px-4 text-center">Default Duration</th>
                <th className="py-3 px-4">Attention Mode & Workload Ratio</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              {flattenedCaps.map((cap) => {
                const st = stations.find((s) => s.id === cap.stationId);
                const trt = treatments.find((t) => t.id === cap.treatmentId);

                return (
                  <tr key={cap.id} className="hover:bg-slate-50/50 transition-colors">
                    <td className="py-3 px-4 font-bold text-slate-900">
                      {st?.name}
                      <span className="text-[10px] text-slate-500 font-normal block">{st?.department}</span>
                    </td>
                    <td className="py-3 px-4 text-slate-800 font-medium">
                      {trt?.name}
                      <span className="text-[10px] text-slate-400 font-normal block">{trt?.category}</span>
                    </td>
                    <td className="py-3 px-4 text-center">
                      <button
                        onClick={() => onToggleAllowed(cap.stationId, cap.treatmentId)}
                        className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold ${
                          cap.isAllowed
                            ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                            : 'bg-slate-100 text-slate-500 border border-slate-200'
                        }`}
                      >
                        {cap.isAllowed ? (
                          <>
                            <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                            <span>Allowed</span>
                          </>
                        ) : (
                          <>
                            <XCircle className="w-3 h-3 text-slate-400" />
                            <span>Disabled</span>
                          </>
                        )}
                      </button>
                    </td>
                    <td className="py-3 px-4 text-center font-mono font-medium">
                      {cap.durationMinutes} mins
                    </td>
                    <td className="py-3 px-4">
                      <AttentionModeBadge
                        mode={cap.attentionMode}
                        maxParallel={cap.maximumParallelPatients}
                      />
                    </td>
                    <td className="py-3 px-4 text-right">
                      <button
                        onClick={() => handleOpenEdit(cap)}
                        className="px-2.5 py-1 text-xs text-teal-700 hover:text-teal-900 hover:bg-teal-50 font-semibold rounded transition-colors"
                      >
                        Edit Rule
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      {/* Edit Capability Rule Modal */}
      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title="Configure Room Treatment Capability"
        subtitle="Manage clinical attention modes, parallel limits, and durations"
        maxWidthClass="max-w-md"
      >
        {editingCap && (
          <form onSubmit={handleSave} className="space-y-4">
            <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 text-xs space-y-1">
              <div className="flex justify-between">
                <span className="text-slate-500">Room:</span>
                <strong className="text-slate-900">
                  {stations.find((s) => s.id === editingCap.stationId)?.name}
                </strong>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Treatment Modality:</span>
                <strong className="text-teal-800">
                  {treatments.find((t) => t.id === editingCap.treatmentId)?.name}
                </strong>
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Capability Permission:
              </label>
              <select
                value={isAllowed ? 'ALLOWED' : 'DISABLED'}
                onChange={(e) => setIsAllowed(e.target.value === 'ALLOWED')}
                className="w-full text-xs p-2 bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-teal-500"
              >
                <option value="ALLOWED">Allowed (Room is equipped for this treatment)</option>
                <option value="DISABLED">Disabled (Room cannot deliver this treatment)</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Default Duration (Minutes):
              </label>
              <input
                type="number"
                min="5"
                max="240"
                step="5"
                required
                value={duration}
                onChange={(e) => setDuration(Number(e.target.value))}
                className="w-full text-xs p-2 bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-teal-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Attention Mode:
              </label>
              <select
                value={attentionMode}
                onChange={(e) => setAttentionMode(e.target.value as AttentionMode)}
                className="w-full text-xs p-2 bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-teal-500"
              >
                <option value="EXCLUSIVE">EXCLUSIVE (1:1 Practitioner hands-on dedication required)</option>
                <option value="SHARED">SHARED (Practitioner can supervise multiple concurrent patients)</option>
                <option value="UNATTENDED">UNATTENDED (Equipment runs independently after setup)</option>
              </select>
            </div>

            {attentionMode === 'SHARED' && (
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Maximum Parallel Patients:
                </label>
                <input
                  type="number"
                  min="2"
                  max="8"
                  required
                  value={maxParallel}
                  onChange={(e) => setMaxParallel(Number(e.target.value))}
                  className="w-full text-xs p-2 bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-teal-500"
                />
                <span className="text-[11px] text-slate-500 mt-1 block">
                  Validation will trigger a warning if practitioner workload exceeds this concurrent threshold.
                </span>
              </div>
            )}

            <div className="flex justify-end gap-2 pt-3 border-t border-slate-200">
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-lg transition-colors"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-2 text-xs font-semibold bg-teal-600 hover:bg-teal-700 text-white rounded-lg shadow-xs transition-colors"
              >
                Save Capability Rule
              </button>
            </div>
          </form>
        )}
      </Modal>
    </div>
  );
}
