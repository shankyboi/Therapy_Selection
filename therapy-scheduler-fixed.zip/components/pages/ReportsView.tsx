import React, { useState } from 'react';
import {
  TreatmentAllocation,
  Patient,
  Treatment,
  Station,
  Practitioner,
  TreatmentOrder,
  TreatmentOccurrence,
  AllocationStatus,
} from '@/types/therapy';
import { AllocationStatusBadge, PriorityBadge } from '@/components/StatusBadge';
import { timeToMinutes } from '@/lib/validation';
import {
  FileSpreadsheet,
  Download,
  Search,
  Filter,
  Calendar,
  ChevronRight,
  TrendingUp,
  CheckCircle2,
  XCircle,
  Clock,
} from 'lucide-react';

interface ReportsViewProps {
  allocations: TreatmentAllocation[];
  patients: Patient[];
  treatments: Treatment[];
  stations: Station[];
  practitioners: Practitioner[];
  orders: TreatmentOrder[];
  occurrences: TreatmentOccurrence[];
  onSelectAllocation: (allocation: TreatmentAllocation) => void;
}

export function ReportsView({
  allocations,
  patients,
  treatments,
  stations,
  practitioners,
  orders,
  occurrences,
  onSelectAllocation,
}: ReportsViewProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStationId, setFilterStationId] = useState('ALL');
  const [filterTreatmentId, setFilterTreatmentId] = useState('ALL');
  const [filterStatus, setFilterStatus] = useState<string>('ALL');
  const [filterPractitionerId, setFilterPractitionerId] = useState('ALL');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');

  // Filter allocations
  const filtered = allocations.filter((alloc) => {
    const occ = occurrences.find((o) => o.id === alloc.treatmentOccurrenceId);
    const ord = occ ? orders.find((o) => o.id === occ.treatmentOrderId) : null;
    const pat = ord ? patients.find((p) => p.id === ord.patientId) : null;
    const trt = ord ? treatments.find((t) => t.id === ord.treatmentId) : null;
    const prac = practitioners.find((p) => p.id === (alloc.actualPractitionerId || alloc.plannedPractitionerId));

    if (startDate && alloc.date < startDate) return false;
    if (endDate && alloc.date > endDate) return false;

    if (filterStationId !== 'ALL' && alloc.stationId !== filterStationId) return false;
    if (filterTreatmentId !== 'ALL' && ord?.treatmentId !== filterTreatmentId) return false;
    if (filterStatus !== 'ALL' && alloc.status !== filterStatus) return false;
    if (
      filterPractitionerId !== 'ALL' &&
      alloc.plannedPractitionerId !== filterPractitionerId &&
      alloc.actualPractitionerId !== filterPractitionerId
    ) {
      return false;
    }

    if (searchTerm) {
      const term = searchTerm.toLowerCase();
      const matchPat = pat?.displayName.toLowerCase().includes(term) || pat?.externalPatientId.toLowerCase().includes(term);
      const matchTrt = trt?.name.toLowerCase().includes(term);
      const matchPrac = prac?.displayName.toLowerCase().includes(term);
      const matchAlloc = alloc.id.toLowerCase().includes(term);
      if (!matchPat && !matchTrt && !matchPrac && !matchAlloc) return false;
    }

    return true;
  });

  // Calculate high level metrics
  const totalCount = filtered.length;
  const completedCount = filtered.filter((a) => a.status === 'COMPLETED').length;
  const inProgressCount = filtered.filter((a) => a.status === 'IN_PROGRESS').length;
  const cancelledCount = filtered.filter((a) => a.status === 'CANCELLED').length;
  const noShowCount = filtered.filter((a) => a.status === 'NO_SHOW').length;

  const totalMinutes = filtered
    .filter((a) => a.status === 'COMPLETED' || a.status === 'IN_PROGRESS')
    .reduce((sum, a) => sum + (timeToMinutes(a.plannedEnd) - timeToMinutes(a.plannedStart)), 0);

  const noShowRate = totalCount > 0 ? ((noShowCount / totalCount) * 100).toFixed(1) : '0';

  // Export to CSV
  const handleExportCSV = () => {
    const headers = [
      'Allocation ID',
      'Date',
      'Start Time',
      'End Time',
      'Room',
      'Patient Name',
      'Patient ID',
      'Treatment Modality',
      'Session #',
      'Planned Practitioner',
      'Actual Practitioner',
      'Status',
      'Override Reason',
    ];

    const rows = filtered.map((a) => {
      const occ = occurrences.find((o) => o.id === a.treatmentOccurrenceId);
      const ord = occ ? orders.find((o) => o.id === occ.treatmentOrderId) : null;
      const pat = ord ? patients.find((p) => p.id === ord.patientId) : null;
      const trt = ord ? treatments.find((t) => t.id === ord.treatmentId) : null;
      const st = stations.find((s) => s.id === a.stationId);
      const plannedP = practitioners.find((p) => p.id === a.plannedPractitionerId);
      const actualP = practitioners.find((p) => p.id === a.actualPractitionerId);

      return [
        `"${a.id}"`,
        `"${a.date}"`,
        `"${a.plannedStart}"`,
        `"${a.plannedEnd}"`,
        `"${st?.name || ''}"`,
        `"${pat?.displayName || ''}"`,
        `"${pat?.externalPatientId || ''}"`,
        `"${trt?.name || ''}"`,
        `"${occ?.sessionNumber || 1}"`,
        `"${plannedP?.displayName || ''}"`,
        `"${actualP?.displayName || ''}"`,
        `"${a.status}"`,
        `"${a.overrideReason || ''}"`,
      ].join(',');
    });

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `Therapy_Scheduler_Report_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div id="reports-view-container" className="max-w-7xl mx-auto px-4 sm:px-6 py-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 pb-4">
        <div>
          <div className="flex items-center gap-2 text-teal-700 text-xs font-bold uppercase tracking-wider mb-1">
            <FileSpreadsheet className="w-4 h-4" />
            <span>Clinical Audit & Analytics</span>
          </div>
          <h2 className="text-xl font-bold text-slate-900">Treatment Allocations & Audit Report</h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Search, filter, and export comprehensive therapy session logs and practitioner delivery metrics.
          </p>
        </div>

        <button
          id="btn-export-csv"
          onClick={handleExportCSV}
          className="px-4 py-2 bg-slate-800 hover:bg-slate-900 text-white font-semibold text-xs rounded-xl shadow-xs flex items-center gap-1.5 transition-colors self-start sm:self-auto"
        >
          <Download className="w-4 h-4 text-teal-400" />
          <span>Export Filtered CSV</span>
        </button>
      </div>

      {/* Analytics Summary Badges */}
      <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-5 gap-3">
        <div className="p-3 bg-white border border-slate-200 rounded-xl">
          <span className="text-[11px] text-slate-500 font-medium block">Total Filtered</span>
          <span className="text-xl font-bold text-slate-900">{totalCount} sessions</span>
        </div>
        <div className="p-3 bg-white border border-slate-200 rounded-xl">
          <span className="text-[11px] text-slate-500 font-medium block">Completed</span>
          <span className="text-xl font-bold text-emerald-700">{completedCount}</span>
        </div>
        <div className="p-3 bg-white border border-slate-200 rounded-xl">
          <span className="text-[11px] text-slate-500 font-medium block">Care Hours Delivered</span>
          <span className="text-xl font-bold text-teal-700">{(totalMinutes / 60).toFixed(1)} hrs</span>
        </div>
        <div className="p-3 bg-white border border-slate-200 rounded-xl">
          <span className="text-[11px] text-slate-500 font-medium block">No-Shows</span>
          <span className="text-xl font-bold text-zinc-700">{noShowCount}</span>
        </div>
        <div className="p-3 bg-white border border-slate-200 rounded-xl">
          <span className="text-[11px] text-slate-500 font-medium block">No-Show Rate</span>
          <span className="text-xl font-bold text-rose-700">{noShowRate}%</span>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200 space-y-3 text-xs">
        <div className="flex flex-wrap items-center gap-3">
          <div className="relative flex-1 min-w-[200px]">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search patient, ID, modality, or therapist..."
              className="w-full pl-8 pr-3 py-1.5 bg-white border border-slate-200 rounded-lg text-xs"
            />
          </div>

          <div className="flex items-center gap-1 bg-white border border-slate-200 px-2 py-1 rounded-lg">
            <span className="text-slate-500 text-[11px]">From:</span>
            <input
              type="date"
              value={startDate}
              onChange={(e) => setStartDate(e.target.value)}
              className="text-xs focus:outline-hidden"
            />
          </div>

          <div className="flex items-center gap-1 bg-white border border-slate-200 px-2 py-1 rounded-lg">
            <span className="text-slate-500 text-[11px]">To:</span>
            <input
              type="date"
              value={endDate}
              onChange={(e) => setEndDate(e.target.value)}
              className="text-xs focus:outline-hidden"
            />
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-3 pt-2 border-t border-slate-200/70">
          <div className="flex items-center gap-1.5">
            <span className="text-slate-500">Room:</span>
            <select
              value={filterStationId}
              onChange={(e) => setFilterStationId(e.target.value)}
              className="bg-white border border-slate-200 rounded px-2 py-1 text-xs"
            >
              <option value="ALL">All Rooms</option>
              {stations.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name}
                </option>
              ))}
            </select>
          </div>

          <div className="flex items-center gap-1.5">
            <span className="text-slate-500">Modality:</span>
            <select
              value={filterTreatmentId}
              onChange={(e) => setFilterTreatmentId(e.target.value)}
              className="bg-white border border-slate-200 rounded px-2 py-1 text-xs"
            >
              <option value="ALL">All Treatments</option>
              {treatments.map((t) => (
                <option key={t.id} value={t.id}>
                  {t.name}
                </option>
              ))}
            </select>
          </div>

          <div className="flex items-center gap-1.5">
            <span className="text-slate-500">Status:</span>
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
              className="bg-white border border-slate-200 rounded px-2 py-1 text-xs"
            >
              <option value="ALL">All Statuses</option>
              <option value="CONFIRMED">Confirmed</option>
              <option value="CHECKED_IN">Checked In</option>
              <option value="IN_PROGRESS">In Progress</option>
              <option value="COMPLETED">Completed</option>
              <option value="CANCELLED">Cancelled</option>
              <option value="NO_SHOW">No-Show</option>
            </select>
          </div>

          <div className="flex items-center gap-1.5">
            <span className="text-slate-500">Practitioner:</span>
            <select
              value={filterPractitionerId}
              onChange={(e) => setFilterPractitionerId(e.target.value)}
              className="bg-white border border-slate-200 rounded px-2 py-1 text-xs"
            >
              <option value="ALL">All Practitioners</option>
              {practitioners.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.displayName}
                </option>
              ))}
            </select>
          </div>

          {(searchTerm ||
            startDate ||
            endDate ||
            filterStationId !== 'ALL' ||
            filterTreatmentId !== 'ALL' ||
            filterStatus !== 'ALL' ||
            filterPractitionerId !== 'ALL') && (
            <button
              onClick={() => {
                setSearchTerm('');
                setStartDate('');
                setEndDate('');
                setFilterStationId('ALL');
                setFilterTreatmentId('ALL');
                setFilterStatus('ALL');
                setFilterPractitionerId('ALL');
              }}
              className="text-rose-600 hover:text-rose-800 text-xs font-semibold underline ml-auto"
            >
              Reset Filters
            </button>
          )}
        </div>
      </div>

      {/* Table of Allocations */}
      <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-2xs">
        <table className="w-full text-left text-xs border-collapse">
          <thead>
            <tr className="border-b border-slate-200 bg-slate-50/70 text-slate-600 font-semibold">
              <th className="py-3 px-4">Session Date & Time</th>
              <th className="py-3 px-4">Patient Profile</th>
              <th className="py-3 px-4">Treatment Prescribed</th>
              <th className="py-3 px-4">Assigned Room</th>
              <th className="py-3 px-4">Practitioner Care</th>
              <th className="py-3 px-4 text-center">Status</th>
              <th className="py-3 px-4 text-right">Details</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 text-slate-700">
            {filtered.length === 0 ? (
              <tr>
                <td colSpan={7} className="py-8 text-center text-slate-400">
                  No therapy allocations match your filter criteria.
                </td>
              </tr>
            ) : (
              filtered.map((alloc) => {
                const occ = occurrences.find((o) => o.id === alloc.treatmentOccurrenceId);
                const ord = occ ? orders.find((o) => o.id === occ.treatmentOrderId) : null;
                const pat = ord ? patients.find((p) => p.id === ord.patientId) : null;
                const trt = ord ? treatments.find((t) => t.id === ord.treatmentId) : null;
                const st = stations.find((s) => s.id === alloc.stationId);
                const plannedP = practitioners.find((p) => p.id === alloc.plannedPractitionerId);
                const actualP = practitioners.find((p) => p.id === alloc.actualPractitionerId);

                return (
                  <tr
                    key={alloc.id}
                    onClick={() => onSelectAllocation(alloc)}
                    className="hover:bg-slate-50/70 cursor-pointer transition-colors"
                  >
                    <td className="py-3 px-4">
                      <div className="font-bold text-slate-900">{alloc.date}</div>
                      <span className="font-mono text-slate-500 text-[11px]">
                        {alloc.plannedStart} - {alloc.plannedEnd}
                      </span>
                    </td>

                    <td className="py-3 px-4">
                      <div className="font-bold text-slate-900">{pat?.displayName}</div>
                      <span className="text-[10px] text-slate-400 font-mono">
                        {pat?.externalPatientId} • {pat?.gender}, {pat?.age}y
                      </span>
                    </td>

                    <td className="py-3 px-4">
                      <div className="font-semibold text-teal-900">{trt?.name}</div>
                      <span className="text-[10px] text-slate-500">
                        Session {occ?.sessionNumber || 1} of {ord?.totalSessions || 1}
                      </span>
                    </td>

                    <td className="py-3 px-4">
                      <div className="font-medium text-slate-800">{st?.name}</div>
                      <span className="text-[10px] text-slate-400">{st?.location}</span>
                    </td>

                    <td className="py-3 px-4">
                      <div className="text-slate-800 font-medium">
                        {actualP?.displayName || plannedP?.displayName || 'Unassigned'}
                      </div>
                      {actualP && actualP.id !== plannedP?.id && (
                        <span className="text-[10px] text-purple-700 font-semibold block">
                          Handover Takeover
                        </span>
                      )}
                    </td>

                    <td className="py-3 px-4 text-center">
                      <AllocationStatusBadge status={alloc.status} />
                    </td>

                    <td className="py-3 px-4 text-right">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onSelectAllocation(alloc);
                        }}
                        className="p-1 text-slate-400 hover:text-teal-700 rounded"
                      >
                        <ChevronRight className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
