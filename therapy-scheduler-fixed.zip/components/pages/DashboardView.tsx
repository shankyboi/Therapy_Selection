import React from 'react';
import {
  Station,
  StationType,
  Practitioner,
  StationPractitionerRoster,
  Patient,
  TreatmentOrder,
  TreatmentOccurrence,
  TreatmentAllocation,
  StationTreatmentCapability,
  Treatment,
  ActivePage,
} from '@/types/therapy';
import { PriorityBadge, AllocationStatusBadge, AttentionModeBadge } from '@/components/StatusBadge';
import { timeToMinutes } from '@/lib/validation';
import {
  FileCheck2,
  CalendarCheck,
  ClockAlert,
  PlayCircle,
  CheckCircle2,
  XCircle,
  UserX,
  BedDouble,
  AlertTriangle,
  Flame,
  ArrowRight,
  TrendingUp,
  User,
  Stethoscope,
  Activity,
  Layers,
  ChevronRight,
} from 'lucide-react';

interface DashboardViewProps {
  selectedDate: string;
  stations: Station[];
  stationTypes: StationType[];
  practitioners: Practitioner[];
  rosters: StationPractitionerRoster[];
  orders: TreatmentOrder[];
  occurrences: TreatmentOccurrence[];
  allocations: TreatmentAllocation[];
  patients: Patient[];
  treatments: Treatment[];
  capabilities: StationTreatmentCapability[];
  onNavigate: (page: ActivePage) => void;
  onSelectAllocation: (allocation: TreatmentAllocation) => void;
  onQuickScheduleOccurrence: (occurrence: TreatmentOccurrence) => void;
}

export function DashboardView({
  selectedDate,
  stations,
  stationTypes,
  practitioners,
  rosters,
  orders,
  occurrences,
  allocations,
  patients,
  treatments,
  capabilities,
  onNavigate,
  onSelectAllocation,
  onQuickScheduleOccurrence,
}: DashboardViewProps) {
  // Compute Dashboard Metrics
  const dateOrders = orders.filter(
    (o) => o.earliestAllowedDate <= selectedDate && o.latestAllowedDate >= selectedDate
  );
  const dateAllocations = allocations.filter((a) => a.date === selectedDate);
  const activeDateAllocations = dateAllocations.filter((a) => a.status !== 'CANCELLED');

  const treatmentsOrderedCount = dateOrders.length;
  const treatmentsScheduledCount = activeDateAllocations.length;
  const unscheduledOccurrences = occurrences.filter((o) => o.status === 'UNSCHEDULED');
  const unscheduledCount = unscheduledOccurrences.length;

  const inProgressCount = dateAllocations.filter((a) => a.status === 'IN_PROGRESS').length;
  const completedCount = dateAllocations.filter((a) => a.status === 'COMPLETED').length;
  const cancelledCount = dateAllocations.filter((a) => a.status === 'CANCELLED').length;
  const noShowCount = dateAllocations.filter((a) => a.status === 'NO_SHOW').length;

  // Stations without practitioner assignment today
  const activeStations = stations.filter((s) => s.isActive);
  const dateRosters = rosters.filter((r) => r.date === selectedDate);
  const stationsWithoutPractitioner = activeStations.filter((s) => {
    const r = dateRosters.find((rost) => rost.stationId === s.id);
    return !r || !r.primaryPractitionerId;
  });

  // Stations currently available (Capacity minus active allocations during working hours)
  const totalStationCapacity = activeStations.reduce((sum, s) => sum + s.capacity, 0);
  const stationsAvailableCount = Math.max(
    0,
    activeStations.length -
      new Set(activeDateAllocations.map((a) => a.stationId)).size
  );

  // Station Utilization Rate Calculation (Total allocated hours / Total available operational hours: 10 hrs * capacity)
  const totalAvailableMinutes = totalStationCapacity * (10 * 60); // 10 operating hours (08:00 - 18:00)
  const totalAllocatedMinutes = activeDateAllocations.reduce((sum, a) => {
    return sum + (timeToMinutes(a.plannedEnd) - timeToMinutes(a.plannedStart));
  }, 0);
  const utilizationPercentage = totalAvailableMinutes > 0
    ? Math.min(100, Math.round((totalAllocatedMinutes / totalAvailableMinutes) * 100))
    : 0;

  // Practitioner Workload Summary
  const practitionerWorkloads = practitioners
    .filter((p) => p.isActive)
    .map((prac) => {
      // Rostered stations today
      const assignedRosters = dateRosters.filter(
        (r) => r.primaryPractitionerId === prac.id || r.backupPractitionerId === prac.id
      );
      const isPrimaryOn = assignedRosters.filter((r) => r.primaryPractitionerId === prac.id);
      const isBackupOn = assignedRosters.filter((r) => r.backupPractitionerId === prac.id);

      // Allocations assigned to this practitioner
      const pracAllocations = activeDateAllocations.filter(
        (a) =>
          a.plannedPractitionerId === prac.id ||
          a.actualPractitionerId === prac.id ||
          (!a.plannedPractitionerId && isPrimaryOn.some((r) => r.stationId === a.stationId))
      );

      const totalMinutesSupervised = pracAllocations.reduce((acc, a) => {
        return acc + (timeToMinutes(a.plannedEnd) - timeToMinutes(a.plannedStart));
      }, 0);

      return {
        practitioner: prac,
        primaryStationsCount: isPrimaryOn.length,
        backupStationsCount: isBackupOn.length,
        totalAllocations: pracAllocations.length,
        totalMinutesSupervised,
        inProgress: pracAllocations.filter((a) => a.status === 'IN_PROGRESS').length,
      };
    });

  // Urgent Unscheduled Treatments requiring attention
  const urgentUnscheduled = unscheduledOccurrences
    .map((occ) => {
      const ord = orders.find((o) => o.id === occ.treatmentOrderId);
      const pat = ord ? patients.find((p) => p.id === ord.patientId) : undefined;
      const trt = ord ? treatments.find((t) => t.id === ord.treatmentId) : undefined;
      return { occurrence: occ, order: ord, patient: pat, treatment: trt };
    })
    .filter((item) => item.order?.priority === 'URGENT' || item.order?.priority === 'HIGH');

  // Chronological upcoming allocations for today
  const sortedUpcoming = [...activeDateAllocations].sort(
    (a, b) => timeToMinutes(a.plannedStart) - timeToMinutes(b.plannedStart)
  );

  return (
    <div id="dashboard-view-container" className="max-w-7xl mx-auto px-4 sm:px-6 py-6 space-y-6">
      {/* Top Welcome & Quick Actions Banner */}
      <div className="bg-gradient-to-r from-teal-800 to-slate-900 rounded-2xl p-6 text-white shadow-lg flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-teal-300 text-xs font-bold uppercase tracking-wider mb-1">
            <Activity className="w-4 h-4" />
            <span>Clinical Operations Center</span>
          </div>
          <h2 className="text-2xl font-black tracking-tight">Daily Therapy Operations Dashboard</h2>
          <p className="text-teal-100/80 text-xs sm:text-sm mt-1">
            Scheduling status, practitioner roster load, and room utilization for{' '}
            <strong className="text-white">{selectedDate}</strong>
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            id="btn-dash-open-scheduler"
            onClick={() => onNavigate('scheduler')}
            className="px-4 py-2 bg-teal-500 hover:bg-teal-400 active:bg-teal-600 text-slate-950 font-bold text-xs rounded-xl shadow-md flex items-center gap-1.5 transition-colors"
          >
            <span>Open Day Scheduler</span>
            <ArrowRight className="w-4 h-4" />
          </button>
          <button
            id="btn-dash-open-planner"
            onClick={() => onNavigate('practitioner-planner')}
            className="px-4 py-2 bg-white/10 hover:bg-white/20 text-white font-semibold text-xs rounded-xl border border-white/20 transition-colors"
          >
            Practitioner Shifts
          </button>
        </div>
      </div>

      {/* 9 Summary Cards Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-3.5">
        {/* Card 1: Ordered Today */}
        <MetricCard
          id="metric-ordered-today"
          label="Ordered Treatments"
          value={treatmentsOrderedCount}
          subtitle="Prescribed in active window"
          icon={<FileCheck2 className="w-4 h-4 text-teal-600" />}
          bgColor="bg-teal-50/70"
          borderColor="border-teal-200"
        />

        {/* Card 2: Scheduled Today */}
        <MetricCard
          id="metric-scheduled-today"
          label="Scheduled Today"
          value={treatmentsScheduledCount}
          subtitle="Allocated to stations"
          icon={<CalendarCheck className="w-4 h-4 text-blue-600" />}
          bgColor="bg-blue-50/70"
          borderColor="border-blue-200"
        />

        {/* Card 3: Unscheduled */}
        <MetricCard
          id="metric-unscheduled"
          label="Unscheduled Pool"
          value={unscheduledCount}
          subtitle="Pending slot placement"
          icon={<ClockAlert className="w-4 h-4 text-amber-600" />}
          bgColor="bg-amber-50/70"
          borderColor="border-amber-200"
          highlight={unscheduledCount > 0}
        />

        {/* Card 4: In Progress */}
        <MetricCard
          id="metric-in-progress"
          label="In Progress"
          value={inProgressCount}
          subtitle="Active therapy underway"
          icon={<PlayCircle className="w-4 h-4 text-emerald-600" />}
          bgColor="bg-emerald-50/70"
          borderColor="border-emerald-200"
        />

        {/* Card 5: Completed */}
        <MetricCard
          id="metric-completed"
          label="Completed Today"
          value={completedCount}
          subtitle="Finished sessions"
          icon={<CheckCircle2 className="w-4 h-4 text-slate-600" />}
          bgColor="bg-slate-50"
          borderColor="border-slate-200"
        />

        {/* Card 6: Cancelled */}
        <MetricCard
          id="metric-cancelled"
          label="Cancelled"
          value={cancelledCount}
          subtitle="Rescheduled or revoked"
          icon={<XCircle className="w-4 h-4 text-rose-600" />}
          bgColor="bg-rose-50/60"
          borderColor="border-rose-200"
        />

        {/* Card 7: No-Shows */}
        <MetricCard
          id="metric-noshow"
          label="No-Shows"
          value={noShowCount}
          subtitle="Patient absent"
          icon={<UserX className="w-4 h-4 text-zinc-600" />}
          bgColor="bg-zinc-100/70"
          borderColor="border-zinc-200"
        />

        {/* Card 8: Available Stations */}
        <MetricCard
          id="metric-available-stations"
          label="Available Rooms"
          value={`${stationsAvailableCount} / ${activeStations.length}`}
          subtitle="With open slots"
          icon={<BedDouble className="w-4 h-4 text-teal-600" />}
          bgColor="bg-teal-50/50"
          borderColor="border-teal-200"
        />

        {/* Card 9: Stations Without Practitioner (Alert) */}
        <MetricCard
          id="metric-unassigned-stations"
          label="Unassigned Rooms"
          value={stationsWithoutPractitioner.length}
          subtitle="Missing primary roster"
          icon={<AlertTriangle className="w-4 h-4 text-amber-600" />}
          bgColor={stationsWithoutPractitioner.length > 0 ? 'bg-amber-50' : 'bg-slate-50'}
          borderColor={stationsWithoutPractitioner.length > 0 ? 'border-amber-300' : 'border-slate-200'}
          alert={stationsWithoutPractitioner.length > 0}
        />
      </div>

      {/* Row 2: Station Utilization & Practitioner Workload Summary */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Station Utilization Gauge Card */}
        <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-2xs space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-teal-600" />
              <h3 className="font-bold text-slate-900 text-sm">Room Utilization</h3>
            </div>
            <span className="text-xs font-semibold text-slate-500">08:00 - 18:00</span>
          </div>

          <div className="space-y-2">
            <div className="flex items-baseline justify-between">
              <span className="text-3xl font-black text-slate-900">{utilizationPercentage}%</span>
              <span className="text-xs text-slate-500 font-medium">
                {Math.round(totalAllocatedMinutes / 60)}h allocated of {Math.round(totalAvailableMinutes / 60)}h total
              </span>
            </div>
            <div className="w-full bg-slate-100 rounded-full h-3 overflow-hidden border border-slate-200">
              <div
                className="bg-teal-600 h-full rounded-full transition-all duration-500"
                style={{ width: `${utilizationPercentage}%` }}
              />
            </div>
          </div>

          {/* Breakdown by station type */}
          <div className="space-y-2 pt-2 border-t border-slate-100 text-xs">
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">
              Active Room Types
            </span>
            {stationTypes.map((st) => {
              const matchedStations = activeStations.filter((s) => s.stationTypeId === st.id);
              const matchedAllocations = activeDateAllocations.filter((a) =>
                matchedStations.some((s) => s.id === a.stationId)
              );
              return (
                <div key={st.id} className="flex items-center justify-between text-slate-700">
                  <span className="truncate">{st.name} ({matchedStations.length} units)</span>
                  <span className="font-semibold text-slate-900">{matchedAllocations.length} sessions</span>
                </div>
              );
            })}
          </div>

          <button
            onClick={() => onNavigate('stations')}
            className="w-full py-1.5 text-xs text-teal-700 hover:text-teal-900 font-semibold bg-teal-50 hover:bg-teal-100 rounded-lg transition-colors"
          >
            Manage Rooms & Capacity →
          </button>
        </div>

        {/* Practitioner Workload Distribution Table (2 Cols Span) */}
        <div className="lg:col-span-2 bg-white rounded-xl border border-slate-200 p-5 shadow-2xs space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <User className="w-4 h-4 text-teal-600" />
              <h3 className="font-bold text-slate-900 text-sm">Practitioner Workload Summary</h3>
            </div>
            <button
              onClick={() => onNavigate('practitioner-planner')}
              className="text-xs text-teal-700 hover:text-teal-900 font-semibold"
            >
              Open Shift Planner →
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-slate-200 text-slate-500 font-semibold bg-slate-50/70">
                  <th className="py-2 px-3">Practitioner</th>
                  <th className="py-2 px-2">Department</th>
                  <th className="py-2 px-2 text-center">Rostered Rooms</th>
                  <th className="py-2 px-2 text-center">Allocated Sessions</th>
                  <th className="py-2 px-2 text-center">Total Hours</th>
                  <th className="py-2 px-2 text-center">Live Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-700">
                {practitionerWorkloads.map((pw) => (
                  <tr key={pw.practitioner.id} className="hover:bg-slate-50/60 transition-colors">
                    <td className="py-2.5 px-3">
                      <div className="font-bold text-slate-900">{pw.practitioner.displayName}</div>
                      <div className="text-[10px] text-slate-500">{pw.practitioner.title}</div>
                    </td>
                    <td className="py-2.5 px-2 text-slate-600">{pw.practitioner.department}</td>
                    <td className="py-2.5 px-2 text-center">
                      <span className="font-semibold text-slate-800">
                        {pw.primaryStationsCount} Primary
                      </span>
                      {pw.backupStationsCount > 0 && (
                        <span className="text-[10px] text-slate-500 block">
                          +{pw.backupStationsCount} Backup
                        </span>
                      )}
                    </td>
                    <td className="py-2.5 px-2 text-center font-bold text-slate-900">
                      {pw.totalAllocations}
                    </td>
                    <td className="py-2.5 px-2 text-center font-mono text-slate-700">
                      {(pw.totalMinutesSupervised / 60).toFixed(1)} hrs
                    </td>
                    <td className="py-2.5 px-2 text-center">
                      {pw.inProgress > 0 ? (
                        <span className="inline-flex items-center gap-1 text-[10px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
                          <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-ping" />
                          {pw.inProgress} Active
                        </span>
                      ) : pw.totalAllocations > 0 ? (
                        <span className="text-[10px] text-slate-600 bg-slate-100 px-2 py-0.5 rounded-full">
                          Scheduled
                        </span>
                      ) : (
                        <span className="text-[10px] text-slate-400">Available</span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Row 3: Treatments Requiring Attention & Upcoming Allocations Stream */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Treatments Requiring Attention */}
        <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-2xs space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Flame className="w-4 h-4 text-rose-600" />
              <h3 className="font-bold text-slate-900 text-sm">Treatments Requiring Attention</h3>
            </div>
            <span className="text-xs font-bold text-rose-700 bg-rose-50 px-2 py-0.5 rounded-full border border-rose-200">
              {urgentUnscheduled.length} Urgent / High
            </span>
          </div>

          <div className="space-y-2.5 max-h-72 overflow-y-auto pr-1">
            {urgentUnscheduled.length === 0 ? (
              <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-lg text-xs text-emerald-800 text-center">
                All urgent prescriptions are currently allocated!
              </div>
            ) : (
              urgentUnscheduled.map(({ occurrence, order, patient, treatment }) => (
                <div
                  key={occurrence.id}
                  className="p-3 bg-rose-50/40 border border-rose-200 rounded-lg flex items-center justify-between text-xs gap-3 hover:bg-rose-50 transition-colors"
                >
                  <div className="min-w-0 space-y-0.5">
                    <div className="flex items-center gap-2">
                      <strong className="text-slate-900 truncate">{patient?.displayName}</strong>
                      <PriorityBadge priority={order?.priority || 'HIGH'} />
                    </div>
                    <div className="text-teal-800 font-medium truncate">{treatment?.name}</div>
                    <div className="text-[11px] text-slate-500">
                      Duration: {occurrence.expectedDurationMinutes}m • Session {occurrence.sessionNumber} of{' '}
                      {order?.totalSessions}
                    </div>
                  </div>

                  <button
                    onClick={() => {
                      onQuickScheduleOccurrence(occurrence);
                    }}
                    className="px-3 py-1.5 bg-teal-700 hover:bg-teal-800 text-white font-semibold text-xs rounded-lg shadow-xs shrink-0 flex items-center gap-1 transition-colors"
                  >
                    <span>Schedule</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))
            )}

            {/* Also show unassigned station warnings */}
            {stationsWithoutPractitioner.map((st) => (
              <div
                key={st.id}
                className="p-3 bg-amber-50 border border-amber-200 rounded-lg flex items-center justify-between text-xs"
              >
                <div className="flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />
                  <div>
                    <strong className="text-amber-900">{st.name}</strong>
                    <span className="text-amber-800 block text-[11px]">
                      No primary practitioner rostered today ({st.department})
                    </span>
                  </div>
                </div>
                <button
                  onClick={() => onNavigate('practitioner-planner')}
                  className="text-xs font-semibold text-amber-800 underline shrink-0 hover:text-amber-950"
                >
                  Assign Shift
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Upcoming Allocations Stream */}
        <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-2xs space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Activity className="w-4 h-4 text-teal-600" />
              <h3 className="font-bold text-slate-900 text-sm">Today&apos;s Scheduled Allocations</h3>
            </div>
            <button
              onClick={() => onNavigate('reports')}
              className="text-xs text-teal-700 hover:text-teal-900 font-semibold"
            >
              Full Allocation List →
            </button>
          </div>

          <div className="space-y-2 max-h-72 overflow-y-auto pr-1">
            {sortedUpcoming.length === 0 ? (
              <div className="p-4 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-500 text-center">
                No allocations scheduled yet for {selectedDate}.
              </div>
            ) : (
              sortedUpcoming.map((alloc) => {
                const occ = occurrences.find((o) => o.id === alloc.treatmentOccurrenceId);
                const ord = occ ? orders.find((o) => o.id === occ.treatmentOrderId) : undefined;
                const pat = ord ? patients.find((p) => p.id === ord.patientId) : undefined;
                const trt = ord ? treatments.find((t) => t.id === ord.treatmentId) : undefined;
                const st = stations.find((s) => s.id === alloc.stationId);
                const prac = practitioners.find(
                  (p) => p.id === (alloc.actualPractitionerId || alloc.plannedPractitionerId)
                );

                return (
                  <div
                    key={alloc.id}
                    onClick={() => onSelectAllocation(alloc)}
                    className="p-3 bg-slate-50/70 hover:bg-teal-50/50 border border-slate-200 rounded-lg flex items-center justify-between text-xs cursor-pointer transition-colors"
                  >
                    <div className="min-w-0 space-y-0.5">
                      <div className="flex items-center gap-2">
                        <strong className="text-slate-900 truncate">{pat?.displayName}</strong>
                        <span className="text-[10px] text-slate-500 font-mono">
                          {alloc.plannedStart} - {alloc.plannedEnd}
                        </span>
                      </div>
                      <div className="text-teal-800 font-medium truncate">
                        {trt?.name} • <span className="text-slate-600">{st?.name}</span>
                      </div>
                      <div className="text-[10px] text-slate-500">
                        Practitioner: {prac?.displayName || 'Unassigned'}
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <AllocationStatusBadge status={alloc.status} />
                      <ChevronRight className="w-4 h-4 text-slate-400" />
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

function MetricCard({
  id,
  label,
  value,
  subtitle,
  icon,
  bgColor,
  borderColor,
  highlight = false,
  alert = false,
}: {
  id: string;
  label: string;
  value: string | number;
  subtitle: string;
  icon: React.ReactNode;
  bgColor: string;
  borderColor: string;
  highlight?: boolean;
  alert?: boolean;
}) {
  return (
    <div
      id={id}
      className={`p-4 rounded-xl border ${bgColor} ${borderColor} shadow-2xs flex flex-col justify-between transition-all`}
    >
      <div className="flex items-center justify-between mb-2">
        <span className="text-xs font-semibold text-slate-700 leading-tight">{label}</span>
        <div className="p-1.5 rounded-lg bg-white/80 shadow-2xs">{icon}</div>
      </div>
      <div>
        <div
          className={`text-2xl font-black tracking-tight ${
            alert ? 'text-rose-700' : highlight ? 'text-amber-800' : 'text-slate-900'
          }`}
        >
          {value}
        </div>
        <div className="text-[10px] text-slate-500 mt-0.5 truncate">{subtitle}</div>
      </div>
    </div>
  );
}
