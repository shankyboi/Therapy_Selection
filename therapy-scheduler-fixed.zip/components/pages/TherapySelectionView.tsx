import React, { useState, useEffect } from 'react';
import { Patient, Treatment, PriorityLevel, TreatmentOrder } from '@/types/therapy';
import { Modal } from '@/components/Modal';
import { 
  Users, 
  Sparkles, 
  CheckCircle2, 
  Plus, 
  Trash2, 
  Clock, 
  FileText, 
  Layers, 
  ArrowRight,
  ShieldAlert,
  Search,
  Activity,
  ClipboardList
} from 'lucide-react';

interface TherapySelectionViewProps {
  patients: Patient[];
  treatments: Treatment[];
  orders: TreatmentOrder[];
  onCreateOrder: (
    patientId: string,
    treatmentId: string,
    totalSessions: number,
    earliestAllowedDate: string,
    latestAllowedDate: string,
    priority: PriorityLevel,
    instructions: string,
    customDuration: number
  ) => void;
  showToast: (msg: string, type: 'success' | 'info' | 'error') => void;
}

interface DraftSelection {
  id: string;
  treatmentId: string;
  treatmentName: string;
  customDuration: number;
  instructions: string;
  totalSessions: number;
}

const VARIATIONS_MAP: Record<string, Record<string, string[]>> = {
  'treat-manual': {
    'Manual Release Techniques': ['Myofascial Release', 'Trigger Point Therapy', 'Muscle Energy Technique', 'Passive Joint Mobilization'],
    'Dry Needling Modalities': ['Superficial Dry Needling', 'Deep Intramuscular Stimulation', 'Electro-Acupuncture Needling'],
    'Passive Stretching Protocols': ['Hamstring PNF Stretch', 'Cervical Traction Stretch', 'Shoulder Girdle Mobilization']
  },
  'treat-electro': {
    'Waveform Frequencies': ['TENS Pain Gate Modulation', 'IFT Interferential Current', 'Neuromuscular Electrical STIM', 'Russian Stimulation Muscle Re-ed'],
    'Pad Placements': ['Bilateral Channel A/B Pads', 'Quadpolar Spinal Alignment Pads', 'Trigger Point Concentrated Electrode']
  },
  'treat-heat': {
    'Thermotherapy Methods': ['Moist Hot Pack (6 layers)', 'Infrared Irradiation Lamp', 'Paraffin Wax Bath treatment', 'Fluidotherapy dry heat therapy'],
    'Essential Oils (Herbal)': ['Neem Oil Infusion', 'Eucalyptus Cooling Essence', 'Sesame Warming Oil', 'Mustard Deep Pain Oil', 'Hot Water Pack']
  },
  'treat-dialysis': {
    'Vascular Access Points': ['AV Fistula Connection', 'Central Venous Dialysis Catheter', 'Arteriovenous Dialysis Graft'],
    'Filtration Parameters': ['High Flow Hemofiltration', 'Target Ultrafiltration Rate', 'Low Dialysate Flow rate']
  },
  'treat-rehab-ex': {
    'Resistance Protocols': ['Theraband Progression', 'Progressive Dumbbell Resistance', 'Manual Isometric Resistance'],
    'Functional Gait Training': ['Parallel Bars Balancing', 'Unweighted Gait Trainer', 'Obstacle Mobility Drills']
  },
  'treat-group-ex': {
    'Stabilization Focus': ['Balance Circuit training', 'Postural Stability drills', 'Ankle Proprioception loops'],
    'Cadence & Impact': ['Low Impact Aerobics', 'High Cadence Resistance Circuit', 'Joint-Safe Fluid Cardio']
  }
};

export function TherapySelectionView({
  patients,
  treatments,
  orders,
  onCreateOrder,
  showToast,
}: TherapySelectionViewProps) {
  const [selectedPatient, setSelectedPatient] = useState<Patient | null>(null);
  const [patientSearch, setPatientSearch] = useState('');
  
  // Modal toggle & targeted treatment
  const [activeTreatment, setActiveTreatment] = useState<Treatment | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  // Pop-up form states
  const [selectedCategory, setSelectedCategory] = useState<string>('');
  const [selectedVariation, setSelectedVariation] = useState<string>('Default');
  const [addedVariations, setAddedVariations] = useState<string[]>([]);
  const [customDuration, setCustomDuration] = useState<number>(30);
  const [doctorNotes, setDoctorNotes] = useState<string>('');

  // Draft selection state for the summary view
  const [draftSelections, setDraftSelections] = useState<DraftSelection[]>([]);

  // Handle cascading category change
  const handleCategoryChange = (cat: string) => {
    setSelectedCategory(cat);
    if (activeTreatment) {
      const catMap = VARIATIONS_MAP[activeTreatment.id] || {};
      const variations = catMap[cat] || [];
      if (variations.length > 0) {
        setSelectedVariation(variations[0]);
      } else {
        setSelectedVariation('Default');
      }
    }
  };

  // Add variation tag to local array
  const handleAddVariation = () => {
    if (selectedVariation === 'Default') {
      showToast('Default protocol selected. No custom variations need to be added.', 'info');
      return;
    }
    if (addedVariations.includes(selectedVariation)) {
      showToast('This variation is already added.', 'info');
      return;
    }
    setAddedVariations([...addedVariations, selectedVariation]);
  };

  const handleRemoveVariation = (variation: string) => {
    setAddedVariations(addedVariations.filter((v) => v !== variation));
  };

  // Submit and push to Draft Selections list
  const handleConfirmOrder = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedPatient || !activeTreatment) return;

    // Determine final variation list
    let finalVariations = addedVariations;
    if (finalVariations.length === 0 && selectedVariation !== 'Default') {
      finalVariations = [selectedVariation];
    } else if (finalVariations.length === 0) {
      finalVariations = ['Default Protocol'];
    }

    const variationPart = `Variations: ${finalVariations.join(', ')}`;
    const instructions = doctorNotes.trim() 
      ? `${variationPart}. Dr. Notes: ${doctorNotes.trim()}`
      : variationPart;

    const sessionsCountDefault = 10;

    const newDraft: DraftSelection = {
      id: `draft-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      treatmentId: activeTreatment.id,
      treatmentName: activeTreatment.name,
      customDuration: customDuration,
      instructions: instructions,
      totalSessions: sessionsCountDefault,
    };

    setDraftSelections((prev) => [...prev, newDraft]);
    setIsModalOpen(false);
    setActiveTreatment(null);
    showToast(`Added ${activeTreatment.name} to pending selections. Review and save in the summary on the right!`, 'success');
  };

  const handleSaveAllSelections = () => {
    if (!selectedPatient || draftSelections.length === 0) return;

    const todayStr = new Date().toISOString().split('T')[0];
    const latestStr = new Date(Date.now() + 14 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];
    const priorityDefault: PriorityLevel = 'NORMAL';

    draftSelections.forEach((draft) => {
      onCreateOrder(
        selectedPatient.id,
        draft.treatmentId,
        draft.totalSessions,
        todayStr,
        latestStr,
        priorityDefault,
        draft.instructions,
        draft.customDuration
      );
    });

    showToast(`Successfully saved ${draftSelections.length} selection(s) for ${selectedPatient.displayName}!`, 'success');
    setDraftSelections([]);
  };

  const filteredPatients = patients.filter((p) =>
    p.displayName.toLowerCase().includes(patientSearch.toLowerCase()) ||
    (p.medicalRecordNumber && p.medicalRecordNumber.toLowerCase().includes(patientSearch.toLowerCase()))
  );

  // Filter current active/prescribed selections made for the selected patient
  const patientActiveOrders = selectedPatient
    ? orders.filter((o) => o.patientId === selectedPatient.id)
    : [];

  return (
    <div id="therapy-selection-view" className="w-full max-w-none px-2 py-3 space-y-4">
      {/* Page Header */}
      <div className="border-b border-slate-200 pb-3">
        <div className="flex items-center gap-2 text-zinc-700 text-xs font-bold uppercase tracking-wider mb-1">
          <Layers className="w-4 h-4 text-zinc-500" />
          <span>Clinical Intake Flow</span>
        </div>
        <h2 className="text-xl font-bold text-slate-900">Therapy Selection</h2>
        <p className="text-xs text-slate-500 mt-0.5">
          Select a patient on the left, add therapies with variations in the center, and view a live selection summary on the right.
        </p>
      </div>

      {/* Modern 3-Column Layout: Selector, Catalog, Summary */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-start">
        
        {/* Column 1: Patient Selection */}
        <div className="bg-white border border-slate-200 rounded-xl p-4 flex flex-col h-[calc(100vh-185px)] min-h-[520px] shadow-2xs">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
              <Users className="w-4 h-4 text-zinc-500" />
              <span>1. Patient</span>
            </span>
            <span className="text-[10px] font-semibold text-slate-400">
              {filteredPatients.length} Patients
            </span>
          </div>

          <div className="relative mb-3">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
            <input
              type="text"
              value={patientSearch}
              onChange={(e) => setPatientSearch(e.target.value)}
              placeholder="Search by name or MRN..."
              className="w-full pl-8 pr-3 py-1.5 text-xs bg-slate-50 hover:bg-slate-100/50 border border-slate-200 rounded-lg focus:outline-hidden focus:bg-white focus:border-zinc-400"
            />
          </div>

          <div className="flex-1 overflow-y-auto space-y-1.5 pr-1">
            {filteredPatients.map((p) => {
              const isSelected = selectedPatient?.id === p.id;
              return (
                <button
                  key={p.id}
                  onClick={() => {
                    setSelectedPatient(p);
                    setDraftSelections([]);
                  }}
                  className={`w-full text-left p-2.5 rounded-lg border transition-all flex items-center justify-between ${
                    isSelected
                      ? 'bg-zinc-900 border-zinc-900 text-white shadow-xs'
                      : 'bg-white border-slate-200 hover:border-slate-300 text-slate-700'
                  }`}
                >
                  <div className="min-w-0">
                    <p className={`text-xs font-bold block truncate ${isSelected ? 'text-white' : 'text-slate-900'}`}>
                      {p.displayName}
                    </p>
                    <span className={`text-[10px] font-mono ${isSelected ? 'text-zinc-400' : 'text-slate-400'}`}>
                      {p.medicalRecordNumber || 'No MRN'}
                    </span>
                  </div>
                  <ArrowRight className={`w-3.5 h-3.5 shrink-0 ${isSelected ? 'text-white' : 'text-slate-300'}`} />
                </button>
              );
            })}
          </div>
        </div>

        {/* Column 2: Therapy Catalog */}
        <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 flex flex-col h-[calc(100vh-185px)] min-h-[520px]">
          {selectedPatient ? (
            <div className="flex flex-col h-full">
              <div className="flex items-center justify-between border-b border-slate-200 pb-2.5 mb-3">
                <div>
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                    2. Prescribe Therapy
                  </span>
                  <p className="text-xs font-bold text-slate-800 truncate max-w-[200px]">
                    {selectedPatient.displayName} ({selectedPatient.age}yo)
                  </p>
                </div>
                {selectedPatient.precautions && (
                  <div className="flex items-center gap-1 bg-amber-50 text-amber-800 border border-amber-200 rounded px-2 py-0.5 max-w-[120px] sm:max-w-[160px]">
                    <ShieldAlert className="w-3 h-3 text-amber-600 shrink-0" />
                    <span className="text-[9px] font-medium leading-none truncate">
                      {selectedPatient.precautions}
                    </span>
                  </div>
                )}
              </div>

              <div className="flex-1 overflow-y-auto space-y-2.5 pr-1">
                {treatments.map((t) => {
                  return (
                    <div
                      key={t.id}
                      className="bg-white border border-slate-200 hover:border-zinc-400 p-3 rounded-lg shadow-2xs hover:shadow-xs transition-all flex flex-col justify-between"
                    >
                      <div>
                        <div className="flex items-center justify-between mb-1">
                          <span className="text-[9px] font-bold uppercase tracking-wider text-slate-400">
                            {t.category || 'Therapy'}
                          </span>
                          <span className="text-[9px] font-semibold text-slate-500 flex items-center gap-0.5">
                            <Clock className="w-3 h-3 text-slate-400" />
                            {t.defaultDurationMinutes} mins
                          </span>
                        </div>
                        <h4 className="text-xs font-bold text-slate-900 mb-0.5">{t.name}</h4>
                        <p className="text-[10px] text-slate-500 leading-normal line-clamp-1">
                          {t.description}
                        </p>
                      </div>

                      <button
                        onClick={() => {
                          setActiveTreatment(t);
                          setCustomDuration(t.defaultDurationMinutes || 45);
                          const catMap = VARIATIONS_MAP[t.id] || {};
                          const categories = Object.keys(catMap);
                          if (categories.length > 0) {
                            setSelectedCategory(categories[0]);
                            const variations = catMap[categories[0]] || [];
                            if (variations.length > 0) {
                              setSelectedVariation('Default');
                            } else {
                              setSelectedVariation('Default');
                            }
                          } else {
                            setSelectedCategory('');
                            setSelectedVariation('Default');
                          }
                          setAddedVariations([]);
                          setDoctorNotes('');
                          setIsModalOpen(true);
                        }}
                        className="w-full mt-2 py-1 px-2.5 bg-zinc-900 hover:bg-zinc-800 text-white font-semibold text-[11px] rounded-md flex items-center justify-center gap-1 transition-colors"
                      >
                        <Plus className="w-3 h-3" />
                        <span>Select & Add Variations</span>
                      </button>
                    </div>
                  );
                })}
              </div>
            </div>
          ) : (
            <div className="flex-1 flex flex-col items-center justify-center text-center p-6">
              <Activity className="w-10 h-10 text-slate-300 mb-2" />
              <p className="text-xs font-semibold text-slate-600">Select Patient First</p>
              <p className="text-[10px] text-slate-400 max-w-[180px] mt-1">
                Prescription catalog loads after choosing a patient.
              </p>
            </div>
          )}
        </div>

        {/* Column 3: Selections Summary (Lists prescribed therapies in a beautiful summary column to the right) */}
        <div className="bg-white border border-slate-200 rounded-xl p-4 flex flex-col h-[calc(100vh-185px)] min-h-[520px] shadow-2xs">
          <div className="flex items-center justify-between mb-3 border-b border-slate-100 pb-2">
            <span className="text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
              <ClipboardList className="w-4 h-4 text-zinc-500" />
              <span>3. Selection Summary</span>
            </span>
            <span className="text-[10px] font-bold px-1.5 py-0.5 rounded-full bg-slate-100 text-slate-700">
              {selectedPatient ? (patientActiveOrders.length + draftSelections.length) : 0} Total
            </span>
          </div>

          {selectedPatient ? (
            <div className="flex-1 flex flex-col h-full overflow-hidden">
              <p className="text-[10px] font-medium text-slate-400 mb-2">
                Prescribed course for <strong className="text-slate-700">{selectedPatient.displayName}</strong>:
              </p>
              
              <div className="flex-1 overflow-y-auto space-y-3 pr-1">
                {/* Draft / Pending selections */}
                {draftSelections.length > 0 && (
                  <div className="space-y-1.5">
                    <span className="text-[10px] font-bold text-amber-600 uppercase tracking-wider flex items-center gap-1">
                      <Sparkles className="w-3.5 h-3.5" />
                      <span>Pending Selections ({draftSelections.length})</span>
                    </span>
                    <div className="space-y-1.5">
                      {draftSelections.map((draft) => (
                        <div
                          key={draft.id}
                          className="p-2.5 bg-amber-50/50 border border-amber-200 rounded-lg flex flex-col gap-1 relative"
                        >
                          <div className="flex items-start justify-between">
                            <span className="text-xs font-bold text-amber-950 truncate max-w-[170px]">
                              {draft.treatmentName}
                            </span>
                            <button
                              type="button"
                              onClick={() => setDraftSelections((prev) => prev.filter((d) => d.id !== draft.id))}
                              className="p-0.5 hover:bg-amber-100 text-amber-500 hover:text-amber-800 rounded transition-colors"
                              title="Remove Selection"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                          <div className="text-[10px] text-amber-850 leading-normal font-medium">
                            {draft.instructions}
                          </div>
                          <div className="flex items-center gap-1.5 text-[9px] text-amber-700/80 font-bold mt-0.5">
                            <span className="bg-white px-1 rounded border border-amber-200">
                              {draft.customDuration} mins
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Permanent / Saved selections */}
                {patientActiveOrders.length > 0 ? (
                  <div className="space-y-1.5 mt-2">
                    <span className="text-[10px] font-bold text-emerald-600 uppercase tracking-wider flex items-center gap-1">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>Saved / Active Orders ({patientActiveOrders.length})</span>
                    </span>
                    <div className="space-y-1.5">
                      {patientActiveOrders.map((ord) => {
                        const treatmentName = treatments.find((t) => t.id === ord.treatmentId)?.name || 'Therapy';
                        return (
                          <div
                            key={ord.id}
                            className="p-2.5 bg-slate-50 border border-slate-150 rounded-lg flex flex-col gap-1"
                          >
                            <div className="flex items-start justify-between">
                              <span className="text-xs font-bold text-slate-900 truncate max-w-[180px]">
                                {treatmentName}
                              </span>
                              <span className="text-[9px] font-bold text-emerald-700 bg-emerald-50 px-1 py-0.2 rounded border border-emerald-200 shrink-0 uppercase">
                                Saved
                              </span>
                            </div>
                            <div className="text-[10px] text-slate-600 font-medium">
                              {ord.instructions}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                ) : draftSelections.length === 0 ? (
                  <div className="flex-1 flex flex-col items-center justify-center text-center p-6 bg-slate-50/50 rounded-lg border border-dashed border-slate-200 py-10">
                    <ClipboardList className="w-8 h-8 text-slate-300 mb-1" />
                    <p className="text-[11px] font-semibold text-slate-500">No Selections Yet</p>
                    <p className="text-[10px] text-slate-400 max-w-[160px] mt-1">
                      Select treatments on the left to configure the patient&apos;s plan.
                    </p>
                  </div>
                ) : null}
              </div>

              {/* Save Selections button at the bottom of the column */}
              {draftSelections.length > 0 && (
                <div className="pt-3 border-t border-slate-100 mt-2">
                  <button
                    onClick={handleSaveAllSelections}
                    className="w-full py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-lg flex items-center justify-center gap-1.5 shadow-xs transition-colors"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Save & Submit Selections</span>
                  </button>
                </div>
              )}
            </div>
          ) : (
            <div className="flex-1 flex flex-col items-center justify-center text-center p-6 bg-slate-50/50 rounded-lg border border-dashed border-slate-200">
              <ClipboardList className="w-8 h-8 text-slate-300 mb-1" />
              <p className="text-[11px] font-semibold text-slate-500">Awaiting Selection</p>
              <p className="text-[10px] text-slate-400 max-w-[160px] mt-1">
                Select a patient on the left to review their live summary here.
              </p>
            </div>
          )}
        </div>

      </div>

      {/* Pop-up Modal with Cascading Dropdowns for Variations */}
      {activeTreatment && selectedPatient && (
        <Modal
          isOpen={isModalOpen}
          onClose={() => {
            setIsModalOpen(false);
            setActiveTreatment(null);
          }}
          title={`Configure ${activeTreatment.name}`}
          subtitle={`Patient: ${selectedPatient.displayName}`}
          maxWidthClass="max-w-md"
        >
          <form onSubmit={handleConfirmOrder} className="space-y-4">
            
            {/* Cascading Dropdowns for Variations Selection */}
            <div className="bg-slate-50/70 border border-slate-150 rounded-lg p-3 space-y-3">
              <span className="text-[10px] font-bold text-slate-700 uppercase tracking-wider block">
                Therapy Variations
              </span>
              
              <div className="grid grid-cols-1 gap-2.5">
                {/* Level 1: Category */}
                <div>
                  <label className="block text-[10px] font-semibold text-slate-500 mb-1">
                    Variation Category
                  </label>
                  <select
                    value={selectedCategory}
                    onChange={(e) => handleCategoryChange(e.target.value)}
                    className="w-full text-xs p-2 bg-white border border-slate-200 rounded-md text-slate-700 focus:outline-hidden"
                  >
                    {Object.keys(VARIATIONS_MAP[activeTreatment.id] || {}).map((cat) => (
                      <option key={cat} value={cat}>
                        {cat}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Level 2: Variation (Cascading value including Default) */}
                <div>
                  <label className="block text-[10px] font-semibold text-slate-500 mb-1">
                    Variation Value
                  </label>
                  <select
                    value={selectedVariation}
                    onChange={(e) => setSelectedVariation(e.target.value)}
                    className="w-full text-xs p-2 bg-white border border-slate-200 rounded-md text-slate-700 focus:outline-hidden"
                  >
                    <option value="Default">Default (Use standard protocol)</option>
                    {(VARIATIONS_MAP[activeTreatment.id]?.[selectedCategory] || []).map((v) => (
                      <option key={v} value={v}>
                        {v}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Add Button */}
                <button
                  type="button"
                  onClick={handleAddVariation}
                  disabled={selectedVariation === 'Default'}
                  className={`w-full py-1.5 px-3 font-semibold text-xs rounded-md flex items-center justify-center gap-1.5 transition-colors ${
                    selectedVariation === 'Default'
                      ? 'bg-slate-100 text-slate-400 cursor-not-allowed'
                      : 'bg-slate-200 hover:bg-slate-300 text-slate-800'
                  }`}
                >
                  <Plus className="w-3.5 h-3.5 text-slate-600" />
                  <span>Add Selected Variation</span>
                </button>
              </div>

              {/* Accumulator Tags */}
              <div className="pt-2 border-t border-slate-200">
                <span className="block text-[10px] font-semibold text-slate-500 mb-1.5">
                  Assigned Variations ({addedVariations.length})
                </span>
                {addedVariations.length === 0 ? (
                  <p className="text-[10px] text-slate-400 italic">
                    Using standard Default Protocol (No custom variations needed).
                  </p>
                ) : (
                  <div className="flex flex-wrap gap-1.5">
                    {addedVariations.map((v, idx) => (
                      <span
                        key={idx}
                        className="inline-flex items-center gap-1 text-[10px] font-semibold bg-zinc-900 text-white pl-2 pr-1 py-0.5 rounded-sm"
                      >
                        <span>{v}</span>
                        <button
                          type="button"
                          onClick={() => handleRemoveVariation(v)}
                          className="hover:bg-zinc-800 p-0.5 rounded text-zinc-400 hover:text-white"
                        >
                          <Trash2 className="w-3 h-3" />
                        </button>
                      </span>
                    ))}
                  </div>
                )}
              </div>
            </div>

            {/* Custom Duration only (Removed sessions count and priority input selectors) */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Duration (mins)
              </label>
              <input
                type="number"
                min="5"
                max="240"
                required
                value={customDuration}
                onChange={(e) => setCustomDuration(Number(e.target.value))}
                className="w-full text-xs p-2 bg-white border border-slate-300 rounded-lg focus:ring-1 focus:ring-zinc-500"
              />
            </div>

            {/* Doctor Notes */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Doctor Notes</label>
              <textarea
                rows={3}
                value={doctorNotes}
                onChange={(e) => setDoctorNotes(e.target.value)}
                placeholder="Specific instructions, diagnosis focus, precautions..."
                className="w-full text-xs p-2 bg-white border border-slate-300 rounded-lg focus:ring-1 focus:ring-zinc-500"
              />
            </div>

            {/* Submit Action Block */}
            <div className="flex justify-end gap-2 pt-3 border-t border-slate-200">
              <button
                type="button"
                onClick={() => {
                  setIsModalOpen(false);
                  setActiveTreatment(null);
                }}
                className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-lg transition-colors"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-2 text-xs font-semibold bg-zinc-900 hover:bg-zinc-800 text-white rounded-lg shadow-xs transition-colors"
              >
                Confirm & Add to Review Queue
              </button>
            </div>
          </form>
        </Modal>
      )}
    </div>
  );
}
