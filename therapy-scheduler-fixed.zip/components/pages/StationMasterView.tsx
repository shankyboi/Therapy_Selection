import React, { useState, useEffect } from 'react';
import { Station, StationType, ActivePage, Treatment } from '@/types/therapy';
import { Modal } from '@/components/Modal';
import { 
  BedDouble, 
  Plus, 
  Edit2, 
  CheckCircle2, 
  XCircle, 
  Search, 
  Power, 
  SlidersHorizontal,
  Home,
  Trash2,
  Bookmark,
  Users
} from 'lucide-react';

interface StationMasterViewProps {
  stations: Station[];
  stationTypes: StationType[];
  treatments: Treatment[];
  onSaveStation: (station: Station) => void;
  onToggleActive: (stationId: string, active: boolean) => void;
  onNavigate: (page: ActivePage) => void;
}

const BLOCKS = ['Block A', 'Block B', 'Block C', 'Outpatient Block', 'Inpatient Block', 'Rehab Block'];
const BUILDINGS = ['Main Clinical Building', 'West Wing Annex', 'Neuro-Rehab Center', 'Surgical Tower', 'Wellness Pavilion'];
const FLOORS = ['Ground Floor', '1st Floor', '2nd Floor', '3rd Floor', '4th Floor'];
const ROOM_TYPES = ['General Ward Room', 'Private Therapy Room', 'Multi-Patient Bay', 'ICU Therapy Suite', 'Physiotherapy Hall', 'Dialysis Bay'];
const GENDER_OPTIONS = ['Male', 'Female', 'Others', 'All'];

export function StationMasterView({
  stations,
  stationTypes,
  treatments,
  onSaveStation,
  onToggleActive,
  onNavigate,
}: StationMasterViewProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedDept, setSelectedDept] = useState('ALL');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingStation, setEditingStation] = useState<Station | null>(null);

  // Form states
  const [id, setId] = useState('');
  const [name, setName] = useState('');
  const [stationTypeId, setStationTypeId] = useState(stationTypes[0]?.id || '');
  const [department, setDepartment] = useState('Physiotherapy');
  const [location, setLocation] = useState('West Wing - Bay A');
  const [capacity, setCapacity] = useState(1);
  const [isActive, setIsActive] = useState(true);
  const [notes, setNotes] = useState('');

  // New room attributes states
  const [block, setBlock] = useState('Block A');
  const [building, setBuilding] = useState('Main Clinical Building');
  const [floor, setFloor] = useState('Ground Floor');
  const [roomType, setRoomType] = useState('General Ward Room');
  const [roomSlt, setRoomSlt] = useState('');
  const [genderApplicability, setGenderApplicability] = useState<string[]>(['All']);
  const [overbookingLimit, setOverbookingLimit] = useState<number>(0);

  // Dynamic Therapy Applicability Section states
  const [therapyApplicability, setTherapyApplicability] = useState<Array<{ category: string; treatmentId: string }>>([]);
  const [tempCategory, setTempCategory] = useState('');
  const [tempTreatmentId, setTempTreatmentId] = useState('');

  const departments = Array.from(new Set(stations.map((s) => s.department)));
  const categories = Array.from(new Set(treatments.map((t) => t.category || 'General')));

  // Cascade handler when category changes in temp list
  const handleTempCategoryChange = (cat: string) => {
    setTempCategory(cat);
    const filtered = treatments.filter((t) => (t.category || 'General') === cat);
    if (filtered.length > 0) {
      setTempTreatmentId(filtered[0].id);
    } else {
      setTempTreatmentId('');
    }
  };

  // Prepopulate cascading temp dropdown on load or update
  const initTherapyCascade = () => {
    if (categories.length > 0) {
      const initialCat = categories[0];
      setTempCategory(initialCat);
      const filtered = treatments.filter((t) => (t.category || 'General') === initialCat);
      if (filtered.length > 0) {
        setTempTreatmentId(filtered[0].id);
      } else {
        setTempTreatmentId('');
      }
    } else {
      setTempCategory('');
      setTempTreatmentId('');
    }
  };

  const handleOpenAdd = () => {
    setEditingStation(null);
    setId(`sta-${Date.now().toString(36).substring(4)}`);
    setName('');
    setStationTypeId(stationTypes[0]?.id || '');
    setDepartment('Physiotherapy');
    setLocation('');
    setCapacity(1);
    setIsActive(true);
    setNotes('');

    setBlock('Block A');
    setBuilding('Main Clinical Building');
    setFloor('Ground Floor');
    setRoomType('General Ward Room');
    setRoomSlt('');
    setGenderApplicability(['All']);
    setOverbookingLimit(0);
    setTherapyApplicability([]);
    initTherapyCascade();
    setIsModalOpen(true);
  };

  const handleOpenEdit = (station: Station) => {
    setEditingStation(station);
    setId(station.id);
    setName(station.name);
    setStationTypeId(station.stationTypeId);
    setDepartment(station.department);
    setLocation(station.location);
    setCapacity(station.capacity);
    setIsActive(station.isActive);
    setNotes(station.notes || '');

    // Load custom attributes or defaults
    setBlock(station.block || 'Block A');
    setBuilding(station.building || 'Main Clinical Building');
    setFloor(station.floor || 'Ground Floor');
    setRoomType(station.roomType || 'General Ward Room');
    setRoomSlt(station.roomSlt || '');
    setGenderApplicability(station.genderApplicability || ['All']);
    setOverbookingLimit(station.overbookingLimit || 0);
    setTherapyApplicability(station.therapyApplicability || []);
    initTherapyCascade();
    setIsModalOpen(true);
  };

  const toggleGender = (option: string) => {
    if (option === 'All') {
      setGenderApplicability(['All']);
    } else {
      let next = genderApplicability.filter((g) => g !== 'All');
      if (next.includes(option)) {
        next = next.filter((g) => g !== option);
        if (next.length === 0) next = ['All'];
      } else {
        next.push(option);
      }
      setGenderApplicability(next);
    }
  };

  const handleAddTherapyApplicability = () => {
    if (!tempTreatmentId) return;
    const exists = therapyApplicability.some((rule) => rule.treatmentId === tempTreatmentId);
    if (exists) {
      return;
    }
    setTherapyApplicability([
      ...therapyApplicability,
      { category: tempCategory, treatmentId: tempTreatmentId },
    ]);
  };

  const handleRemoveTherapyApplicability = (treatmentId: string) => {
    setTherapyApplicability(therapyApplicability.filter((rule) => rule.treatmentId !== treatmentId));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    onSaveStation({
      id: editingStation ? editingStation.id : id,
      name,
      stationTypeId,
      department,
      location,
      capacity: Number(capacity),
      isActive,
      notes,
      block,
      building,
      floor,
      roomType,
      roomSlt,
      genderApplicability,
      overbookingLimit: Number(overbookingLimit),
      therapyApplicability,
    });

    setIsModalOpen(false);
  };

  const filteredStations = stations.filter((s) => {
    if (selectedDept !== 'ALL' && s.department !== selectedDept) return false;
    if (
      searchTerm &&
      !s.name.toLowerCase().includes(searchTerm.toLowerCase()) &&
      !s.location.toLowerCase().includes(searchTerm.toLowerCase()) &&
      !s.id.toLowerCase().includes(searchTerm.toLowerCase())
    ) {
      return false;
    }
    return true;
  });

  return (
    <div id="station-master-view" className="max-w-7xl mx-auto px-4 sm:px-6 py-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 pb-4">
        <div>
          <div className="flex items-center gap-2 text-teal-700 text-xs font-bold uppercase tracking-wider mb-1">
            <BedDouble className="w-4 h-4" />
            <span>Room Inventory & Capacity</span>
          </div>
          <h2 className="text-xl font-bold text-slate-900">Room Management</h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Configure clinical rooms with physical locations, gender rules, and specific therapy applicability.
          </p>
        </div>

        <div className="flex items-center gap-2 self-start sm:self-auto">
          <button
            onClick={() => onNavigate('capabilities')}
            className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-xs rounded-lg flex items-center gap-1.5 transition-colors"
          >
            <SlidersHorizontal className="w-3.5 h-3.5 text-teal-600" />
            <span>Configure Capabilities</span>
          </button>
          <button
            id="btn-add-station"
            onClick={handleOpenAdd}
            className="px-3.5 py-1.5 bg-zinc-900 hover:bg-zinc-800 text-white font-semibold text-xs rounded-lg shadow-2xs flex items-center gap-1.5 transition-colors"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add Room</span>
          </button>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-slate-50 p-3 rounded-lg border border-slate-200">
        <div className="flex items-center gap-2.5">
          <div className="relative w-64">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search room or location..."
              className="w-full pl-8 pr-3 py-1.5 text-xs bg-white border border-slate-200 rounded-lg focus:outline-hidden"
            />
          </div>

          <select
            value={selectedDept}
            onChange={(e) => setSelectedDept(e.target.value)}
            className="text-xs py-1.5 px-2.5 bg-white border border-slate-200 rounded-lg text-slate-700 focus:outline-hidden"
          >
            <option value="ALL">All Departments</option>
            {departments.map((d) => (
              <option key={d} value={d}>
                {d}
              </option>
            ))}
          </select>
        </div>

        <span className="text-[11px] font-bold text-slate-500">
          Showing <strong className="text-slate-800">{filteredStations.length}</strong> Rooms
        </span>
      </div>

      {/* Stations Table */}
      <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-2xs">
        <table className="w-full text-left text-xs border-collapse">
          <thead>
            <tr className="border-b border-slate-200 bg-slate-50/70 text-slate-600 font-semibold">
              <th className="py-2.5 px-4">Room ID</th>
              <th className="py-2.5 px-4">Room Name</th>
              <th className="py-2.5 px-4">Building / Block</th>
              <th className="py-2.5 px-4">Floor</th>
              <th className="py-2.5 px-4">Type / SLT</th>
              <th className="py-2.5 px-4 text-center">Gender</th>
              <th className="py-2.5 px-4 text-center">O/B Limit</th>
              <th className="py-2.5 px-4 text-center">Capacity</th>
              <th className="py-2.5 px-4 text-center">Status</th>
              <th className="py-2.5 px-4 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 text-slate-700">
            {filteredStations.map((station) => {
              return (
                <tr key={station.id} className="hover:bg-slate-50/50 transition-colors">
                  <td className="py-2.5 px-4 font-mono text-slate-500 text-[10px]">{station.id}</td>
                  <td className="py-2.5 px-4 font-bold text-slate-900">{station.name}</td>
                  <td className="py-2.5 px-4 text-slate-600">
                    {station.building || 'Main'} - <span className="font-semibold text-slate-700">{station.block || 'A'}</span>
                  </td>
                  <td className="py-2.5 px-4 text-slate-600">{station.floor || 'Ground'}</td>
                  <td className="py-2.5 px-4 text-slate-500">
                    <div className="font-semibold text-slate-700">{station.roomType || 'General'}</div>
                    {station.roomSlt && <div className="text-[9px] font-mono text-slate-400">SLT: {station.roomSlt}</div>}
                  </td>
                  <td className="py-2.5 px-4 text-center">
                    <span className="inline-block text-[9px] font-bold px-1.5 py-0.5 rounded-sm bg-slate-100 text-slate-800 border border-slate-200">
                      {(station.genderApplicability || ['All']).join(', ')}
                    </span>
                  </td>
                  <td className="py-2.5 px-4 text-center font-bold text-slate-800">
                    {station.overbookingLimit || 0}x
                  </td>
                  <td className="py-2.5 px-4 text-center">
                    <span className="inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold bg-purple-50 text-purple-700 border border-purple-200">
                      {station.capacity} Max
                    </span>
                  </td>
                  <td className="py-2.5 px-4 text-center">
                    {station.isActive ? (
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-medium bg-emerald-50 text-emerald-700 border border-emerald-200">
                        <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                        <span>Active</span>
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-medium bg-slate-100 text-slate-500 border border-slate-200">
                        <XCircle className="w-3 h-3 text-slate-400" />
                        <span>Inactive</span>
                      </span>
                    )}
                  </td>
                  <td className="py-2.5 px-4 text-right">
                    <div className="flex items-center justify-end gap-2">
                      <button
                        onClick={() => handleOpenEdit(station)}
                        className="p-1 text-slate-600 hover:text-teal-700 hover:bg-slate-100 rounded transition-colors"
                        title="Edit room"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => onToggleActive(station.id, !station.isActive)}
                        className={`p-1 rounded transition-colors ${
                          station.isActive
                            ? 'text-rose-600 hover:bg-rose-50'
                            : 'text-emerald-600 hover:bg-emerald-50'
                        }`}
                        title={station.isActive ? 'Deactivate room' : 'Activate room'}
                      >
                        <Power className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* Add / Edit Station Modal */}
      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title={editingStation ? 'Edit Clinical Room' : 'Create New Room'}
        subtitle="Manage structural block alignment, floor attributes, room SLT, and assigned therapy services."
        maxWidthClass="max-w-lg"
      >
        <form onSubmit={handleSubmit} className="space-y-4 max-h-[75vh] overflow-y-auto pr-2">
          
          {/* Main Grid: Structural Identifiers */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 bg-slate-50 p-3.5 rounded-xl border border-slate-150">
            <span className="col-span-1 sm:col-span-2 text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1 flex items-center gap-1">
              <Home className="w-3.5 h-3.5" />
              <span>Structural Identifiers</span>
            </span>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Room ID
              </label>
              <input
                type="text"
                disabled={!!editingStation}
                value={id}
                onChange={(e) => setId(e.target.value)}
                className="w-full text-xs p-2 bg-slate-150 border border-slate-300 rounded-lg font-mono focus:outline-hidden"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Room Name <span className="text-rose-500">*</span>
              </label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. Therapy Bed 4"
                className="w-full text-xs p-2 bg-white border border-slate-300 rounded-lg focus:outline-hidden"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Block <span className="text-rose-500">*</span>
              </label>
              <select
                value={block}
                onChange={(e) => setBlock(e.target.value)}
                className="w-full text-xs p-2 bg-white border border-slate-300 rounded-lg text-slate-700"
              >
                {BLOCKS.map((b) => (
                  <option key={b} value={b}>
                    {b}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Building <span className="text-rose-500">*</span>
              </label>
              <select
                value={building}
                onChange={(e) => setBuilding(e.target.value)}
                className="w-full text-xs p-2 bg-white border border-slate-300 rounded-lg text-slate-700"
              >
                {BUILDINGS.map((b) => (
                  <option key={b} value={b}>
                    {b}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Floor <span className="text-rose-500">*</span>
              </label>
              <select
                value={floor}
                onChange={(e) => setFloor(e.target.value)}
                className="w-full text-xs p-2 bg-white border border-slate-300 rounded-lg text-slate-700"
              >
                {FLOORS.map((f) => (
                  <option key={f} value={f}>
                    {f}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                (Therapy) Room Type <span className="text-rose-500">*</span>
              </label>
              <select
                value={roomType}
                onChange={(e) => setRoomType(e.target.value)}
                className="w-full text-xs p-2 bg-white border border-slate-300 rounded-lg text-slate-700"
              >
                {ROOM_TYPES.map((rt) => (
                  <option key={rt} value={rt}>
                    {rt}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                (Therapy) Room (SLT)
              </label>
              <input
                type="text"
                value={roomSlt}
                onChange={(e) => setRoomSlt(e.target.value)}
                placeholder="e.g. SLT-A4"
                className="w-full text-xs p-2 bg-white border border-slate-300 rounded-lg focus:outline-hidden"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Overbooking Limit <span className="text-rose-500">*</span>
              </label>
              <input
                type="number"
                min="0"
                max="50"
                required
                value={overbookingLimit}
                onChange={(e) => setOverbookingLimit(Number(e.target.value))}
                className="w-full text-xs p-2 bg-white border border-slate-300 rounded-lg focus:outline-hidden"
              />
            </div>
          </div>

          {/* Gender Applicability */}
          <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-150">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-2 flex items-center gap-1">
              <Users className="w-3.5 h-3.5" />
              <span>Gender Applicability</span>
            </span>

            <div className="flex flex-wrap gap-2 pt-1.5">
              {GENDER_OPTIONS.map((g) => {
                const isSelected = genderApplicability.includes(g);
                return (
                  <button
                    key={g}
                    type="button"
                    onClick={() => toggleGender(g)}
                    className={`px-3 py-1 text-xs font-bold rounded-md border transition-all ${
                      isSelected
                        ? 'bg-zinc-900 border-zinc-900 text-white'
                        : 'bg-white border-slate-200 text-slate-700 hover:border-slate-300'
                    }`}
                  >
                    {g}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Therapy Applicability Cascading Section */}
          <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-150 space-y-3">
            <span className="text-[10px] font-bold text-slate-700 uppercase tracking-wider flex items-center gap-1 border-b border-slate-200 pb-1">
              <Bookmark className="w-3.5 h-3.5 text-zinc-500" />
              <span>Therapy Applicability</span>
            </span>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-[10px] font-semibold text-slate-500 mb-1">
                  Therapy Category
                </label>
                <select
                  value={tempCategory}
                  onChange={(e) => handleTempCategoryChange(e.target.value)}
                  className="w-full text-xs p-2 bg-white border border-slate-200 rounded-md text-slate-700 focus:outline-hidden"
                >
                  {categories.map((cat) => (
                    <option key={cat} value={cat}>
                      {cat}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-[10px] font-semibold text-slate-500 mb-1">
                  Therapy (Cascading Dropdown)
                </label>
                <select
                  value={tempTreatmentId}
                  onChange={(e) => setTempTreatmentId(e.target.value)}
                  className="w-full text-xs p-2 bg-white border border-slate-200 rounded-md text-slate-700 focus:outline-hidden"
                >
                  {treatments
                    .filter((t) => (t.category || 'General') === tempCategory)
                    .map((t) => (
                      <option key={t.id} value={t.id}>
                        {t.name}
                      </option>
                    ))}
                </select>
              </div>
            </div>

            <button
              type="button"
              onClick={handleAddTherapyApplicability}
              className="w-full py-1.5 bg-slate-200 hover:bg-slate-300 text-slate-800 text-xs font-semibold rounded-md flex items-center justify-center gap-1 transition-colors"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add Therapy Applicability</span>
            </button>

            {/* List of Added Applicabilities */}
            <div className="pt-2 border-t border-slate-200">
              <span className="block text-[10px] font-semibold text-slate-500 mb-1.5">
                Active Therapy Capabilities ({therapyApplicability.length})
              </span>
              {therapyApplicability.length === 0 ? (
                <p className="text-[10px] text-slate-400 italic">No therapies explicitly restricted yet. Room accepts all standard treatments by default.</p>
              ) : (
                <div className="flex flex-wrap gap-1.5">
                  {therapyApplicability.map((rule) => {
                    const treatmentName = treatments.find((t) => t.id === rule.treatmentId)?.name || 'Therapy';
                    return (
                      <span
                        key={rule.treatmentId}
                        className="inline-flex items-center gap-1 text-[10px] font-semibold bg-zinc-900 text-white pl-2 pr-1 py-0.5 rounded-sm"
                      >
                        <span>{treatmentName}</span>
                        <button
                          type="button"
                          onClick={() => handleRemoveTherapyApplicability(rule.treatmentId)}
                          className="hover:bg-zinc-800 p-0.5 rounded text-zinc-400 hover:text-white"
                        >
                          <Trash2 className="w-3 h-3" />
                        </button>
                      </span>
                    );
                  })}
                </div>
              )}
            </div>
          </div>

          {/* Standard fields: Capacity, Department, Notes */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Room Capacity
              </label>
              <input
                type="number"
                min="1"
                max="10"
                required
                value={capacity}
                onChange={(e) => setCapacity(Number(e.target.value))}
                className="w-full text-xs p-2 bg-white border border-slate-300 rounded-lg focus:outline-hidden"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Department
              </label>
              <input
                type="text"
                value={department}
                onChange={(e) => setDepartment(e.target.value)}
                placeholder="Physiotherapy"
                className="w-full text-xs p-2 bg-white border border-slate-300 rounded-lg focus:outline-hidden"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Room Notes / Descriptions</label>
            <textarea
              rows={2}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Physical wing details, special equipment numbers..."
              className="w-full text-xs p-2 bg-white border border-slate-300 rounded-lg focus:outline-hidden"
            />
          </div>

          {/* Submit Block */}
          <div className="flex justify-end gap-2 pt-3 border-t border-slate-200">
            <button
              type="button"
              onClick={() => setIsModalOpen(false)}
              className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-lg transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 text-xs font-semibold bg-zinc-900 hover:bg-zinc-800 text-white rounded-lg shadow-xs transition-colors"
            >
              {editingStation ? 'Update Room' : 'Save Room'}
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
