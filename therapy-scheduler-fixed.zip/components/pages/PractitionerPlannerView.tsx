import React, { useState } from 'react';
import {
  Station,
  StationType,
  Practitioner,
  StationPractitionerRoster,
} from '@/types/therapy';
import { Modal } from '@/components/Modal';
import { getRelativeDateString } from '@/lib/sampleData';
import {
  UserCheck,
  Calendar,
  Copy,
  AlertTriangle,
  CheckCircle2,
  Users,
  BedDouble,
  ArrowLeft,
  ArrowRight,
  ShieldCheck,
  Zap,
  Shuffle,
} from 'lucide-react';

interface PractitionerPlannerViewProps {
  selectedDate: string;
  onDateChange: (date: string) => void;
  stations: Station[];
  stationTypes: StationType[];
  practitioners: Practitioner[];
  rosters: StationPractitionerRoster[];
  onSaveRoster: (roster: StationPractitionerRoster) => void;
  onCopyFromDate: (sourceDate: string, targetDate: string) => void;
}

export function PractitionerPlannerView({
  selectedDate,
  onDateChange,
  stations,
  stationTypes,
  practitioners,
  rosters,
  onSaveRoster,
  onCopyFromDate,
}: PractitionerPlannerViewProps) {
  const [plannerMode, setPlannerMode] = useState<'daily' | 'weekly'>('daily');
  const [batchModalOpen, setBatchModalOpen] = useState(false);
  const [batchStationId, setBatchStationId] = useState('ALL');
  const [batchPrimaryId, setBatchPrimaryId] = useState(practitioners[0]?.id || '');
  const [batchBackupId, setBatchBackupId] = useState('');
  const [batchDaysCount, setBatchDaysCount] = useState(7);

  // Active items
  const activeStations = stations.filter((s) => s.isActive);
  const activePractitioners = practitioners.filter((p) => p.isActive);

  // Get rosters for selected date
  const dateRosters = rosters.filter((r) => r.date === selectedDate);

  // Weekly dates (current date + 6 following days)
  const weekDates: string[] = [];
  const curr = new Date(selectedDate);
  for (let i = 0; i < 7; i++) {
    const d = new Date(curr);
    d.setDate(curr.getDate() + i);
    weekDates.push(d.toISOString().split('T')[0]);
  }

  // Handle single station roster update
  const handleUpdateRoster = (
    stationId: string,
    date: string,
    primaryId?: string,
    backupId?: string
  ) => {
    const existing = rosters.find((r) => r.stationId === stationId && r.date === date);
    const chosenPrimary =
      primaryId !== undefined
        ? primaryId
        : existing?.primaryPractitionerId || practitioners[0]?.id || '';

    const newRoster: StationPractitionerRoster = {
      id: existing ? existing.id : `rst-${stationId}-${date}`,
      stationId,
      date,
      startTime: '08:00',
      endTime: '18:00',
      primaryPractitionerId: chosenPrimary,
      practitionerIds: existing?.practitionerIds && primaryId === undefined ? existing.practitionerIds : (chosenPrimary ? [chosenPrimary] : []),
      backupPractitionerId: backupId !== undefined ? backupId : existing?.backupPractitionerId,
      status: 'CONFIRMED',
    };
    onSaveRoster(newRoster);
  };

  const handleAddPractitioner = (stationId: string, date: string, pId: string) => {
    const existing = rosters.find((r) => r.stationId === stationId && r.date === date);
    const existingIds = existing?.practitionerIds || (existing?.primaryPractitionerId ? [existing.primaryPractitionerId] : []);
    if (!existingIds.includes(pId)) {
      const newIds = [...existingIds, pId];
      const newRoster: StationPractitionerRoster = {
        id: existing ? existing.id : `rst-${stationId}-${date}`,
        stationId,
        date,
        startTime: '08:00',
        endTime: '18:00',
        primaryPractitionerId: newIds[0] || '',
        practitionerIds: newIds,
        backupPractitionerId: existing?.backupPractitionerId,
        status: 'CONFIRMED',
      };
      onSaveRoster(newRoster);
    }
  };

  const handleRemovePractitioner = (stationId: string, date: string, pId: string) => {
    const existing = rosters.find((r) => r.stationId === stationId && r.date === date);
    if (!existing) return;
    const existingIds = existing.practitionerIds || (existing.primaryPractitionerId ? [existing.primaryPractitionerId] : []);
    const newIds = existingIds.filter((id) => id !== pId);
    const newRoster: StationPractitionerRoster = {
      ...existing,
      primaryPractitionerId: newIds[0] || '',
      practitionerIds: newIds,
    };
    onSaveRoster(newRoster);
  };

  // Copy previous day handler
  const handleCopyYesterday = () => {
    const yesterday = new Date(selectedDate);
    yesterday.setDate(yesterday.getDate() - 1);
    const yStr = yesterday.toISOString().split('T')[0];
    onCopyFromDate(yStr, selectedDate);
  };

  // Copy previous week handler
  const handleCopyLastWeek = () => {
    const lastWeek = new Date(selectedDate);
    lastWeek.setDate(lastWeek.getDate() - 7);
    const lwStr = lastWeek.toISOString().split('T')[0];
    onCopyFromDate(lwStr, selectedDate);
  };

  // Randomize primary and backup doctor allotment to all beds
  const handleRandomizeAllotment = () => {
    if (practitioners.length < 2) return;
    stations.forEach((station) => {
      // Pick random distinct primary and backup
      const available = [...practitioners];
      const pIdx = Math.floor(Math.random() * available.length);
      const primaryPrac = available[pIdx];
      available.splice(pIdx, 1); // remove to prevent backup being the same
      
      const bIdx = Math.floor(Math.random() * available.length);
      const backupPrac = available[bIdx];

      const existing = rosters.find((r) => r.stationId === station.id && r.date === selectedDate);
      const newRoster: StationPractitionerRoster = {
        id: existing ? existing.id : `rst-${station.id}-${selectedDate}`,
        stationId: station.id,
        date: selectedDate,
        startTime: '08:00',
        endTime: '18:00',
        primaryPractitionerId: primaryPrac.id,
        practitionerIds: [primaryPrac.id],
        backupPractitionerId: backupPrac.id,
        status: 'CONFIRMED',
      };
      onSaveRoster(newRoster);
    });
  };

  // Batch assign handler
  const handleBatchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const targets = batchStationId === 'ALL' ? activeStations : activeStations.filter((s) => s.id === batchStationId);

    const baseDate = new Date(selectedDate);
    for (let dayOffset = 0; dayOffset < batchDaysCount; dayOffset++) {
      const d = new Date(baseDate);
      d.setDate(baseDate.getDate() + dayOffset);
      const dStr = d.toISOString().split('T')[0];

      for (const st of targets) {
        handleUpdateRoster(st.id, dStr, batchPrimaryId || undefined, batchBackupId || undefined);
      }
    }

    setBatchModalOpen(false);
  };

  return (
    <div id="practitioner-planner-view" className="max-w-7xl mx-auto px-4 sm:px-6 py-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 pb-4">
        <div>
          <div className="flex items-center gap-2 text-teal-700 text-xs font-bold uppercase tracking-wider mb-1">
            <UserCheck className="w-4 h-4" />
            <span>Room Roster & Shift Planning</span>
          </div>
          <h2 className="text-xl font-bold text-slate-900">Practitioner Planner</h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Assign primary responsible practitioners and secondary backup coverages to rooms by date.
          </p>
        </div>

        {/* Date Navigator & View Switcher */}
        <div className="flex flex-wrap items-center gap-2.5">
          <div className="flex items-center bg-slate-100 p-0.5 rounded-lg border border-slate-200 text-xs">
            <button
              onClick={() => setPlannerMode('daily')}
              className={`px-3 py-1.5 rounded-md font-semibold transition-colors ${
                plannerMode === 'daily'
                  ? 'bg-white text-teal-700 shadow-2xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Daily Shift Roster
            </button>
            <button
              onClick={() => setPlannerMode('weekly')}
              className={`px-3 py-1.5 rounded-md font-semibold transition-colors ${
                plannerMode === 'weekly'
                  ? 'bg-white text-teal-700 shadow-2xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              7-Day Room View
            </button>
          </div>

          <div className="flex items-center gap-1.5 bg-white border border-slate-200 px-3 py-1.5 rounded-lg text-xs shadow-2xs">
            <Calendar className="w-3.5 h-3.5 text-slate-400" />
            <input
              type="date"
              value={selectedDate}
              onChange={(e) => onDateChange(e.target.value)}
              className="font-medium text-slate-800 focus:outline-hidden"
            />
          </div>
        </div>
      </div>

      {/* Action Toolbar */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-slate-50 p-3 rounded-xl border border-slate-200 text-xs">
        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={handleCopyYesterday}
            className="px-3 py-1.5 bg-white hover:bg-slate-100 text-slate-700 font-semibold border border-slate-200 rounded-lg flex items-center gap-1.5 shadow-2xs transition-colors"
          >
            <Copy className="w-3.5 h-3.5 text-teal-600" />
            <span>Copy From Yesterday</span>
          </button>

          <button
            onClick={handleCopyLastWeek}
            className="px-3 py-1.5 bg-white hover:bg-slate-100 text-slate-700 font-semibold border border-slate-200 rounded-lg flex items-center gap-1.5 shadow-2xs transition-colors"
          >
            <Copy className="w-3.5 h-3.5 text-teal-600" />
            <span>Copy From Last Week</span>
          </button>

          <button
            id="btn-randomize-roster"
            onClick={handleRandomizeAllotment}
            className="px-3 py-1.5 bg-white hover:bg-slate-100 text-slate-700 font-semibold border border-slate-200 rounded-lg flex items-center gap-1.5 shadow-2xs transition-colors"
            title="Randomly assign primary and backup doctors to all beds"
          >
            <Shuffle className="w-3.5 h-3.5 text-indigo-600 animate-pulse" />
            <span>Randomize Roster</span>
          </button>

          <button
            onClick={() => setBatchModalOpen(true)}
            className="px-3 py-1.5 bg-teal-600 hover:bg-teal-700 text-white font-semibold rounded-lg flex items-center gap-1.5 shadow-xs transition-colors"
          >
            <Zap className="w-3.5 h-3.5" />
            <span>Batch Multi-Day Roster</span>
          </button>
        </div>

        <div className="text-slate-500 flex items-center gap-3">
          <span className="flex items-center gap-1">
            <span className="w-2.5 h-2.5 rounded-full bg-teal-500" /> Primary Assigned
          </span>
          <span className="flex items-center gap-1">
            <span className="w-2.5 h-2.5 rounded-full bg-amber-500" /> Missing Assignment
          </span>
        </div>
      </div>

      {/* Mode 1: Daily Table View */}
      {plannerMode === 'daily' ? (
        <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-2xs">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-slate-200 bg-slate-50/70 text-slate-600 font-semibold">
                <th className="py-3 px-4">Room</th>
                <th className="py-3 px-4">Department & Location</th>
                <th className="py-3 px-4">Shift Period</th>
                <th className="py-3 px-4">Primary Responsible Practitioner</th>
                <th className="py-3 px-4">Backup Coverage Practitioner</th>
                <th className="py-3 px-4 text-center">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              {activeStations.map((station) => {
                const roster = dateRosters.find((r) => r.stationId === station.id);
                const primaryId = roster?.primaryPractitionerId || '';
                const backupId = roster?.backupPractitionerId || '';
                const isUnassigned = !primaryId;
                const isSamePractitioner = primaryId && primaryId === backupId;

                return (
                  <tr key={station.id} className="hover:bg-slate-50/40 transition-colors">
                    <td className="py-3 px-4 font-bold text-slate-900">
                      <div className="flex items-center gap-2">
                        <BedDouble className="w-4 h-4 text-teal-600" />
                        <span>{station.name}</span>
                      </div>
                      <span className="text-[10px] text-slate-400 font-normal block pl-6">
                        Concurrent Cap: {station.capacity}
                      </span>
                    </td>

                    <td className="py-3 px-4 text-slate-600">
                      <div>{station.department}</div>
                      <div className="text-[10px] text-slate-400">{station.location}</div>
                    </td>

                    <td className="py-3 px-4">
                      <span className="bg-slate-100 text-slate-700 font-mono px-2 py-0.5 rounded text-[11px]">
                        08:00 - 18:00 (Full Day)
                      </span>
                    </td>

                    {/* Primary Practitioner Selector */}
                    <td className="py-3 px-4">
                      <div className="space-y-1.5 max-w-xs">
                        {/* Current list of pills */}
                        <div className="flex flex-wrap gap-1">
                          {(roster?.practitionerIds || (primaryId ? [primaryId] : [])).map((pId) => {
                            const p = activePractitioners.find((pr) => pr.id === pId);
                            if (!p) return null;
                            return (
                              <span
                                key={pId}
                                className="inline-flex items-center gap-1 bg-teal-50 border border-teal-200 text-teal-800 rounded-md px-1.5 py-0.5 text-[11px] font-medium"
                              >
                                <span>{p.displayName}</span>
                                <button
                                  type="button"
                                  onClick={() => handleRemovePractitioner(station.id, selectedDate, pId)}
                                  className="text-teal-600 hover:text-teal-900 font-bold cursor-pointer"
                                >
                                  ×
                                </button>
                              </span>
                            );
                          })}
                          {(!roster?.practitionerIds || roster.practitionerIds.length === 0) && !primaryId && (
                            <span className="text-amber-600 text-[11px] font-medium italic">
                              No therapists assigned
                            </span>
                          )}
                        </div>

                        {/* Dropdown to add another therapist */}
                        <select
                          value=""
                          onChange={(e) => {
                            if (e.target.value) {
                              handleAddPractitioner(station.id, selectedDate, e.target.value);
                            }
                          }}
                          className="w-full text-xs p-1 bg-white border border-slate-300 rounded-lg text-slate-700"
                        >
                          <option value="">+ Add Therapist...</option>
                          {activePractitioners
                            .filter((p) => !(roster?.practitionerIds || (primaryId ? [primaryId] : [])).includes(p.id))
                            .map((p) => (
                              <option key={p.id} value={p.id}>
                                {p.displayName} ({p.title || 'Therapist'})
                              </option>
                            ))}
                        </select>
                      </div>
                    </td>

                    {/* Backup Practitioner Selector */}
                    <td className="py-3 px-4">
                      <select
                        value={backupId}
                        onChange={(e) =>
                          handleUpdateRoster(station.id, selectedDate, primaryId || undefined, e.target.value || undefined)
                        }
                        className="w-full max-w-xs text-xs p-1.5 rounded-lg border border-slate-300 bg-white text-slate-900"
                      >
                        <option value="">-- None (Optional) --</option>
                        {activePractitioners.map((p) => (
                          <option key={p.id} value={p.id}>
                            {p.displayName} ({p.title} • {p.department})
                          </option>
                        ))}
                      </select>
                    </td>

                    {/* Validation Status Badge */}
                    <td className="py-3 px-4 text-center">
                      {isUnassigned ? (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-50 text-amber-700 border border-amber-200">
                          <AlertTriangle className="w-3 h-3 text-amber-600" />
                          <span>Unassigned</span>
                        </span>
                      ) : isSamePractitioner ? (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-medium bg-rose-50 text-rose-700 border border-rose-200">
                          <AlertTriangle className="w-3 h-3 text-rose-600" />
                          <span>Redundant</span>
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-medium bg-emerald-50 text-emerald-700 border border-emerald-200">
                          <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                          <span>Rostered</span>
                        </span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      ) : (
        /* Mode 2: Weekly 7-Day Matrix */
        <div className="bg-white rounded-xl border border-slate-200 overflow-x-auto shadow-2xs">
          <table className="w-full text-left text-xs border-collapse min-w-[800px]">
            <thead>
              <tr className="border-b border-slate-200 bg-slate-50/80 text-slate-700 font-semibold">
                <th className="py-3 px-4 sticky left-0 bg-slate-50 z-10 w-44 border-r border-slate-200">
                  Room
                </th>
                {weekDates.map((dateStr) => {
                  const dObj = new Date(dateStr + 'T00:00:00');
                  const dayName = dObj.toLocaleDateString('en-US', { weekday: 'short' });
                  const isCur = dateStr === selectedDate;
                  return (
                    <th
                      key={dateStr}
                      className={`py-3 px-2 text-center min-w-[130px] ${
                        isCur ? 'bg-teal-50/80 text-teal-900 font-bold' : ''
                      }`}
                    >
                      <div>{dayName}</div>
                      <span className="text-[10px] text-slate-500 font-normal font-mono">{dateStr}</span>
                    </th>
                  );
                })}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              {activeStations.map((station) => (
                <tr key={station.id} className="hover:bg-slate-50/40 transition-colors">
                  <td className="py-3 px-4 sticky left-0 bg-white z-10 border-r border-slate-200 font-semibold text-slate-900 shadow-2xs">
                    <div>{station.name}</div>
                    <span className="text-[10px] text-slate-400 font-normal">{station.department}</span>
                  </td>

                  {weekDates.map((dateStr) => {
                    const r = rosters.find((rost) => rost.stationId === station.id && rost.date === dateStr);
                    const assignedIds = r?.practitionerIds || (r?.primaryPractitionerId ? [r.primaryPractitionerId] : []);
                    const assignedPracs = assignedIds
                      .map((id) => practitioners.find((p) => p.id === id))
                      .filter(Boolean) as Practitioner[];
                    const backupPrac = practitioners.find((p) => p.id === r?.backupPractitionerId);

                    return (
                      <td key={dateStr} className="py-2.5 px-2 text-center border-l border-slate-100">
                        {assignedPracs.length > 0 ? (
                          <div className="p-1.5 rounded-lg bg-teal-50/80 border border-teal-200 text-left space-y-1">
                            <div className="flex flex-col gap-0.5">
                              {assignedPracs.map((p) => (
                                <div key={p.id} className="font-bold text-[10px] text-teal-900 truncate">
                                  {p.displayName}
                                </div>
                              ))}
                            </div>
                            {backupPrac && (
                              <div className="text-[9px] text-slate-500 truncate pt-0.5 border-t border-dotted border-slate-200">
                                Cover: {backupPrac.displayName}
                              </div>
                            )}
                          </div>
                        ) : (
                          <button
                            onClick={() => {
                              onDateChange(dateStr);
                              setPlannerMode('daily');
                            }}
                            className="w-full py-2 px-1 text-[10px] text-amber-700 bg-amber-50 hover:bg-amber-100 border border-amber-200 rounded font-medium"
                          >
                            + Assign
                          </button>
                        )}
                      </td>
                    );
                  })}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Batch Assign Multi-Day Roster Modal */}
      <Modal
        isOpen={batchModalOpen}
        onClose={() => setBatchModalOpen(false)}
        title="Batch Assign Shifts Across Dates"
        subtitle="Apply recurring primary and backup practitioners to rooms"
        maxWidthClass="max-w-md"
      >
        <form onSubmit={handleBatchSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Target Room(s):</label>
            <select
              value={batchStationId}
              onChange={(e) => setBatchStationId(e.target.value)}
              className="w-full text-xs p-2 bg-white border border-slate-300 rounded-lg"
            >
              <option value="ALL">All Active Rooms ({activeStations.length})</option>
              {activeStations.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name} ({s.department})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Primary Responsible Practitioner:
            </label>
            <select
              value={batchPrimaryId}
              onChange={(e) => setBatchPrimaryId(e.target.value)}
              className="w-full text-xs p-2 bg-white border border-slate-300 rounded-lg font-medium"
            >
              {activePractitioners.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.displayName} ({p.title} • {p.department})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Backup Coverage Practitioner (Optional):
            </label>
            <select
              value={batchBackupId}
              onChange={(e) => setBatchBackupId(e.target.value)}
              className="w-full text-xs p-2 bg-white border border-slate-300 rounded-lg"
            >
              <option value="">-- No Backup Assigned --</option>
              {activePractitioners.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.displayName} ({p.title})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Days to apply starting from {selectedDate}:
            </label>
            <select
              value={batchDaysCount}
              onChange={(e) => setBatchDaysCount(Number(e.target.value))}
              className="w-full text-xs p-2 bg-white border border-slate-300 rounded-lg"
            >
              <option value={1}>1 Day (Current Date Only)</option>
              <option value={5}>5 Days (Monday - Friday Workweek)</option>
              <option value={7}>7 Days (Full Week)</option>
              <option value={14}>14 Days (Two Weeks)</option>
              <option value={30}>30 Days (Full Month)</option>
            </select>
          </div>

          <div className="flex justify-end gap-2 pt-3 border-t border-slate-200">
            <button
              type="button"
              onClick={() => setBatchModalOpen(false)}
              className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-lg transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 text-xs font-semibold bg-teal-600 hover:bg-teal-700 text-white rounded-lg shadow-xs transition-colors"
            >
              Apply Batch Shift Roster
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
