import React, { useState } from 'react';
import { StationType } from '@/types/therapy';
import { Modal } from '@/components/Modal';
import { Layers, Plus, Edit2, CheckCircle2, XCircle, Search, Power } from 'lucide-react';

interface StationTypeMasterViewProps {
  stationTypes: StationType[];
  onSaveStationType: (type: StationType) => void;
  onToggleActive: (typeId: string, active: boolean) => void;
}

export function StationTypeMasterView({
  stationTypes,
  onSaveStationType,
  onToggleActive,
}: StationTypeMasterViewProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingType, setEditingType] = useState<StationType | null>(null);

  // Form states
  const [name, setName] = useState('');
  const [id, setId] = useState('');
  const [description, setDescription] = useState('');
  const [defaultCapacity, setDefaultCapacity] = useState(1);
  const [isActive, setIsActive] = useState(true);

  const handleOpenAdd = () => {
    setEditingType(null);
    setId(`st-${Date.now().toString(36).substring(4)}`);
    setName('');
    setDescription('');
    setDefaultCapacity(1);
    setIsActive(true);
    setIsModalOpen(true);
  };

  const handleOpenEdit = (type: StationType) => {
    setEditingType(type);
    setId(type.id);
    setName(type.name);
    setDescription(type.description);
    setDefaultCapacity(type.defaultCapacity);
    setIsActive(type.isActive);
    setIsModalOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    onSaveStationType({
      id: editingType ? editingType.id : id,
      name,
      description,
      defaultCapacity: Number(defaultCapacity),
      isActive,
    });

    setIsModalOpen(false);
  };

  const filteredTypes = stationTypes.filter(
    (t) =>
      t.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      t.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      t.id.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div id="station-type-master-view" className="max-w-6xl mx-auto px-4 sm:px-6 py-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 pb-4">
        <div>
          <div className="flex items-center gap-2 text-teal-700 text-xs font-bold uppercase tracking-wider mb-1">
            <Layers className="w-4 h-4" />
            <span>Master Catalog Configuration</span>
          </div>
          <h2 className="text-xl font-bold text-slate-900">Room Type</h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Configure primary room categories (Therapy Beds, Treatment Rooms, Rehabilitation Tables, Group Areas).
          </p>
        </div>

        <button
          id="btn-add-station-type"
          onClick={handleOpenAdd}
          className="px-4 py-2 bg-teal-600 hover:bg-teal-700 text-white font-semibold text-xs rounded-xl shadow-xs flex items-center gap-1.5 transition-colors self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>Add Room Type</span>
        </button>
      </div>

      {/* Search & Counter */}
      <div className="flex items-center justify-between gap-4">
        <div className="relative max-w-xs w-full">
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-3" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search room types..."
            className="w-full pl-8 pr-3 py-2 text-xs bg-white border border-slate-200 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-teal-500"
          />
        </div>
        <span className="text-xs text-slate-500">
          Total: <strong className="text-slate-800">{filteredTypes.length}</strong> types
        </span>
      </div>

      {/* Room Types Table */}
      <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-2xs">
        <table className="w-full text-left text-xs border-collapse">
          <thead>
            <tr className="border-b border-slate-200 bg-slate-50/70 text-slate-600 font-semibold">
              <th className="py-3 px-4">Type ID</th>
              <th className="py-3 px-4">Room Type Name</th>
              <th className="py-3 px-4">Description</th>
              <th className="py-3 px-4 text-center">Default Capacity</th>
              <th className="py-3 px-4 text-center">Status</th>
              <th className="py-3 px-4 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 text-slate-700">
            {filteredTypes.map((type) => (
              <tr key={type.id} className="hover:bg-slate-50/50 transition-colors">
                <td className="py-3 px-4 font-mono text-slate-500">{type.id}</td>
                <td className="py-3 px-4 font-bold text-slate-900">{type.name}</td>
                <td className="py-3 px-4 text-slate-600 max-w-md">{type.description}</td>
                <td className="py-3 px-4 text-center">
                  <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-semibold bg-purple-50 text-purple-700 border border-purple-200">
                    {type.defaultCapacity} Patient{type.defaultCapacity > 1 ? 's' : ''}
                  </span>
                </td>
                <td className="py-3 px-4 text-center">
                  {type.isActive ? (
                    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-medium bg-emerald-50 text-emerald-700 border border-emerald-200">
                      <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                      <span>Active</span>
                    </span>
                  ) : (
                    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-medium bg-slate-100 text-slate-500 border border-slate-200">
                      <XCircle className="w-3 h-3 text-slate-400" />
                      <span>Inactive</span>
                    </span>
                  )}
                </td>
                <td className="py-3 px-4 text-right">
                  <div className="flex items-center justify-end gap-2">
                    <button
                      onClick={() => handleOpenEdit(type)}
                      className="p-1.5 text-slate-600 hover:text-teal-700 hover:bg-slate-100 rounded transition-colors"
                      title="Edit room type"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => onToggleActive(type.id, !type.isActive)}
                      className={`p-1.5 rounded transition-colors ${
                        type.isActive
                          ? 'text-rose-600 hover:bg-rose-50'
                          : 'text-emerald-600 hover:bg-emerald-50'
                      }`}
                      title={type.isActive ? 'Deactivate type' : 'Activate type'}
                    >
                      <Power className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Add/Edit Modal */}
      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title={editingType ? 'Edit Room Type' : 'Create New Room Type'}
        subtitle="Define category characteristics and default concurrent capacity"
        maxWidthClass="max-w-md"
      >
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Room Type ID <span className="text-slate-400 font-normal">(Auto-generated or custom)</span>
            </label>
            <input
              type="text"
              required
              disabled={!!editingType}
              value={id}
              onChange={(e) => setId(e.target.value)}
              className="w-full text-xs p-2 bg-slate-50 border border-slate-300 rounded-lg font-mono focus:ring-2 focus:ring-teal-500"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Room Type Name <span className="text-rose-500">*</span>
            </label>
            <input
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Therapy Bed, Treatment Room"
              className="w-full text-xs p-2 bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-teal-500"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Description
            </label>
            <textarea
              rows={3}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Describe clinical equipment and physical layout characteristics..."
              className="w-full text-xs p-2 bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-teal-500"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Default Concurrent Capacity
              </label>
              <input
                type="number"
                min="1"
                max="10"
                required
                value={defaultCapacity}
                onChange={(e) => setDefaultCapacity(Number(e.target.value))}
                className="w-full text-xs p-2 bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-teal-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Active Status</label>
              <select
                value={isActive ? 'ACTIVE' : 'INACTIVE'}
                onChange={(e) => setIsActive(e.target.value === 'ACTIVE')}
                className="w-full text-xs p-2 bg-white border border-slate-300 rounded-lg"
              >
                <option value="ACTIVE">Active</option>
                <option value="INACTIVE">Inactive</option>
              </select>
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-3 border-t border-slate-200">
            <button
              type="button"
              onClick={() => setIsModalOpen(false)}
              className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-lg transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 text-xs font-semibold bg-teal-600 hover:bg-teal-700 text-white rounded-lg shadow-xs transition-colors"
            >
              {editingType ? 'Update Room Type' : 'Save Room Type'}
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
