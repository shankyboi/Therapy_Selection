import type { NextConfig } from 'next';

const nextConfig: NextConfig = {
  reactStrictMode: true,
  // Keep both TypeScript and ESLint build checks enabled.
  output: 'standalone',
  images: {
    remotePatterns: [
      { protocol: 'https', hostname: 'picsum.photos', pathname: '/**' },
    ],
  },
  webpack: (config, { dev }) => {
    // Optional compatibility with the AI Studio editing environment.
    if (dev && process.env.DISABLE_HMR === 'true') {
      config.watchOptions = { ...config.watchOptions, ignored: /.*/ };
    }
    return config;
  },
};

export default nextConfig;
