import {
  Station,
  StationType,
  Treatment,
  StationTreatmentCapability,
  Practitioner,
  StationPractitionerRoster,
  Patient,
  TreatmentOrder,
  TreatmentOccurrence,
  TreatmentAllocation,
  ValidationResult,
  ValidationIssue,
} from '@/types/therapy';

export function timeToMinutes(timeStr: string): number {
  if (!timeStr) return 0;
  const [h, m] = timeStr.split(':').map(Number);
  return (h || 0) * 60 + (m || 0);
}

export function minutesToTime(totalMinutes: number): string {
  const normalized = Math.max(0, Math.min(24 * 60 - 1, totalMinutes));
  const h = Math.floor(normalized / 60);
  const m = normalized % 60;
  return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
}

export function calculateEndTime(startTime: string, durationMinutes: number): string {
  const startMins = timeToMinutes(startTime);
  const endMins = startMins + durationMinutes;
  return minutesToTime(endMins);
}

export function doIntervalsOverlap(
  startA: string,
  endA: string,
  startB: string,
  endB: string
): boolean {
  const a1 = timeToMinutes(startA);
  const a2 = timeToMinutes(endA);
  const b1 = timeToMinutes(startB);
  const b2 = timeToMinutes(endB);
  return Math.max(a1, b1) < Math.min(a2, b2);
}

export interface ValidationContext {
  stations: Station[];
  stationTypes?: StationType[];
  treatments: Treatment[];
  capabilities: StationTreatmentCapability[];
  rosters: StationPractitionerRoster[];
  practitioners: Practitioner[];
  patients: Patient[];
  orders: TreatmentOrder[];
  occurrences: TreatmentOccurrence[];
  allocations: TreatmentAllocation[];
}

export interface CandidateAllocation {
  id?: string; // If editing existing allocation, exclude self from conflict checks
  treatmentOccurrenceId: string;
  stationId: string;
  date: string;
  plannedStart: string;
  plannedEnd: string;
  plannedPractitionerId?: string;
}

export function validateAllocation(
  candidate: CandidateAllocation,
  ctx: ValidationContext
): ValidationResult {
  const errors: ValidationIssue[] = [];
  const warnings: ValidationIssue[] = [];
  const infos: ValidationIssue[] = [];

  // 1. Resolve occurrence and order
  const occurrence = ctx.occurrences.find((o) => o.id === candidate.treatmentOccurrenceId);
  if (!occurrence) {
    errors.push({
      type: 'ERROR',
      code: 'OCCURRENCE_NOT_FOUND',
      message: 'Treatment occurrence not found.',
    });
    return {
      isValid: false,
      hasWarnings: warnings.length > 0,
      errors,
      warnings,
      infos,
    };
  }

  const order = ctx.orders.find((o) => o.id === occurrence.treatmentOrderId);
  if (!order) {
    errors.push({
      type: 'ERROR',
      code: 'ORDER_NOT_FOUND',
      message: 'Associated treatment order not found.',
    });
    return {
      isValid: false,
      hasWarnings: warnings.length > 0,
      errors,
      warnings,
      infos,
    };
  }

  // 12. Cancelled or inactive treatment orders cannot be allocated
  if (order.status === 'CANCELLED') {
    errors.push({
      type: 'ERROR',
      code: 'ORDER_CANCELLED',
      message: 'This treatment order has been cancelled and cannot be scheduled.',
    });
  }

  const patient = ctx.patients.find((p) => p.id === order.patientId);
  const treatment = ctx.treatments.find((t) => t.id === order.treatmentId);

  if (!treatment || !treatment.isActive) {
    errors.push({
      type: 'ERROR',
      code: 'TREATMENT_INACTIVE',
      message: `Treatment "${treatment?.name || 'Unknown'}" is inactive or disabled.`,
    });
  }

  // 2. Station must be active
  const station = ctx.stations.find((s) => s.id === candidate.stationId);
  if (!station) {
    errors.push({
      type: 'ERROR',
      code: 'STATION_NOT_FOUND',
      message: 'Selected station does not exist.',
    });
    return {
      isValid: false,
      hasWarnings: warnings.length > 0,
      errors,
      warnings,
      infos,
    };
  }

  if (!station.isActive) {
    errors.push({
      type: 'ERROR',
      code: 'STATION_INACTIVE',
      message: `Station "${station.name}" is currently marked inactive.`,
    });
  }

  // 1. Treatment must be supported by the station
  const capability = ctx.capabilities.find(
    (c) => c.stationId === candidate.stationId && c.treatmentId === order.treatmentId && c.isActive
  );

  if (!capability || !capability.isAllowed) {
    errors.push({
      type: 'ERROR',
      code: 'TREATMENT_NOT_SUPPORTED',
      message: `Station "${station.name}" does not support "${treatment?.name}".`,
      details: 'Check Station Treatment Capabilities to configure allowed modalities.',
    });
  }

  // 8. Duration validation
  const startMins = timeToMinutes(candidate.plannedStart);
  const endMins = timeToMinutes(candidate.plannedEnd);
  const duration = endMins - startMins;

  if (duration <= 0) {
    errors.push({
      type: 'ERROR',
      code: 'INVALID_DURATION',
      message: 'End time must be strictly after start time.',
    });
  } else if (duration < 15) {
    errors.push({
      type: 'ERROR',
      code: 'DURATION_TOO_SHORT',
      message: 'Minimum slot duration is 15 minutes.',
    });
  }

  // 3. Station operating hours
  const openTime = '08:00';
  const closeTime = '18:00';
  if (startMins < timeToMinutes(openTime) || endMins > timeToMinutes(closeTime)) {
    warnings.push({
      type: 'WARNING',
      code: 'OUTSIDE_OPERATING_HOURS',
      message: `Allocation extends outside standard operating hours (${openTime} - ${closeTime}).`,
      details: 'Requires clinical supervisor authorization.',
    });
  }

  // 7. Allocation must fall within the permitted treatment date range
  if (order.earliestAllowedDate && candidate.date < order.earliestAllowedDate) {
    errors.push({
      type: 'ERROR',
      code: 'DATE_TOO_EARLY',
      message: `Requested date (${candidate.date}) is before the earliest allowed date (${order.earliestAllowedDate}) for this order.`,
    });
  }

  if (order.latestAllowedDate && candidate.date > order.latestAllowedDate) {
    warnings.push({
      type: 'WARNING',
      code: 'DATE_EXCEEDS_ORDER_WINDOW',
      message: `Requested date (${candidate.date}) is past the order validity end date (${order.latestAllowedDate}).`,
      details: 'Can be scheduled with physician override reason.',
    });
  }

  // Filter existing active allocations on the same date (excluding self)
  const activeDateAllocations = ctx.allocations.filter(
    (a) =>
      a.date === candidate.date &&
      a.status !== 'CANCELLED' &&
      a.id !== candidate.id
  );

  // 4. Station concurrent capacity validation
  const maxStationCapacity = station.overbookingLimit && station.overbookingLimit > 0
    ? station.overbookingLimit
    : (capability ? Math.min(station.capacity, capability.stationCapacity) : station.capacity);
  
  // Find station overlapping allocations including the 10-minute preparation time
  const stationOverlaps = activeDateAllocations.filter(
    (a) => {
      if (a.stationId !== candidate.stationId) return false;
      const aStart = timeToMinutes(a.plannedStart);
      const aEndWithPrep = timeToMinutes(a.plannedEnd) + 10;
      const candStart = startMins;
      const candEndWithPrep = endMins + 10;
      return Math.max(aStart, candStart) < Math.min(aEndWithPrep, candEndWithPrep);
    }
  );

  // Check capacity at discrete 15-minute slice points across candidate duration including preparation time
  for (let m = startMins; m < endMins + 10; m += 15) {
    const pointTime = minutesToTime(m);
    const concurrentAtPoint = stationOverlaps.filter((a) => {
      const aStart = timeToMinutes(a.plannedStart);
      const aEndWithPrep = timeToMinutes(a.plannedEnd) + 10;
      return m >= aStart && m < aEndWithPrep;
    });

    if (concurrentAtPoint.length + 1 > maxStationCapacity) {
      errors.push({
        type: 'ERROR',
        code: 'STATION_CAPACITY_EXCEEDED',
        message: `Station "${station.name}" capacity limit (${maxStationCapacity}) exceeded at ${pointTime} during treatment or its preparation.`,
        details: `Currently ${concurrentAtPoint.length} active allocation(s) scheduled in this time window.`,
      });
      break;
    }
  }

  // 5. Primary practitioner assigned to station in roster
  const stationRoster = ctx.rosters.find(
    (r) =>
      r.stationId === candidate.stationId &&
      r.date === candidate.date &&
      doIntervalsOverlap(candidate.plannedStart, candidate.plannedEnd, r.startTime, r.endTime)
  );

  let effectivePractitionerId = candidate.plannedPractitionerId;

  if (!stationRoster || !stationRoster.primaryPractitionerId) {
    warnings.push({
      type: 'WARNING',
      code: 'NO_PRACTITIONER_ASSIGNED',
      message: `Station "${station.name}" has no primary practitioner rostered for ${candidate.date} at ${candidate.plannedStart}.`,
      details: 'You can still allocate if an ad-hoc practitioner or supervisor override is provided.',
    });
  } else {
    if (!effectivePractitionerId) {
      effectivePractitionerId = stationRoster.primaryPractitionerId;
    }
    const rosterPrac = ctx.practitioners.find((p) => p.id === stationRoster.primaryPractitionerId);
    infos.push({
      type: 'INFO',
      code: 'ROSTER_MATCH',
      message: `Rostered Primary: ${rosterPrac?.displayName || 'Unknown'}${stationRoster.backupPractitionerId ? ` (Backup: ${ctx.practitioners.find(p => p.id === stationRoster.backupPractitionerId)?.displayName || 'None'})` : ''}`,
    });
  }

  // 6. Patient must not have another overlapping allocation
  const patientOverlaps = activeDateAllocations.filter((a) => {
    const occ = ctx.occurrences.find((o) => o.id === a.treatmentOccurrenceId);
    const ord = occ ? ctx.orders.find((ord) => ord.id === occ.treatmentOrderId) : null;
    return (
      ord?.patientId === order.patientId &&
      doIntervalsOverlap(candidate.plannedStart, candidate.plannedEnd, a.plannedStart, a.plannedEnd)
    );
  });

  if (patientOverlaps.length > 0) {
    const conflictAlloc = patientOverlaps[0];
    const conflictStation = ctx.stations.find((s) => s.id === conflictAlloc.stationId);
    errors.push({
      type: 'ERROR',
      code: 'PATIENT_DOUBLE_BOOKING',
      message: `Patient ${patient?.displayName || 'Unknown'} already has an active session from ${conflictAlloc.plannedStart} to ${conflictAlloc.plannedEnd} at ${conflictStation?.name || 'another station'}.`,
    });
  }

  // 9, 10, 11. Practitioner Workload & Concurrency validations
  if (effectivePractitionerId) {
    const prac = ctx.practitioners.find((p) => p.id === effectivePractitionerId);
    const attentionMode = capability?.attentionMode || 'EXCLUSIVE';

    // Find all allocations that this practitioner is responsible for during this date & overlapping time
    const practitionerOverlaps = activeDateAllocations.filter((a) => {
      const isPlanned = a.plannedPractitionerId === effectivePractitionerId;
      const isActual = a.actualPractitionerId === effectivePractitionerId;
      // If unassigned on allocation, check if station roster had this practitioner
      let isRostered = false;
      if (!a.plannedPractitionerId) {
        const rost = ctx.rosters.find(
          (r) =>
            r.stationId === a.stationId &&
            r.date === a.date &&
            r.primaryPractitionerId === effectivePractitionerId
        );
        if (rost) isRostered = true;
      }

      return (
        (isPlanned || isActual || isRostered) &&
        doIntervalsOverlap(candidate.plannedStart, candidate.plannedEnd, a.plannedStart, a.plannedEnd)
      );
    });

    // Check if new treatment is EXCLUSIVE
    if (attentionMode === 'EXCLUSIVE') {
      if (practitionerOverlaps.length > 0) {
        const firstConflict = practitionerOverlaps[0];
        const conflictSt = ctx.stations.find((s) => s.id === firstConflict.stationId);
        errors.push({
          type: 'ERROR',
          code: 'PRACTITIONER_EXCLUSIVE_CONFLICT',
          message: `${prac?.displayName || 'Practitioner'} cannot take an EXCLUSIVE treatment because they already have ${practitionerOverlaps.length} session(s) scheduled (e.g. at ${conflictSt?.name} ${firstConflict.plannedStart}-${firstConflict.plannedEnd}).`,
          details: 'EXCLUSIVE treatments require 100% 1-on-1 practitioner attention.',
        });
      }
    } else {
      // Candidate is SHARED or UNATTENDED. Check if any existing overlap is EXCLUSIVE.
      for (const exAlloc of practitionerOverlaps) {
        const exOcc = ctx.occurrences.find((o) => o.id === exAlloc.treatmentOccurrenceId);
        const exOrd = exOcc ? ctx.orders.find((ord) => ord.id === exOcc.treatmentOrderId) : null;
        const exCap = exOrd
          ? ctx.capabilities.find(
              (c) => c.stationId === exAlloc.stationId && c.treatmentId === exOrd.treatmentId
            )
          : null;

        if (exCap?.attentionMode === 'EXCLUSIVE') {
          const exSt = ctx.stations.find((s) => s.id === exAlloc.stationId);
          errors.push({
            type: 'ERROR',
            code: 'OVERLAPPING_EXISTING_EXCLUSIVE',
            message: `${prac?.displayName || 'Practitioner'} is currently committed to an EXCLUSIVE 1-on-1 session at ${exSt?.name} (${exAlloc.plannedStart} - ${exAlloc.plannedEnd}).`,
          });
          break;
        }
      }

      // Check SHARED concurrency limits
      if (attentionMode === 'SHARED') {
        const maxParallel = capability?.maximumParallelPatients || 3;
        // Total simultaneous sessions for this practitioner
        if (practitionerOverlaps.length + 1 > maxParallel) {
          warnings.push({
            type: 'WARNING',
            code: 'SHARED_CONCURRENCY_EXCEEDED',
            message: `${prac?.displayName || 'Practitioner'} will have ${practitionerOverlaps.length + 1} simultaneous patients (limit for this capability is ${maxParallel}).`,
            details: 'Overload warning. Allowed only with clinical supervisor override.',
          });
        }
      }
    }
  }

  const isValid = errors.length === 0;
  const hasWarnings = warnings.length > 0;

  return {
    isValid,
    hasWarnings,
    errors,
    warnings,
    infos,
  };
}
