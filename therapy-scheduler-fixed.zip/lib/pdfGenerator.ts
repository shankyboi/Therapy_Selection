import { jsPDF } from 'jspdf';
import {
  Station,
  StationType,
  StationPractitionerRoster,
  Practitioner,
  TreatmentAllocation,
  Patient,
  Treatment,
  TreatmentOrder,
  TreatmentOccurrence,
} from '@/types/therapy';

interface PDFGeneratorParams {
  selectedDate: string;
  stations: Station[];
  stationTypes: StationType[];
  rosters: StationPractitionerRoster[];
  practitioners: Practitioner[];
  allocations: TreatmentAllocation[];
  patients: Patient[];
  treatments: Treatment[];
  orders: TreatmentOrder[];
  occurrences: TreatmentOccurrence[];
}

function parseTimeToMinutes(timeStr: string): number {
  if (!timeStr) return 0;
  const parts = timeStr.split(':');
  const h = parseInt(parts[0] || '0', 10);
  const m = parseInt(parts[1] || '0', 10);
  return h * 60 + m;
}

export function generateSchedulerPDF({
  selectedDate,
  stations,
  stationTypes,
  rosters,
  practitioners,
  allocations,
  patients,
  treatments,
  orders,
  occurrences,
}: PDFGeneratorParams): void {
  // Create jsPDF landscape A4 document
  const doc = new jsPDF({
    orientation: 'landscape',
    unit: 'mm',
    format: 'a4',
  });

  const pageWidth = 297;
  const pageHeight = 210;
  const marginLeft = 10;
  const marginTop = 25;
  const gridStartY = 38;
  const gridEndY = 195;
  const gridHeight = gridEndY - gridStartY; // 157mm
  const totalMinutes = 10 * 60; // 08:00 to 18:00 = 600 mins
  const scale = gridHeight / totalMinutes; // mm per minute

  const timeColWidth = 16;
  const roomsWidth = 261;
  const maxRoomsPerPage = 4;

  let isFirstPage = true;

  // Filter active stations
  const activeStations = stations.filter((s) => s.isActive);

  // Group stations by Room Type
  for (const stationType of stationTypes) {
    const typeStations = activeStations.filter((s) => s.stationTypeId === stationType.id);
    if (typeStations.length === 0) continue;

    // Split stations into pages of max 4 columns
    const totalPagesForType = Math.ceil(typeStations.length / maxRoomsPerPage);

    for (let pageIdx = 0; pageIdx < totalPagesForType; pageIdx++) {
      const pageStations = typeStations.slice(
        pageIdx * maxRoomsPerPage,
        (pageIdx + 1) * maxRoomsPerPage
      );

      if (!isFirstPage) {
        doc.addPage();
      }
      isFirstPage = false;

      // Draw Header Banner
      doc.setFillColor(248, 250, 252); // Light background top bar
      doc.rect(marginLeft, 8, pageWidth - 20, 14, 'F');
      
      doc.setFont('Helvetica', 'bold');
      doc.setFontSize(12);
      doc.setTextColor(15, 23, 42); // slate-900
      doc.text(
        `Clinical Schedule: ${stationType.name}`,
        marginLeft + 4,
        14
      );

      doc.setFont('Helvetica', 'normal');
      doc.setFontSize(8.5);
      doc.setTextColor(100, 116, 139); // slate-500
      doc.text(
        `Date: ${selectedDate}  |  Sheet: Page ${pageIdx + 1} of ${totalPagesForType}`,
        marginLeft + 4,
        19
      );

      // Compact Legend
      doc.setFontSize(8);
      doc.text(
        "Priority Code: Urgent (Rose)  High (Amber)  Normal (Teal)  Low (Grey)",
        pageWidth - 110,
        16
      );

      // Draw Time Grid Y-axis Hour Indicators and horizontal lines
      doc.setDrawColor(226, 232, 240); // slate-200
      doc.setLineWidth(0.1);

      for (let h = 8; h <= 18; h++) {
        const mins = (h - 8) * 60;
        const lineY = gridStartY + mins * scale;

        // Draw horizontal grid line
        doc.line(marginLeft, lineY, marginLeft + timeColWidth + roomsWidth, lineY);

        // Time text
        doc.setFont('Helvetica', 'bold');
        doc.setFontSize(7.5);
        doc.setTextColor(71, 85, 105); // slate-600
        doc.text(
          `${String(h).padStart(2, '0')}:00`,
          marginLeft + 1,
          lineY + 3
        );
      }

      // Draw Columns for Rooms in the current page group
      const numRooms = pageStations.length;
      const colWidth = roomsWidth / numRooms;

      pageStations.forEach((station, colIdx) => {
        const colStartX = marginLeft + timeColWidth + colIdx * colWidth;

        // Fetch roster details for this room
        const roster = rosters.find((r) => r.stationId === station.id && r.date === selectedDate);
        const primaryDr = roster?.primaryPractitionerId
          ? practitioners.find((p) => p.id === roster.primaryPractitionerId)
          : undefined;
        const backupDr = roster?.backupPractitionerId
          ? practitioners.find((p) => p.id === roster.backupPractitionerId)
          : undefined;

        // Column Header Box
        doc.setFillColor(241, 245, 249); // slate-100
        doc.setDrawColor(203, 213, 225); // slate-300
        doc.setLineWidth(0.2);
        doc.rect(colStartX, gridStartY - 13, colWidth, 13, 'FD');

        // Room Name and Doctors in Header Box
        doc.setFont('Helvetica', 'bold');
        doc.setFontSize(8.5);
        doc.setTextColor(15, 23, 42); // slate-900
        doc.text(
          station.name,
          colStartX + 2,
          gridStartY - 9.5
        );

        doc.setFont('Helvetica', 'normal');
        doc.setFontSize(7);
        doc.setTextColor(71, 85, 105); // slate-600
        const docText = primaryDr ? `Dr: ${primaryDr.displayName}` : 'Dr: Unassigned';
        doc.text(
          docText,
          colStartX + 2,
          gridStartY - 5.5
        );

        if (backupDr) {
          doc.text(
            `Backup: ${backupDr.displayName}`,
            colStartX + 2,
            gridStartY - 1.5
          );
        }

        // Draw vertical column divider on the right of the column
        doc.setDrawColor(203, 213, 225);
        doc.setLineWidth(0.2);
        doc.line(colStartX + colWidth, gridStartY, colStartX + colWidth, gridEndY);

        // Render Scheduled Allocations for this station
        const stationAllocations = allocations.filter(
          (a) => a.stationId === station.id && a.date === selectedDate && a.status !== 'CANCELLED'
        );

        stationAllocations.forEach((alloc) => {
          const startMins = parseTimeToMinutes(alloc.plannedStart) - 8 * 60;
          const endMins = parseTimeToMinutes(alloc.plannedEnd) - 8 * 60;

          if (startMins < 0 || endMins > totalMinutes) return;

          const startY = gridStartY + startMins * scale;
          const endY = gridStartY + endMins * scale;
          const heightY = endY - startY;

          // Find occurrence and treatment details
          const occ = occurrences.find((o) => o.id === alloc.treatmentOccurrenceId);
          const ord = occ ? orders.find((o) => o.id === occ.treatmentOrderId) : undefined;
          const pat = ord ? patients.find((p) => p.id === ord.patientId) : undefined;
          const treat = ord ? treatments.find((t) => t.id === ord.treatmentId) : undefined;

          // Variations parser list
          const variationsList: string[] = [];
          if (treat?.variations && Array.isArray(treat.variations)) {
            treat.variations.forEach((v) => {
              if (v && v !== 'Default Protocol') {
                variationsList.push(v);
              }
            });
          }
          if (ord?.instructions) {
            const match = ord.instructions.match(/Variations:\s*([^.]+)/i);
            if (match && match[1]) {
              const parts = match[1]
                .split(',')
                .map((p) => p.trim())
                .filter((p) => p.length > 0 && p !== 'Default Protocol');
              parts.forEach((p) => {
                if (!variationsList.includes(p)) {
                  variationsList.push(p);
                }
              });
            }
          }

          // Card color palette based on priority
          const priority = ord?.priority || 'NORMAL';
          let fillR = 248, fillG = 250, fillB = 252; // default slate-50
          let borderR = 148, borderG = 163, borderB = 184; // slate-400

          if (priority === 'URGENT') {
            fillR = 254; fillG = 242; fillB = 242; // rose-50
            borderR = 244; borderG = 63; borderB = 94; // rose-500
          } else if (priority === 'HIGH') {
            fillR = 255; fillG = 251; fillB = 235; // amber-50
            borderR = 245; borderG = 158; borderB = 11; // amber-500
          } else if (priority === 'NORMAL') {
            fillR = 240; fillG = 253; fillB = 250; // teal-50
            borderR = 20; borderG = 184; borderB = 166; // teal-500
          }

          // Draw Card Box
          doc.setFillColor(fillR, fillG, fillB);
          doc.setDrawColor(borderR, borderG, borderB);
          doc.setLineWidth(0.25);
          doc.rect(colStartX + 0.8, startY + 0.3, colWidth - 1.6, heightY - 0.6, 'FD');

          // Print text content (Patient, Treatment, Variations, Time)
          doc.setFont('Helvetica', 'bold');
          doc.setFontSize(7.5);
          doc.setTextColor(15, 23, 42); // slate-900

          const patName = pat ? `${pat.displayName} (${pat.gender.charAt(0)})` : 'Unknown';
          const maxCharCount = Math.floor(colWidth / 1.7);
          
          const truncate = (str: string) => {
            if (str.length > maxCharCount) {
              return str.substring(0, maxCharCount - 3) + '...';
            }
            return str;
          };

          // Draw Patient Name
          doc.text(truncate(patName), colStartX + 2, startY + 3.2);

          // Draw Treatment Name & Variations as small tabs starting from right of therapy name
          let currentY = startY + 6.3;
          let currentX = colStartX + 2;

          doc.setFont('Helvetica', 'bold');
          doc.setFontSize(7);
          doc.setTextColor(13, 148, 136); // teal-600
          const treatmentName = treat ? treat.name : 'Therapy';
          const truncatedTreatment = truncate(treatmentName);
          doc.text(truncatedTreatment, currentX, currentY);

          // Width of treatment name plus spacing
          const treatWidth = doc.getTextWidth(truncatedTreatment);
          currentX += treatWidth + 1.2;

          // Draw each variation as a small tab/pill with a border and light fill
          doc.setFont('Helvetica', 'bold');
          doc.setFontSize(5.5);
          doc.setTextColor(15, 118, 110); // slightly darker teal for tiny text readability

          variationsList.forEach((variation) => {
            const truncatedVar = truncate(variation);
            const textWidth = doc.getTextWidth(truncatedVar);
            const tabWidth = textWidth + 1.6; // 0.8mm padding on each side
            const tabHeight = 2.4;

            // If we exceed column width, wrap to the next line
            if (currentX + tabWidth > colStartX + colWidth - 1.5) {
              currentX = colStartX + 2;
              currentY += 3.2; // Move down to next line
            }

            // Draw pill container
            doc.setFillColor(240, 253, 250); // teal-50
            doc.setDrawColor(153, 246, 228); // teal-200
            doc.setLineWidth(0.08);
            doc.roundedRect(currentX, currentY - 1.8, tabWidth, tabHeight, 0.4, 0.4, 'FD');

            // Draw text inside pill
            doc.text(truncatedVar, currentX + 0.8, currentY - 0.1);

            // Advance horizontal pointer
            currentX += tabWidth + 0.8;
          });

          // Draw timings below the wrapped items
          currentY += 3.4;
          doc.setFont('Helvetica', 'bold');
          doc.setFontSize(6.5);
          doc.setTextColor(71, 85, 105); // slate-600
          const timeText = `${alloc.plannedStart} - ${alloc.plannedEnd}`;
          doc.text(timeText, colStartX + 2, currentY);

          // Draw 10-minute Preparation Buffer block
          const prepStartY = endY;
          const prepHeightY = 10 * scale;

          doc.setFillColor(241, 245, 249); // slate-100
          doc.setDrawColor(148, 163, 184); // slate-400
          doc.setLineWidth(0.15);
          // Draw dashed or dotted preparation boundary using simple rectangles
          doc.rect(colStartX + 0.8, prepStartY, colWidth - 1.6, prepHeightY, 'FD');

          doc.setFont('Helvetica', 'normal');
          doc.setFontSize(6);
          doc.setTextColor(100, 116, 139);
          doc.text("Preparation Buffer (10m)", colStartX + 2, prepStartY + 2.5);
        });
      });
    }
  }

  // Open Save Prompt dialog
  doc.save(`Clinical_Schedule_${selectedDate}.pdf`);
}
