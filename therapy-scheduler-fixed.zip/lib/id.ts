let sequence = 0;

/** Unique keys even when several orders or history entries are created in one millisecond. */
export function createId(prefix: string): string {
  if (typeof globalThis.crypto?.randomUUID === 'function') {
    return `${prefix}-${globalThis.crypto.randomUUID()}`;
  }
  // A sequence prevents collisions even when the clock and random source repeat.
  // The fallback supports non-secure browser contexts without randomUUID().
  sequence += 1;
  return `${prefix}-${Date.now().toString(36)}-${sequence.toString(36)}-${Math.random().toString(36).slice(2, 10)}`;
}
