import type {Metadata} from 'next';
import './globals.css'; // Global styles

export const metadata: Metadata = {
  title: 'Therapy Scheduler - Hospital & Rehabilitation Station Manager',
  description: 'Hospital and therapy centre scheduling system for stations, practitioner rosters, treatment orders, and real-time conflict-validated therapy allocations.',
  openGraph: {
    title: 'Therapy Scheduler - Hospital & Rehabilitation Station Manager',
    description: 'Hospital and therapy centre scheduling system for stations, practitioner rosters, treatment orders, and real-time conflict-validated therapy allocations.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Therapy Scheduler - Hospital & Rehabilitation Station Manager',
    description: 'Hospital and therapy centre scheduling system for stations, practitioner rosters, treatment orders, and real-time conflict-validated therapy allocations.',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
