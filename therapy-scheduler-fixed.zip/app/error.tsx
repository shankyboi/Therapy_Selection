'use client';

export default function ErrorPage({ reset }: { reset: () => void }) {
  return (
    <main className="min-h-screen flex items-center justify-center bg-slate-100 p-6">
      <section role="alert" className="max-w-lg rounded-xl bg-white p-6 shadow-lg text-slate-800">
        <h1 className="text-xl font-semibold">The scheduler could not load</h1>
        <p className="mt-3 text-sm">
          Try again or reload the page. Reloading does not clear your saved browser data.
          When reporting the problem, include the browser console or terminal error.
        </p>
        <div className="mt-5 flex gap-3">
          <button onClick={reset} className="rounded-lg bg-teal-700 px-4 py-2 text-white">Try again</button>
          <button onClick={() => window.location.reload()} className="rounded-lg border px-4 py-2">Reload page</button>
        </div>
      </section>
    </main>
  );
}
