'use client';

import dynamic from 'next/dynamic';

// Client Components are otherwise prerendered by Next.js. The scheduler uses
// the browser's local calendar date and localStorage, not server-side data.
const TherapySchedulerApp = dynamic(
  () => import('@/components/TherapySchedulerApp'),
  {
    ssr: false,
    loading: () => (
      <main className="min-h-screen flex items-center justify-center bg-slate-100 text-slate-700">
        <p role="status" aria-live="polite">Loading therapy scheduler...</p>
      </main>
    ),
  }
);

export default function Page() {
  return <TherapySchedulerApp />;
}
