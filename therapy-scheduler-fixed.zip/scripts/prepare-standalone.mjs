import { cpSync, existsSync, mkdirSync, rmSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = fileURLToPath(new URL('../', import.meta.url));
const standalone = join(root, '.next', 'standalone');
if (!existsSync(join(standalone, 'server.js'))) {
  throw new Error('Standalone server was not generated. Run next build first.');
}

// Next.js does not copy these assets into standalone output automatically.
for (const relative of ['.next/static', 'public']) {
  const source = join(root, relative);
  if (!existsSync(source)) continue;
  const destination = join(standalone, relative);
  rmSync(destination, { recursive: true, force: true });
  mkdirSync(dirname(destination), { recursive: true });
  cpSync(source, destination, { recursive: true });
}
console.log('Standalone server assets prepared.');
