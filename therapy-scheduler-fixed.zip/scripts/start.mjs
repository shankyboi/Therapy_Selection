import { existsSync } from 'node:fs';
import { fileURLToPath, pathToFileURL } from 'node:url';

const server = fileURLToPath(new URL('../.next/standalone/server.js', import.meta.url));
if (!existsSync(server)) {
  console.error('Production build not found. Run "npm run build" before "npm start".');
  process.exit(1);
}

// PORT/HOSTNAME may be supplied by the hosting platform.
process.env.PORT ||= '3000';
process.env.HOSTNAME ||= '0.0.0.0';
await import(pathToFileURL(server).href);
