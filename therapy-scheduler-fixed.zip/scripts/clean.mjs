import { rmSync } from 'node:fs';
import { fileURLToPath } from 'node:url';

// Project-relative and cross-platform. Never delete dependencies or user data.
for (const path of ['../.next', '../tsconfig.tsbuildinfo']) {
  rmSync(fileURLToPath(new URL(path, import.meta.url)), {
    recursive: true,
    force: true,
  });
}
console.log('Removed the Next.js build cache and TypeScript build metadata.');
