/* Dependency-free application regression tests apart from the project's TypeScript compiler.
 * These check source syntax and core data logic; they do NOT replace a Next.js build
 * or a real browser/end-to-end test.
 */
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const ts = require('typescript');

const root = path.resolve(__dirname, '..');
const STORAGE_KEY = 'therapy_scheduler_data_v4';

function walk(directory) {
  return fs.readdirSync(directory, { withFileTypes: true }).flatMap((entry) => {
    if (['node_modules', '.next', '.git'].includes(entry.name)) return [];
    const target = path.join(directory, entry.name);
    return entry.isDirectory() ? walk(target) : [target];
  });
}

function memoryStorage(initial) {
  const data = new Map(initial === undefined ? [] : [[STORAGE_KEY, initial]]);
  return {
    data,
    getItem: (key) => data.get(key) ?? null,
    setItem: (key, value) => data.set(key, String(value)),
  };
}

// Execute actual application modules, not reimplementations of their logic.
function loadApp({ storage, frozenClock = false, sourceRoot = root } = {}) {
  const context = vm.createContext({ console });
  if (storage !== undefined) {
    context.window = { localStorage: storage };
    context.localStorage = storage;
  }
  if (frozenClock) {
    vm.runInContext('Date.now = () => 1770000000000; Math.random = () => 0.5;', context);
  }
  const cache = new Map();
  function load(relative) {
    const filename = path.resolve(sourceRoot, relative);
    if (cache.has(filename)) return cache.get(filename).exports;
    const module = { exports: {} };
    cache.set(filename, module);
    const result = ts.transpileModule(fs.readFileSync(filename, 'utf8'), {
      fileName: filename,
      compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2020 },
    });
    const localRequire = (specifier) => {
      if (specifier.startsWith('@/')) return load(`${specifier.slice(2)}.ts`);
      if (specifier.startsWith('.')) {
        return load(path.relative(sourceRoot, path.resolve(path.dirname(filename), specifier)) + '.ts');
      }
      throw new Error(`Unexpected external dependency in core tests: ${specifier}`);
    };
    const run = vm.runInContext(`(function(require, module, exports) {\n${result.outputText}\n})`, context, { filename });
    run(localRequire, module, module.exports);
    return module.exports;
  }
  return { service: load('services/therapyService.ts').therapyService, load, context };
}

function snapshot() {
  return JSON.parse(JSON.stringify(loadApp().service.getData()));
}

function createOrder(service) {
  const data = service.getData();
  return service.createOrderWithVariations(
    data.patients[0].id, data.treatments[0].id, 2,
    data.lastInitializedDate, data.lastInitializedDate, 'NORMAL', 'Regression test', 30
  );
}

test('all TypeScript and TSX source files parse without syntax errors', () => {
  const files = walk(root).filter((file) => /\.tsx?$/.test(file) && !file.endsWith('.d.ts'));
  const errors = [];
  for (const file of files) {
    const source = ts.createSourceFile(file, fs.readFileSync(file, 'utf8'), ts.ScriptTarget.Latest, true);
    errors.push(...source.parseDiagnostics);
  }
  assert.equal(errors.length, 0, ts.formatDiagnosticsWithColorAndContext(errors, {
    getCurrentDirectory: () => root, getCanonicalFileName: (name) => name, getNewLine: () => '\n',
  }));
  assert.ok(files.length >= 25);
});

test('strict TypeScript check passes for models, sample data, validation, IDs, and service', () => {
  const config = ts.readConfigFile(path.join(root, 'tsconfig.json'), ts.sys.readFile);
  assert.equal(config.error, undefined);
  const parsed = ts.parseJsonConfigFileContent(config.config, ts.sys, root);
  const files = ['types/therapy.ts', 'lib/sampleData.ts', 'lib/validation.ts', 'lib/id.ts', 'services/therapyService.ts'];
  const program = ts.createProgram(files.map((file) => path.join(root, file)), {
    ...parsed.options, noEmit: true, incremental: false, types: [],
  });
  const diagnostics = ts.getPreEmitDiagnostics(program);
  assert.equal(diagnostics.length, 0, ts.formatDiagnosticsWithColorAndContext(diagnostics, {
    getCurrentDirectory: () => root, getCanonicalFileName: (name) => name, getNewLine: () => '\n',
  }));
});

test('Next.js and ESLint versions match; React and React DOM versions match', () => {
  const pkg = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));
  assert.equal(pkg.dependencies.next, pkg.devDependencies['eslint-config-next']);
  assert.equal(pkg.dependencies.react, pkg.dependencies['react-dom']);
  assert.ok(!pkg.scripts.clean.includes('next clean'));
});

test('Next.js ambient declarations are present', () => {
  const file = fs.readFileSync(path.join(root, 'next-env.d.ts'), 'utf8');
  assert.match(file, /reference types="next"/);
  assert.match(file, /reference types="next\/image-types\/global"/);
});

test('browser-only scheduler and lazy PDF import are present', () => {
  const page = fs.readFileSync(path.join(root, 'app/page.tsx'), 'utf8');
  assert.match(page, /ssr:\s*false/);
  assert.match(page, /'use client'/);
  const grid = fs.readFileSync(path.join(root, 'components/scheduler/SchedulerGrid.tsx'), 'utf8');
  assert.match(grid, /await import\('@\/lib\/pdfGenerator'\)/);
  assert.doesNotMatch(grid, /import\s*\{\s*generateSchedulerPDF\s*\}\s*from/);
});

test('service imports and seeds safely without window or localStorage', () => {
  const { service } = loadApp();
  assert.ok(service.getStations().length > 0);
  assert.ok(service.getOrders().length > 0);
  assert.equal(service.getStorageWarning(), null);
});

test('a fresh browser receives a complete persistable dataset', () => {
  const storage = memoryStorage();
  const { service } = loadApp({ storage });
  const saved = JSON.parse(storage.getItem(STORAGE_KEY));
  for (const key of ['stationTypes', 'stations', 'treatments', 'capabilities', 'practitioners', 'patients', 'rosters', 'orders', 'occurrences', 'allocations', 'history']) {
    assert.ok(Array.isArray(saved[key]), key);
  }
  assert.equal(service.getStorageWarning(), null);
  assert.equal(loadApp({ storage }).service.getStorageWarning(), null);
});

test('valid saved data is retained without reseeding or rewriting it', () => {
  const data = snapshot();
  data.stations[0].name = 'User-edited therapy room';
  const original = JSON.stringify(data);
  const storage = memoryStorage(original);
  const { service } = loadApp({ storage });
  assert.equal(service.getStations()[0].name, 'User-edited therapy room');
  assert.equal(service.getStorageWarning(), null);
  assert.equal(storage.getItem(STORAGE_KEY), original);
});

for (const [name, raw] of [
  ['malformed JSON', '{broken json'],
  ['empty stored string', ''],
  ['null document', 'null'],
  ['missing collections', JSON.stringify({ stations: [], allocations: [] })],
]) {
  test(`${name}: temporary defaults do not overwrite the original data`, () => {
    const storage = memoryStorage(raw);
    const { service } = loadApp({ storage });
    assert.ok(service.getStorageWarning());
    assert.ok(service.getStationTypes().length > 0);
    createOrder(service);
    assert.equal(storage.getItem(STORAGE_KEY), raw);
  });
}

for (const [name, corrupt] of [
  ['null record', (data) => { data.stations.push(null); }],
  ['missing required string', (data) => { delete data.stations[0].name; }],
  ['invalid numeric field', (data) => { data.stations[0].capacity = 'two'; }],
  ['invalid nested array', (data) => { data.stations[0].genderApplicability = 'All'; }],
  ['duplicate IDs', (data) => { data.orders.push({ ...data.orders[0] }); }],
]) {
  test(`${name} is rejected before reaching the UI and the snapshot is preserved`, () => {
    const data = snapshot();
    corrupt(data);
    const raw = JSON.stringify(data);
    const storage = memoryStorage(raw);
    const { service } = loadApp({ storage });
    assert.ok(service.getStorageWarning());
    assert.equal(storage.getItem(STORAGE_KEY), raw);
    assert.ok(service.getStations().every((station) => typeof station.name === 'string'));
  });
}

test('blocked storage reads do not crash startup or subsequent in-memory edits', () => {
  const storage = {
    getItem() { throw new Error('SecurityError: storage blocked'); },
    setItem() { throw new Error('SecurityError: storage blocked'); },
  };
  const { service } = loadApp({ storage });
  assert.match(service.getStorageWarning(), /unavailable/);
  assert.doesNotThrow(() => createOrder(service));
});

test('storage quota failure is reported and the in-memory dataset remains usable', () => {
  const storage = { getItem: () => null, setItem() { throw new Error('QuotaExceededError'); } };
  const { service } = loadApp({ storage });
  assert.match(service.getStorageWarning(), /could not be saved/);
  const count = service.getOrders().length;
  createOrder(service);
  assert.equal(service.getOrders().length, count + 1);
});

test('explicit Reset Demo restores persistence after an invalid snapshot', () => {
  const storage = memoryStorage('{invalid');
  const { service } = loadApp({ storage });
  service.resetToDemo();
  assert.equal(service.getStorageWarning(), null);
  assert.ok(JSON.parse(storage.getItem(STORAGE_KEY)).stations.length > 0);
});

test('subscribers are notified once per save and can unsubscribe', () => {
  const { service } = loadApp();
  let count = 0;
  const stop = service.subscribe(() => { count += 1; });
  createOrder(service);
  assert.equal(count, 1);
  stop();
  createOrder(service);
  assert.equal(count, 1);
});

test('batch-created orders and occurrences remain unique when clock and randomness repeat', () => {
  const { service } = loadApp({ frozenClock: true });
  const ids = [];
  const occurrenceIds = [];
  for (let i = 0; i < 100; i += 1) {
    const result = createOrder(service);
    ids.push(result.order.id);
    occurrenceIds.push(...result.occurrences.map((entry) => entry.id));
  }
  assert.equal(new Set(ids).size, ids.length);
  assert.equal(new Set(occurrenceIds).size, occurrenceIds.length);
});

test('allocation updates keep status and history coherent with unique history keys', () => {
  const { service } = loadApp({ frozenClock: true });
  const result = createOrder(service);
  const allocation = service.createAllocation({
    treatmentOccurrenceId: result.occurrences[0].id,
    stationId: service.getStations()[0].id,
    date: service.getData().lastInitializedDate,
    plannedStart: '10:00', plannedEnd: '10:30', status: 'CONFIRMED', createdBy: 'Test',
  });
  service.updateAllocationStatus(allocation.id, 'CHECKED_IN');
  service.updateAllocationStatus(allocation.id, 'IN_PROGRESS');
  assert.equal(service.getAllocations().find((item) => item.id === allocation.id).status, 'IN_PROGRESS');
  assert.equal(service.getOccurrences().find((item) => item.id === result.occurrences[0].id).status, 'IN_PROGRESS');
  const ids = service.getHistory().map((item) => item.id);
  assert.equal(new Set(ids).size, ids.length);
});

test('time arithmetic and non-overlapping boundary slots retain existing behavior', () => {
  const { load } = loadApp();
  const validation = load('lib/validation.ts');
  assert.equal(validation.calculateEndTime('09:30', 45), '10:15');
  assert.equal(validation.doIntervalsOverlap('09:00', '09:30', '09:30', '10:00'), false);
  assert.equal(validation.doIntervalsOverlap('09:00', '09:45', '09:30', '10:00'), true);
});

test('invalid occurrence IDs are rejected by allocation validation', () => {
  const { service, load } = loadApp();
  const validation = load('lib/validation.ts');
  const result = validation.validateAllocation({
    treatmentOccurrenceId: 'does-not-exist', stationId: service.getStations()[0].id,
    date: service.getData().lastInitializedDate, plannedStart: '09:00', plannedEnd: '09:30',
  }, service.getValidationContext());
  assert.equal(result.isValid, false);
  assert.ok(result.errors.some((error) => error.code === 'OCCURRENCE_NOT_FOUND'));
});

// Exported for the repair report's original-versus-fixed reproduction checks.
module.exports = { loadApp, memoryStorage, createOrder };

test('cross-platform clean command only removes generated build files', () => {
  const os = require('node:os');
  const { spawnSync } = require('node:child_process');
  const fixture = fs.mkdtempSync(path.join(os.tmpdir(), 'therapy-clean-test-'));
  try {
    fs.mkdirSync(path.join(fixture, 'scripts'));
    fs.cpSync(path.join(root, 'scripts/clean.mjs'), path.join(fixture, 'scripts/clean.mjs'));
    fs.mkdirSync(path.join(fixture, '.next'));
    fs.writeFileSync(path.join(fixture, '.next', 'generated.js'), 'build artifact');
    fs.writeFileSync(path.join(fixture, 'tsconfig.tsbuildinfo'), '{}');
    fs.writeFileSync(path.join(fixture, '.env.local'), 'KEEP_ME=true');
    const run = spawnSync(process.execPath, [path.join(fixture, 'scripts/clean.mjs')], { encoding: 'utf8' });
    assert.equal(run.status, 0, run.stderr);
    assert.equal(fs.existsSync(path.join(fixture, '.next')), false);
    assert.equal(fs.existsSync(path.join(fixture, 'tsconfig.tsbuildinfo')), false);
    assert.equal(fs.readFileSync(path.join(fixture, '.env.local'), 'utf8'), 'KEEP_ME=true');
  } finally { fs.rmSync(fixture, { recursive: true, force: true }); }
});

test('standalone preparation copies CSS/JS and public assets into a build fixture', () => {
  const os = require('node:os');
  const { spawnSync } = require('node:child_process');
  const fixture = fs.mkdtempSync(path.join(os.tmpdir(), 'therapy-assets-test-'));
  try {
    for (const dir of ['scripts', '.next/standalone', '.next/static', 'public']) {
      fs.mkdirSync(path.join(fixture, dir), { recursive: true });
    }
    fs.cpSync(path.join(root, 'scripts/prepare-standalone.mjs'), path.join(fixture, 'scripts/prepare-standalone.mjs'));
    fs.writeFileSync(path.join(fixture, '.next/standalone/server.js'), '// fixture only');
    fs.writeFileSync(path.join(fixture, '.next/static/app.css'), 'body{}');
    fs.writeFileSync(path.join(fixture, 'public/test.txt'), 'asset');
    const run = spawnSync(process.execPath, [path.join(fixture, 'scripts/prepare-standalone.mjs')], { encoding: 'utf8' });
    assert.equal(run.status, 0, run.stderr);
    assert.equal(fs.readFileSync(path.join(fixture, '.next/standalone/.next/static/app.css'), 'utf8'), 'body{}');
    assert.equal(fs.readFileSync(path.join(fixture, '.next/standalone/public/test.txt'), 'utf8'), 'asset');
  } finally { fs.rmSync(fixture, { recursive: true, force: true }); }
});

test('production launcher reports a missing build clearly', () => {
  const os = require('node:os');
  const { spawnSync } = require('node:child_process');
  const fixture = fs.mkdtempSync(path.join(os.tmpdir(), 'therapy-start-test-'));
  try {
    fs.mkdirSync(path.join(fixture, 'scripts'));
    fs.cpSync(path.join(root, 'scripts/start.mjs'), path.join(fixture, 'scripts/start.mjs'));
    const run = spawnSync(process.execPath, [path.join(fixture, 'scripts/start.mjs')], { encoding: 'utf8' });
    assert.equal(run.status, 1);
    assert.match(run.stderr, /npm run build/);
  } finally { fs.rmSync(fixture, { recursive: true, force: true }); }
});
