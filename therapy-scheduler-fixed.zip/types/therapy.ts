export type AttentionMode = 'EXCLUSIVE' | 'SHARED' | 'UNATTENDED';

export type PriorityLevel = 'URGENT' | 'HIGH' | 'NORMAL' | 'LOW';

export type OrderStatus = 'ACTIVE' | 'COMPLETED' | 'CANCELLED';

export type OccurrenceStatus = 
  | 'UNSCHEDULED' 
  | 'SCHEDULED' 
  | 'CHECKED_IN' 
  | 'IN_PROGRESS' 
  | 'COMPLETED' 
  | 'CANCELLED' 
  | 'NO_SHOW';

export type AllocationStatus = 
  | 'CONFIRMED' 
  | 'CHECKED_IN' 
  | 'IN_PROGRESS' 
  | 'COMPLETED' 
  | 'CANCELLED' 
  | 'NO_SHOW';

export type RosterStatus = 'SCHEDULED' | 'CONFIRMED' | 'ABSENT';

export type HistoryEventType = 
  | 'CREATED' 
  | 'RESCHEDULED' 
  | 'STATUS_CHANGED' 
  | 'OVERRIDDEN' 
  | 'CANCELLED' 
  | 'RETURNED_TO_UNSCHEDULED';

export interface StationType {
  id: string;
  name: string;
  description: string;
  defaultCapacity: number;
  isActive: boolean;
}

export interface Station {
  id: string;
  name: string;
  stationTypeId: string;
  department: string;
  location: string;
  capacity: number;
  isActive: boolean;
  notes?: string;

  // New room attributes
  block?: string;
  building?: string;
  floor?: string;
  roomType?: string;
  roomSlt?: string;
  genderApplicability?: string[];
  overbookingLimit?: number;
  therapyApplicability?: Array<{ category: string; treatmentId: string }>;
}

export interface Treatment {
  id: string;
  name: string;
  description: string;
  defaultDurationMinutes: number;
  category?: string;
  isActive: boolean;
  variations?: string[];
}

export interface StationTreatmentCapability {
  id: string;
  stationId: string;
  treatmentId: string;
  isAllowed: boolean;
  durationMinutes: number;
  stationCapacity: number;
  attentionMode: AttentionMode;
  maximumParallelPatients?: number | null;
  isActive: boolean;
}

export interface Practitioner {
  id: string;
  externalPractitionerId: string;
  displayName: string;
  department: string;
  title?: string;
  specialization?: string;
  isActive: boolean;
}

export interface StationPractitionerRoster {
  id: string;
  date: string; // YYYY-MM-DD
  startTime: string; // HH:mm (e.g., "08:00")
  endTime: string; // HH:mm (e.g., "18:00")
  stationId: string;
  primaryPractitionerId: string;
  backupPractitionerId?: string | null;
  practitionerIds?: string[]; // Array of assigned therapists
  status: RosterStatus;
  notes?: string;
}

export interface Patient {
  id: string;
  externalPatientId: string;
  displayName: string;
  gender: 'MALE' | 'FEMALE' | 'OTHER';
  age: number;
  department: string;
  phone?: string;
  medicalRecordNumber?: string;
  precautions?: string;
}

export interface TreatmentOrder {
  id: string;
  externalOrderId: string;
  patientId: string;
  treatmentId: string;
  totalSessions: number;
  completedSessions: number;
  earliestAllowedDate: string; // YYYY-MM-DD
  latestAllowedDate: string; // YYYY-MM-DD
  priority: PriorityLevel;
  instructions: string;
  status: OrderStatus;
}

export interface TreatmentOccurrence {
  id: string;
  treatmentOrderId: string;
  sessionNumber: number;
  expectedDurationMinutes: number;
  requestedDate: string; // YYYY-MM-DD
  status: OccurrenceStatus;
}

export interface TreatmentAllocation {
  id: string;
  treatmentOccurrenceId: string;
  stationId: string;
  rosterId?: string;
  date: string; // YYYY-MM-DD
  plannedStart: string; // HH:mm
  plannedEnd: string; // HH:mm
  plannedPractitionerId?: string;
  actualPractitionerId?: string;
  status: AllocationStatus;
  checkInTime?: string;
  actualStartTime?: string;
  actualEndTime?: string;
  notes?: string;
  overrideReason?: string;
  overriddenBy?: string;
  overriddenAt?: string;
  createdBy: string;
  createdAt: string;
  updatedBy?: string;
  updatedAt?: string;
}

export interface AllocationHistory {
  id: string;
  allocationId: string;
  eventType: HistoryEventType;
  previousValue?: string;
  newValue?: string;
  reason?: string;
  performedBy: string;
  performedAt: string;
}

export interface ValidationIssue {
  type: 'ERROR' | 'WARNING' | 'INFO';
  code: string;
  message: string;
  details?: string;
}

export interface ValidationResult {
  isValid: boolean;
  hasWarnings: boolean;
  errors: ValidationIssue[];
  warnings: ValidationIssue[];
  infos: ValidationIssue[];
}

export type ActivePage = 
  | 'dashboard'
  | 'therapy-selection'
  | 'station-types'
  | 'stations'
  | 'capabilities'
  | 'practitioner-planner'
  | 'scheduler'
  | 'reports';
